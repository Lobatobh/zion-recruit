import { db } from '../src/lib/db';

async function main() {
  const stages = await db.pipelineStage.findMany({
    orderBy: { order: 'asc' }
  });
  console.log('Pipeline Stages:', JSON.stringify(stages, null, 2));
  
  const tenants = await db.tenant.findMany();
  console.log('\nTenants:', JSON.stringify(tenants, null, 2));
  
  const agents = await db.aIAgent.findMany();
  console.log('\nAI Agents:', JSON.stringify(agents, null, 2));
}

main().catch(console.error).finally(() => db.$disconnect());
