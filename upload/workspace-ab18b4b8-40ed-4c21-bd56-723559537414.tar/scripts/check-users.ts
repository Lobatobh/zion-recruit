import { db } from '../src/lib/db';

async function main() {
  // Check users
  const users = await db.user.findMany();
  console.log('Users:', JSON.stringify(users, null, 2));
  
  // Check tenant members
  const members = await db.tenantMember.findMany({
    include: { user: true, tenant: true }
  });
  console.log('\nTenant Members:', JSON.stringify(members, null, 2));
  
  // Check pipeline stages
  const stages = await db.pipelineStage.findMany({
    orderBy: { order: 'asc' }
  });
  console.log('\nPipeline Stages:', JSON.stringify(stages, null, 2));
  
  // Check if stages belong to the member's tenant
  if (members.length > 0 && stages.length > 0) {
    const memberTenantId = members[0].tenantId;
    const stagesForTenant = stages.filter(s => s.tenantId === memberTenantId);
    console.log(`\nStages for member's tenant (${memberTenantId}): ${stagesForTenant.length}`);
  }
}

main().catch(console.error).finally(() => db.$disconnect());
