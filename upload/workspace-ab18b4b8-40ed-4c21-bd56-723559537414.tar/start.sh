#!/bin/bash
cd /home/z/my-project
rm -rf .next
while true; do
  echo "$(date) - Starting server..." >> server.log
  bun run dev >> server.log 2>&1 &
  PID=$!
  echo "Started PID: $PID" >> server.log
  
  # Wait for process to die
  while kill -0 $PID 2>/dev/null; do
    sleep 5
  done
  
  echo "$(date) - Process $PID died, restarting..." >> server.log
  sleep 2
done
