#!/bin/bash
cd /home/z/my-project

# Start server with auto-restart, no cache clearing
while true; do
  echo "$(date) - Starting server..." >> server-run.log
  bun run dev 2>&1 | tee -a server-run.log
  echo "$(date) - Server exited with code $?" >> server-run.log
  sleep 3
done
