#!/bin/bash
cd /home/z/my-project

# Kill existing
pkill -9 -f "next dev" 2>/dev/null
sleep 2

# Clean
rm -rf .next

# Start in a way that persists
exec bun run dev
