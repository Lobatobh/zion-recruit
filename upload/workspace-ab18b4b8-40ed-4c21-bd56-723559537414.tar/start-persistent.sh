#!/bin/bash
cd /home/z/my-project

# Cleanup
rm -rf .next
pkill -9 -f "next dev" 2>/dev/null

# Start with auto-restart
while true; do
  echo "$(date) - Starting server..." >> server-persistent.log
  
  # Start server (this will block until it dies)
  timeout 120 bun run dev 2>&1 | tee -a server-persistent.log
  
  EXIT_CODE=$?
  echo "$(date) - Server exited with code $EXIT_CODE" >> server-persistent.log
  
  # If timeout, restart immediately. Otherwise wait a bit.
  if [ $EXIT_CODE -eq 124 ]; then
    echo "Timeout, restarting..." >> server-persistent.log
  else
    sleep 2
  fi
done
