/**
 * Parse Resume API - Zion Recruit
 * Parse resume text without creating a candidate (for preview)
 */

import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { parseResume, validateResumeContent } from "@/lib/resume-parser";

interface ParseResumeBody {
  resumeText: string;
  resumeBase64?: string;
}

// POST /api/candidates/parse-resume - Parse resume for preview
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.tenantId) {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const body: ParseResumeBody = await request.json();
    let { resumeText, resumeBase64 } = body;

    // Handle base64 encoded content
    if (resumeBase64 && !resumeText) {
      try {
        resumeText = Buffer.from(resumeBase64, "base64").toString("utf-8");
      } catch {
        return NextResponse.json(
          { error: "Falha ao decodificar conteúdo base64" },
          { status: 400 }
        );
      }
    }

    if (!resumeText) {
      return NextResponse.json(
        { error: "resumeText ou resumeBase64 é obrigatório" },
        { status: 400 }
      );
    }

    // Validate content
    const validation = validateResumeContent(resumeText);
    if (!validation.valid) {
      return NextResponse.json({
        success: false,
        warnings: validation.issues,
        data: null,
      });
    }

    // Parse resume
    const result = await parseResume(
      resumeText,
      session.user.tenantId,
      true // use cache
    );

    if (!result.success || !result.data) {
      return NextResponse.json({
        success: false,
        error: result.error || "Falha ao processar currículo",
        data: null,
      });
    }

    return NextResponse.json({
      success: true,
      cached: result.cached,
      data: result.data,
    });
  } catch (error) {
    console.error("Error parsing resume:", error);
    return NextResponse.json(
      { error: "Erro ao processar currículo" },
      { status: 500 }
    );
  }
}
