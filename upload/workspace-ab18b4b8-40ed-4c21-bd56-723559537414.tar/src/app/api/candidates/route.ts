/**
 * Candidates API - Zion Recruit
 * Handles candidate creation and listing
 */

import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { parseResume } from "@/lib/resume-parser";
import { calculateMatchScore, getJobRequirements } from "@/lib/matching-service";

interface CreateCandidateBody {
  jobId: string;
  name?: string;
  email?: string;
  phone?: string;
  linkedin?: string;
  portfolio?: string;
  resumeText?: string;
  resumeBase64?: string;
  skipParsing?: boolean;
}

// GET /api/candidates - List candidates for organization
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.tenantId) {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(request.url);
    const jobId = searchParams.get("jobId");
    const status = searchParams.get("status");
    const search = searchParams.get("search");
    const minScore = searchParams.get("minScore");

    // Build where clause
    const where: {
      tenantId: string;
      jobId?: string;
      status?: string;
      matchScore?: { gte: number };
      OR?: Array<{
        name?: { contains: string };
        email?: { contains: string };
      }>;
    } = {
      tenantId: session.user.tenantId,
    };

    if (jobId) {
      where.jobId = jobId;
    }

    if (status) {
      where.status = status;
    }

    if (minScore) {
      where.matchScore = { gte: parseInt(minScore) };
    }

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { email: { contains: search } },
      ];
    }

    const candidates = await db.candidate.findMany({
      where,
      include: {
        job: {
          select: {
            id: true,
            title: true,
            department: true,
          },
        },
        pipelineStage: {
          select: {
            id: true,
            name: true,
            color: true,
          },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({
      candidates,
      total: candidates.length,
    });
  } catch (error) {
    console.error("Error fetching candidates:", error);
    return NextResponse.json(
      { error: "Erro ao buscar candidatos" },
      { status: 500 }
    );
  }
}

// POST /api/candidates - Create new candidate with resume parsing
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.tenantId) {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const body: CreateCandidateBody = await request.json();
    const { 
      jobId, 
      name: providedName,
      email: providedEmail,
      phone: providedPhone,
      linkedin,
      portfolio,
      resumeText,
      resumeBase64,
      skipParsing 
    } = body;

    if (!jobId) {
      return NextResponse.json(
        { error: "jobId é obrigatório" },
        { status: 400 }
      );
    }

    // Verify job exists and belongs to organization
    const job = await db.job.findFirst({
      where: {
        id: jobId,
        tenantId: session.user.tenantId,
      },
    });

    if (!job) {
      return NextResponse.json(
        { error: "Vaga não encontrada" },
        { status: 404 }
      );
    }

    // Get default pipeline stage (first stage)
    const defaultStage = await db.pipelineStage.findFirst({
      where: {
        tenantId: session.user.tenantId,
      },
      orderBy: { order: "asc" },
    });

    // Prepare resume text
    let textContent = resumeText || "";
    
    if (resumeBase64 && !resumeText) {
      try {
        textContent = Buffer.from(resumeBase64, "base64").toString("utf-8");
      } catch {
        // If decoding fails, leave empty
      }
    }

    // Initialize candidate data
    let candidateData: {
      name: string;
      email: string;
      phone: string | null;
      linkedin: string | null;
      portfolio: string | null;
      resumeText: string | null;
      parsedSkills: string | null;
      parsedExperience: string | null;
      parsedEducation: string | null;
      parsedLanguages: string | null;
      aiSummary: string | null;
      matchScore: number | null;
      matchDetails: string | null;
    } = {
      name: providedName || "",
      email: providedEmail || "",
      phone: providedPhone || null,
      linkedin: linkedin || null,
      portfolio: portfolio || null,
      resumeText: textContent || null,
      parsedSkills: null,
      parsedExperience: null,
      parsedEducation: null,
      parsedLanguages: null,
      aiSummary: null,
      matchScore: null,
      matchDetails: null,
    };

    let parsingResult = null;
    let matchResult = null;

    // Parse resume if text provided and not skipped
    if (textContent && !skipParsing) {
      const parseResult = await parseResume(
        textContent,
        session.user.tenantId
      );

      if (parseResult.success && parseResult.data) {
        parsingResult = parseResult.data;
        
        // Override with parsed data if not provided
        candidateData.name = providedName || parsingResult.name || "";
        candidateData.email = providedEmail || parsingResult.email || "";
        candidateData.phone = providedPhone || parsingResult.phone || null;
        candidateData.parsedSkills = JSON.stringify(parsingResult.skills);
        candidateData.parsedExperience = JSON.stringify(parsingResult.experience);
        candidateData.parsedEducation = JSON.stringify(parsingResult.education);
        candidateData.parsedLanguages = JSON.stringify(parsingResult.languages);
        candidateData.aiSummary = parsingResult.summary || null;

        // Calculate match score
        const jobRequirements = await getJobRequirements(jobId);
        
        if (jobRequirements) {
          matchResult = await calculateMatchScore(
            {
              skills: parsingResult.skills,
              experience: parsingResult.experience,
              education: parsingResult.education,
              languages: parsingResult.languages,
              summary: parsingResult.summary,
            },
            jobRequirements,
            session.user.tenantId
          );

          candidateData.matchScore = matchResult.overallScore;
          candidateData.matchDetails = JSON.stringify({
            skillsScore: matchResult.skillsScore,
            experienceScore: matchResult.experienceScore,
            educationScore: matchResult.educationScore,
            reasons: matchResult.reasons,
            strengths: matchResult.strengths,
            gaps: matchResult.gaps,
          });
        }
      }
    }

    // Validate required fields
    if (!candidateData.name || !candidateData.email) {
      return NextResponse.json(
        { error: "Nome e email são obrigatórios" },
        { status: 400 }
      );
    }

    // Check for duplicate candidate (same email for same job)
    const existingCandidate = await db.candidate.findFirst({
      where: {
        tenantId: session.user.tenantId,
        jobId,
        email: candidateData.email,
      },
    });

    if (existingCandidate) {
      return NextResponse.json(
        { error: "Candidato já existe para esta vaga" },
        { status: 409 }
      );
    }

    // Create candidate
    const candidate = await db.candidate.create({
      data: {
        tenantId: session.user.tenantId,
        jobId,
        pipelineStageId: defaultStage?.id || null,
        name: candidateData.name,
        email: candidateData.email,
        phone: candidateData.phone,
        linkedin: candidateData.linkedin,
        portfolio: candidateData.portfolio,
        resumeText: candidateData.resumeText,
        parsedSkills: candidateData.parsedSkills,
        parsedExperience: candidateData.parsedExperience,
        parsedEducation: candidateData.parsedEducation,
        parsedLanguages: candidateData.parsedLanguages,
        aiSummary: candidateData.aiSummary,
        matchScore: candidateData.matchScore,
        matchDetails: candidateData.matchDetails,
        status: "APPLIED",
      },
      include: {
        job: {
          select: {
            id: true,
            title: true,
          },
        },
        pipelineStage: {
          select: {
            id: true,
            name: true,
            color: true,
          },
        },
      },
    });

    return NextResponse.json({
      candidate,
      parsing: parsingResult ? {
        success: true,
        cached: parsingResult.parsingConfidence,
      } : null,
      matching: matchResult ? {
        overallScore: matchResult.overallScore,
        cached: matchResult.cached,
      } : null,
    }, { status: 201 });
  } catch (error) {
    console.error("Error creating candidate:", error);
    return NextResponse.json(
      { error: "Erro ao criar candidato" },
      { status: 500 }
    );
  }
}
