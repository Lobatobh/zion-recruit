/**
 * Analytics Sources API
 * Returns source effectiveness metrics
 */

import { NextRequest, NextResponse } from 'next/server';
import { calculateSourceEffectiveness, getDefaultDateRange } from '@/lib/analytics/metrics';
import { formatSourcePieChart, formatSourceBarChart } from '@/lib/analytics/charts';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const tenantId = searchParams.get('tenantId') || 'demo';
    const startDateStr = searchParams.get('startDate');
    const endDateStr = searchParams.get('endDate');

    const dateRange = startDateStr && endDateStr
      ? {
          startDate: new Date(startDateStr),
          endDate: new Date(endDateStr),
        }
      : getDefaultDateRange(90);

    const metrics = await calculateSourceEffectiveness(tenantId, dateRange);

    return NextResponse.json({
      success: true,
      data: {
        metrics,
        pieChart: formatSourcePieChart(metrics),
        barChart: formatSourceBarChart(metrics),
      },
      dateRange: {
        startDate: dateRange.startDate.toISOString(),
        endDate: dateRange.endDate.toISOString(),
      },
    });
  } catch (error) {
    console.error('Error fetching source metrics:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch source metrics' },
      { status: 500 }
    );
  }
}
