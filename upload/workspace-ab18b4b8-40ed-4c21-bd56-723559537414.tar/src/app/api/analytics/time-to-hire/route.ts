/**
 * Analytics Time-to-Hire API
 * Returns time-to-hire metrics and trends
 */

import { NextRequest, NextResponse } from 'next/server';
import { calculateTimeToHire, getDefaultDateRange } from '@/lib/analytics/metrics';
import { formatTimeToHireChart } from '@/lib/analytics/charts';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const tenantId = searchParams.get('tenantId') || 'demo';
    const startDateStr = searchParams.get('startDate');
    const endDateStr = searchParams.get('endDate');

    const dateRange = startDateStr && endDateStr
      ? {
          startDate: new Date(startDateStr),
          endDate: new Date(endDateStr),
        }
      : getDefaultDateRange(90);

    const metrics = await calculateTimeToHire(tenantId, dateRange);

    return NextResponse.json({
      success: true,
      data: {
        metrics,
        lineChart: formatTimeToHireChart(metrics),
      },
      dateRange: {
        startDate: dateRange.startDate.toISOString(),
        endDate: dateRange.endDate.toISOString(),
      },
    });
  } catch (error) {
    console.error('Error fetching time-to-hire metrics:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch time-to-hire metrics' },
      { status: 500 }
    );
  }
}
