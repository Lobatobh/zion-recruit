/**
 * Analytics Pipeline API
 * Returns pipeline conversion rates and funnel data
 */

import { NextRequest, NextResponse } from 'next/server';
import { calculatePipelineConversion, getDefaultDateRange } from '@/lib/analytics/metrics';
import { formatPipelineFunnel, formatPipelineBarChart } from '@/lib/analytics/charts';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const tenantId = searchParams.get('tenantId') || 'demo';
    const startDateStr = searchParams.get('startDate');
    const endDateStr = searchParams.get('endDate');

    const dateRange = startDateStr && endDateStr
      ? {
          startDate: new Date(startDateStr),
          endDate: new Date(endDateStr),
        }
      : getDefaultDateRange(30);

    const metrics = await calculatePipelineConversion(tenantId, dateRange);

    return NextResponse.json({
      success: true,
      data: {
        metrics,
        funnel: formatPipelineFunnel(metrics),
        barChart: formatPipelineBarChart(metrics),
      },
      dateRange: {
        startDate: dateRange.startDate.toISOString(),
        endDate: dateRange.endDate.toISOString(),
      },
    });
  } catch (error) {
    console.error('Error fetching pipeline metrics:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to fetch pipeline metrics' },
      { status: 500 }
    );
  }
}
