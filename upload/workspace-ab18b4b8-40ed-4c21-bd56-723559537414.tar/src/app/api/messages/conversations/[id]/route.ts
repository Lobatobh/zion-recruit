/**
 * Single Conversation API - Zion Recruit
 * Handles individual conversation operations
 */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ConversationStatus } from "@prisma/client";

const DEMO_TENANT_ID = "cmmxleln70000px3a43u36vum";

// GET /api/messages/conversations/[id] - Get single conversation
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const conversation = await db.conversation.findFirst({
      where: {
        id,
        tenantId: DEMO_TENANT_ID,
      },
      include: {
        candidate: {
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            photo: true,
          },
        },
        job: {
          select: {
            id: true,
            title: true,
            department: true,
          },
        },
      },
    });

    if (!conversation) {
      return NextResponse.json(
        { error: "Conversa não encontrada" },
        { status: 404 }
      );
    }

    return NextResponse.json({ conversation });
  } catch (error) {
    console.error("Error fetching conversation:", error);
    return NextResponse.json(
      { error: "Falha ao carregar conversa" },
      { status: 500 }
    );
  }
}

// PATCH /api/messages/conversations/[id] - Update conversation
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { status, aiMode, notes } = body;

    const updateData: Record<string, unknown> = {};
    if (status) updateData.status = status as ConversationStatus;
    if (aiMode !== undefined) updateData.aiMode = aiMode;
    if (notes !== undefined) updateData.notes = notes;

    const conversation = await db.conversation.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({ conversation });
  } catch (error) {
    console.error("Error updating conversation:", error);
    return NextResponse.json(
      { error: "Falha ao atualizar conversa" },
      { status: 500 }
    );
  }
}

// DELETE /api/messages/conversations/[id] - Delete/archive conversation
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    // Archive instead of delete
    const conversation = await db.conversation.update({
      where: { id },
      data: { status: "ARCHIVED" as ConversationStatus },
    });

    return NextResponse.json({ conversation });
  } catch (error) {
    console.error("Error deleting conversation:", error);
    return NextResponse.json(
      { error: "Falha ao excluir conversa" },
      { status: 500 }
    );
  }
}
