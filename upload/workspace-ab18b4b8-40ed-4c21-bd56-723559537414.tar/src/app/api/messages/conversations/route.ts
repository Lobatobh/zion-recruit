/**
 * Conversations API - Zion Recruit
 * Handles conversation listing and creation
 * Uses raw queries until Prisma Client is regenerated
 */

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/messages/conversations - List conversations
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const channel = searchParams.get("channel");
    const jobId = searchParams.get("jobId");
    const search = searchParams.get("search");
    const needsIntervention = searchParams.get("needsIntervention");

    // Build where conditions
    const conditions: string[] = ["c.tenantId IS NOT NULL"];
    const params: unknown[] = [];

    if (status) {
      conditions.push("c.status = ?");
      params.push(status);
    }
    if (channel) {
      conditions.push("c.channel = ?");
      params.push(channel);
    }
    if (jobId) {
      conditions.push("c.jobId = ?");
      params.push(jobId);
    }
    if (needsIntervention === "true") {
      conditions.push("c.needsIntervention = 1");
    }

    // Get conversations with candidate and job info
    const whereClause = conditions.length > 0 
      ? `WHERE ${conditions.join(" AND ")}` 
      : "";

    const conversations = await db.$queryRawUnsafe(`
      SELECT 
        c.id,
        c.tenantId,
        c.candidateId,
        c.jobId,
        c.channel,
        c.status,
        c.aiMode,
        c.aiStage,
        c.lastMessageAt,
        c.lastMessagePreview,
        c.unreadCount,
        c.needsIntervention,
        c.interventionReason,
        c.createdAt,
        cand.name as candidateName,
        cand.email as candidateEmail,
        cand.phone as candidatePhone,
        cand.photo as candidatePhoto,
        j.title as jobTitle,
        j.department as jobDepartment
      FROM conversations c
      LEFT JOIN candidates cand ON c.candidateId = cand.id
      LEFT JOIN jobs j ON c.jobId = j.id
      ${whereClause}
      ORDER BY c.lastMessageAt DESC
      LIMIT 50
    `, ...params);

    // Transform results
    const formattedConversations = (conversations as any[]).map((row) => ({
      id: row.id,
      tenantId: row.tenantId,
      candidateId: row.candidateId,
      jobId: row.jobId,
      channel: row.channel,
      status: row.status,
      aiMode: row.aiMode === 1,
      aiStage: row.aiStage,
      lastMessageAt: row.lastMessageAt,
      lastMessagePreview: row.lastMessagePreview,
      unreadCount: row.unreadCount,
      needsIntervention: row.needsIntervention === 1,
      interventionReason: row.interventionReason,
      createdAt: row.createdAt,
      candidate: {
        id: row.candidateId,
        name: row.candidateName,
        email: row.candidateEmail,
        phone: row.candidatePhone,
        photo: row.candidatePhoto,
      },
      job: row.jobId
        ? {
            id: row.jobId,
            title: row.jobTitle,
            department: row.jobDepartment,
          }
        : null,
    }));

    return NextResponse.json({
      conversations: formattedConversations,
      total: formattedConversations.length,
    });
  } catch (error) {
    console.error("Error fetching conversations:", error);
    return NextResponse.json(
      { error: "Falha ao carregar conversas" },
      { status: 500 }
    );
  }
}

// POST /api/messages/conversations - Create new conversation
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { candidateId, jobId, channel = "CHAT" } = body;

    if (!candidateId) {
      return NextResponse.json(
        { error: "ID do candidato é obrigatório" },
        { status: 400 }
      );
    }

    // Check if conversation already exists
    const existing = await db.$queryRawUnsafe(`
      SELECT * FROM conversations 
      WHERE candidateId = ? AND channel = ?
      LIMIT 1
    `, candidateId, channel);

    if ((existing as any[]).length > 0) {
      return NextResponse.json({ conversation: (existing as any[])[0] });
    }

    // Get tenant from candidate
    const candidate = await db.$queryRawUnsafe(`
      SELECT tenantId FROM candidates WHERE id = ? LIMIT 1
    `, candidateId);

    if ((candidate as any[]).length === 0) {
      return NextResponse.json(
        { error: "Candidato não encontrado" },
        { status: 404 }
      );
    }

    const tenantId = (candidate as any[])[0].tenantId;

    // Create new conversation
    const id = `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = new Date().toISOString();

    await db.$queryRawUnsafe(`
      INSERT INTO conversations (
        id, tenantId, candidateId, jobId, channel, status, aiMode, aiStage, 
        lastMessageAt, unreadCount, needsIntervention, createdAt, updatedAt
      ) VALUES (?, ?, ?, ?, ?, 'ACTIVE', 1, 'welcome', ?, 0, 0, ?, ?)
    `, id, tenantId, candidateId, jobId || null, channel, now, now, now);

    const conversation = {
      id,
      tenantId,
      candidateId,
      jobId: jobId || null,
      channel,
      status: "ACTIVE",
      aiMode: true,
      aiStage: "welcome",
      lastMessageAt: now,
      unreadCount: 0,
      needsIntervention: false,
      createdAt: now,
    };

    return NextResponse.json({ conversation });
  } catch (error) {
    console.error("Error creating conversation:", error);
    return NextResponse.json(
      { error: "Falha ao criar conversa" },
      { status: 500 }
    );
  }
}
