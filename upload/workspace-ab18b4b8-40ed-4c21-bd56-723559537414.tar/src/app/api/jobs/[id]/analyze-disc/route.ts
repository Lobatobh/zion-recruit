/**
 * Job DISC Analysis API - Zion Recruit
 * Analyzes a job and generates DISC profile suggestion
 */

import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { parseJob } from "@/lib/agents/specialized/JobParserAgent";

// Helper to get effective tenant ID
async function getEffectiveTenantId(session: { user?: { id?: string; tenantId?: string | null } }): Promise<string | null> {
  // First try session tenantId
  if (session?.user?.tenantId) {
    const tenant = await db.tenant.findUnique({
      where: { id: session.user.tenantId },
    });
    if (tenant) {
      return tenant.id;
    }
  }

  // Fallback: find tenant through membership
  if (session?.user?.id) {
    const membership = await db.tenantMember.findFirst({
      where: { userId: session.user.id },
      include: { tenant: true },
    });
    if (membership) {
      return membership.tenantId;
    }
  }

  // Last resort: get first tenant
  const firstTenant = await db.tenant.findFirst();
  return firstTenant?.id || null;
}

// POST /api/jobs/[id]/analyze-disc
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: "Não autorizado" },
        { status: 401 }
      );
    }

    const effectiveTenantId = await getEffectiveTenantId(session);

    if (!effectiveTenantId) {
      return NextResponse.json(
        { error: "Organização não encontrada" },
        { status: 404 }
      );
    }

    const { id: jobId } = await params;

    // Get job
    const job = await db.job.findFirst({
      where: {
        id: jobId,
        tenantId: effectiveTenantId,
      },
    });

    if (!job) {
      return NextResponse.json(
        { error: "Vaga não encontrada" },
        { status: 404 }
      );
    }

    // Parse job with AI
    const result = await parseJob(
      effectiveTenantId,
      job.id,
      job.title,
      job.description,
      job.requirements
    );

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Falha ao analisar vaga" },
        { status: 500 }
      );
    }

    // Get updated job
    const updatedJob = await db.job.findUnique({
      where: { id: jobId },
      select: {
        id: true,
        discProfileRequired: true,
        discProfileReason: true,
        discIdealCombo: true,
        discIdealRoles: true,
        discWorkEnvironment: true,
        aiParsedSkills: true,
        aiParsedKeywords: true,
        aiParsedSeniority: true,
        aiSummary: true,
      },
    });

    return NextResponse.json({
      success: true,
      job: updatedJob,
      analysis: result.data,
      tokensUsed: result.tokensUsed,
    });
  } catch (error) {
    console.error("Error analyzing job DISC:", error);
    return NextResponse.json(
      { error: "Erro ao analisar vaga" },
      { status: 500 }
    );
  }
}
