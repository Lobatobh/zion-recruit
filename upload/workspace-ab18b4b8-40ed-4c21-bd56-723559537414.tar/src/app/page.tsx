"use client";

import { useState, useEffect, useCallback, Suspense } from "react";
import { signIn, signOut } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  Eye,
  EyeOff,
  Loader2,
  Mail,
  Lock,
  Building2,
  Home as HomeIcon,
  Briefcase,
  Users,
  LayoutGrid,
  Settings,
  Menu,
  ChevronDown,
  LogOut,
  User,
  Bot,
  MessageCircle,
  Brain,
  Key,
  BarChart3,
  FileSearch,
  Webhook,
  Search,
  BookOpen,
  RefreshCw,
  Clock,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  Calendar,
  FileText,
  Target,
  Activity,
} from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ThemeToggle } from "@/components/layout/theme-toggle";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useAuthStore } from "@/stores/auth-store";
import { cn } from "@/lib/utils";

// ============================================
// TYPES
// ============================================

type ViewType = "overview" | "jobs" | "candidates" | "pipeline" | "messages" | "agents" | "disc" | "apis" | "analytics" | "audit" | "webhooks" | "docs" | "disc-test" | "careers" | "sourcing" | "settings";

interface SessionUser {
  id: string;
  email: string;
  name?: string | null;
  image?: string | null;
  tenantSlug?: string | null;
}

interface OverviewStats {
  activeJobs: number;
  totalCandidates: number;
  inProcess: number;
  hiredThisMonth: number;
  previousMonth: {
    activeJobs: number;
    totalCandidates: number;
    inProcess: number;
    hiredThisMonth: number;
  };
}

interface OverviewData {
  stats: OverviewStats;
  recentJobs: Array<{
    id: string;
    title: string;
    department: string;
    candidates: number;
    status: string;
  }>;
  recentCandidates: Array<{
    id: string;
    name: string;
    jobTitle: string;
    stage: string;
    stageColor: string;
    matchScore: number | null;
  }>;
  pipelineStages: Array<{
    id: string;
    name: string;
    color: string;
    count: number;
  }>;
  tenant: {
    id: string;
    name: string;
    plan: string;
  };
}

// ============================================
// LOGIN FORM
// ============================================

const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(1, "Senha é obrigatória"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

function LoginForm({ onLoginSuccess }: { onLoginSuccess: (user: SessionUser) => void }) {
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormValues) => {
    setIsLoading(true);

    try {
      const result = await signIn("credentials", {
        email: data.email,
        password: data.password,
        redirect: false,
      });

      if (result?.error) {
        toast.error("Credenciais inválidas", {
          description: "Verifique seu email e senha e tente novamente.",
        });
      } else {
        toast.success("Login realizado com sucesso!");
        // Fetch session to get user data
        const sessionRes = await fetch("/api/auth/session");
        const session = await sessionRes.json();
        onLoginSuccess(session?.user);
      }
    } catch {
      toast.error("Erro ao fazer login");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      <div className="flex flex-1 flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-20 xl:px-24">
        <div className="mx-auto w-full max-w-sm lg:w-96">
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/80 text-primary-foreground font-bold text-2xl shadow-lg">
              Z
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Zion Recruit
            </span>
          </div>

          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-foreground">Bem-vindo de volta</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Entre com suas credenciais para acessar o sistema
            </p>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          {...field}
                          type="email"
                          placeholder="seu@email.com"
                          className="pl-10"
                          disabled={isLoading}
                        />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Senha</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          {...field}
                          type={showPassword ? "text" : "password"}
                          placeholder="••••••••"
                          className="pl-10 pr-10"
                          disabled={isLoading}
                        />
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                        >
                          {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                        </button>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full" size="lg" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Entrando...
                  </>
                ) : (
                  "Entrar"
                )}
              </Button>
            </form>
          </Form>

          <div className="mt-6 p-4 rounded-lg bg-muted/50 border border-border">
            <p className="text-sm font-medium text-center mb-2">Credenciais de Demo</p>
            <div className="text-xs text-muted-foreground space-y-1 text-center">
              <p>Email: <code className="bg-muted px-1 rounded">admin@zion.demo</code></p>
              <p>Senha: <code className="bg-muted px-1 rounded">password123</code></p>
            </div>
          </div>
        </div>
      </div>

      <div className="relative hidden w-0 flex-1 lg:block">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-primary/80 to-primary/60">
          <div className="relative flex h-full items-center justify-center p-12">
            <div className="max-w-lg text-center text-white">
              <Building2 className="h-16 w-16 mx-auto mb-6 opacity-90" />
              <h2 className="text-3xl font-bold mb-4">Transforme seu Processo de Recrutamento</h2>
              <p className="text-lg opacity-90">
                Inteligência artificial para encontrar os melhores candidatos.
              </p>
              <div className="mt-10 grid grid-cols-2 gap-4 text-left">
                {["Matching Inteligente com IA", "Pipeline Visual", "Multi-organização", "Análise de Currículos"].map((feature) => (
                  <div key={feature} className="flex items-center gap-2">
                    <div className="h-2 w-2 rounded-full bg-white/80" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================
// DASHBOARD CONTENT
// ============================================

function DashboardContent({ user, onSignOut }: { user: SessionUser; onSignOut: () => void }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const currentView = (searchParams.get("view") as ViewType) || "overview";
  const { sidebarCollapsed, setSidebarCollapsed } = useAuthStore();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [overviewData, setOverviewData] = useState<OverviewData | null>(null);
  const [isLoadingOverview, setIsLoadingOverview] = useState(true);

  const fetchOverview = useCallback(async () => {
    setIsLoadingOverview(true);
    try {
      const response = await fetch("/api/overview");
      if (response.ok) {
        const result = await response.json();
        setOverviewData(result);
      }
    } catch (error) {
      console.error("Error fetching overview:", error);
    } finally {
      setIsLoadingOverview(false);
    }
  }, []);

  useEffect(() => {
    fetchOverview();
  }, [fetchOverview]);

  const navigationItems: { name: string; view: ViewType; icon: React.ElementType }[] = [
    { name: "Visão Geral", view: "overview", icon: HomeIcon },
    { name: "Vagas", view: "jobs", icon: Briefcase },
    { name: "Candidatos", view: "candidates", icon: Users },
    { name: "Pipeline", view: "pipeline", icon: LayoutGrid },
    { name: "Mensagens", view: "messages", icon: MessageCircle },
    { name: "Sourcing", view: "sourcing", icon: Search },
    { name: "Agentes IA", view: "agents", icon: Bot },
    { name: "Analytics", view: "analytics", icon: BarChart3 },
    { name: "Audit Logs", view: "audit", icon: FileSearch },
    { name: "Testes DISC", view: "disc", icon: Brain },
    { name: "APIs", view: "apis", icon: Key },
    { name: "Webhooks", view: "webhooks", icon: Webhook },
    { name: "Documentação", view: "docs", icon: BookOpen },
    { name: "Configurações", view: "settings", icon: Settings },
  ];

  const handleNavClick = (view: ViewType) => {
    const url = new URL(window.location.href);
    url.searchParams.set("view", view);
    router.push(url.pathname + url.search);
    setMobileOpen(false);
  };

  const getInitials = (name?: string | null) => {
    if (!name) return "U";
    return name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
  };

  const statsConfig = overviewData ? [
    { title: "Vagas Ativas", value: overviewData.stats.activeJobs, icon: Briefcase, color: "#3B82F6" },
    { title: "Candidatos", value: overviewData.stats.totalCandidates, icon: Users, color: "#10B981" },
    { title: "Em Processo", value: overviewData.stats.inProcess, icon: Clock, color: "#F59E0B" },
    { title: "Contratados", value: overviewData.stats.hiredThisMonth, icon: CheckCircle2, color: "#8B5CF6" },
  ] : [];

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: sidebarCollapsed ? 64 : 240 }}
        transition={{ duration: 0.2, ease: "easeInOut" }}
        className="hidden lg:block relative"
      >
        <div className="flex h-full flex-col bg-sidebar border-r border-sidebar-border">
          <div className={cn("flex h-16 items-center border-b border-sidebar-border px-4", sidebarCollapsed ? "justify-center" : "gap-3")}>
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-lg">
              Z
            </div>
            {!sidebarCollapsed && (
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                Zion Recruit
              </span>
            )}
          </div>

          <ScrollArea className="flex-1 py-4">
            <nav className={cn("space-y-1 px-2", sidebarCollapsed && "flex flex-col items-center")}>
              {navigationItems.map((item) => (
                <button
                  key={item.name}
                  onClick={() => handleNavClick(item.view)}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 w-full text-left",
                    currentView === item.view
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                  )}
                >
                  <item.icon className="h-5 w-5 flex-shrink-0" />
                  {!sidebarCollapsed && <span>{item.name}</span>}
                </button>
              ))}
            </nav>
          </ScrollArea>
        </div>

        <Button
          variant="ghost"
          size="icon"
          className="absolute top-[18px] -right-3 z-50 h-6 w-6 rounded-full border border-border bg-background shadow-sm hover:bg-accent"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
        >
          <ChevronDown className={cn("h-3 w-3 transition-transform", sidebarCollapsed && "rotate-180")} />
        </Button>
      </motion.aside>

      {/* Mobile Sidebar */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="p-0 w-64">
          <SheetHeader className="sr-only">
            <SheetTitle>Navigation Menu</SheetTitle>
          </SheetHeader>
          <div className="flex h-full flex-col bg-sidebar">
            <div className="flex h-16 items-center border-b border-sidebar-border px-4 gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold text-lg">
                Z
              </div>
              <span className="font-bold">Zion Recruit</span>
            </div>
            <ScrollArea className="flex-1 py-4">
              <nav className="space-y-1 px-2">
                {navigationItems.map((item) => (
                  <button
                    key={item.name}
                    onClick={() => handleNavClick(item.view)}
                    className={cn(
                      "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-all duration-200 w-full text-left",
                      currentView === item.view
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                    )}
                  >
                    <item.icon className="h-5 w-5 flex-shrink-0" />
                    <span>{item.name}</span>
                  </button>
                ))}
              </nav>
            </ScrollArea>
          </div>
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Mobile Header */}
        <div className="flex h-16 items-center gap-4 border-b border-border bg-background px-4 lg:hidden">
          <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
          </Sheet>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground font-bold">
              Z
            </div>
            <span className="font-bold">Zion Recruit</span>
          </div>
        </div>

        {/* Desktop Header */}
        <header className="hidden lg:flex sticky top-0 z-50 h-16 items-center justify-between border-b border-border bg-background/95 px-6 backdrop-blur">
          <div className="flex items-center gap-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 text-sm font-medium">
                  <Building2 className="h-4 w-4" />
                  <span>{user?.tenantSlug || "Sem Organização"}</span>
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56">
                <DropdownMenuLabel>Organizações</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Building2 className="mr-2 h-4 w-4" />
                  {user?.tenantSlug || "Demo Organization"}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full">
                  <Avatar className="h-9 w-9">
                    <AvatarFallback>{getInitials(user?.name)}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium">{user?.name}</p>
                    <p className="text-xs text-muted-foreground">{user?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  Perfil
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="mr-2 h-4 w-4" />
                  Configurações
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onSignOut} className="text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  Sair
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="h-full"
          >
            {isLoadingOverview ? (
              <div className="p-6 lg:p-8 space-y-6">
                <Skeleton className="h-20 w-full rounded-xl" />
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  {[...Array(4)].map((_, i) => (
                    <Skeleton key={i} className="h-32 rounded-lg" />
                  ))}
                </div>
              </div>
            ) : !overviewData ? (
              <div className="p-6 lg:p-8 flex items-center justify-center min-h-[400px]">
                <div className="text-center">
                  <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Não foi possível carregar os dados</p>
                  <Button variant="outline" className="mt-4" onClick={fetchOverview}>
                    Tentar novamente
                  </Button>
                </div>
              </div>
            ) : (
              <div className="p-6 lg:p-8 space-y-6 max-w-[1600px] mx-auto">
                {/* Header */}
                <div className="flex items-center justify-between">
                  <div>
                    <h1 className="text-3xl font-bold">Visão Geral</h1>
                    <p className="text-muted-foreground mt-1">
                      Bem-vindo ao {overviewData.tenant?.name || "Zion Recruit"}!
                    </p>
                  </div>
                  <Button variant="outline" onClick={fetchOverview}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Atualizar
                  </Button>
                </div>

                {/* Stats Grid */}
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  {statsConfig.map((stat) => (
                    <Card key={stat.title}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="space-y-2">
                            <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                            <p className="text-3xl font-bold">{stat.value}</p>
                          </div>
                          <div
                            className="flex h-12 w-12 items-center justify-center rounded-xl"
                            style={{ backgroundColor: `${stat.color}15` }}
                          >
                            <stat.icon className="h-6 w-6" style={{ color: stat.color }} />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Ações Rápidas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
                      {[
                        { label: "Nova Vaga", icon: Briefcase, view: "jobs" as ViewType },
                        { label: "Candidatos", icon: Users, view: "candidates" as ViewType },
                        { label: "Pipeline", icon: Activity, view: "pipeline" as ViewType },
                        { label: "Entrevistas", icon: Calendar, view: "jobs" as ViewType },
                        { label: "Relatórios", icon: FileText, view: "analytics" as ViewType },
                        { label: "Analytics", icon: Target, view: "analytics" as ViewType },
                      ].map((action, i) => (
                        <Button
                          key={i}
                          variant="outline"
                          className="h-auto flex-col gap-2 p-4"
                          onClick={() => handleNavClick(action.view)}
                        >
                          <action.icon className="h-5 w-5 text-muted-foreground" />
                          <span className="text-xs">{action.label}</span>
                        </Button>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Jobs */}
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <CardTitle>Vagas Recentes</CardTitle>
                    <Button variant="ghost" size="sm" onClick={() => handleNavClick("jobs")}>
                      Ver todas →
                    </Button>
                  </CardHeader>
                  <CardContent>
                    {overviewData.recentJobs.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Briefcase className="h-10 w-10 mx-auto mb-3 opacity-50" />
                        <p>Nenhuma vaga cadastrada</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {overviewData.recentJobs.slice(0, 5).map((job) => (
                          <div key={job.id} className="flex items-center justify-between p-3 rounded-lg border hover:bg-accent/50 cursor-pointer transition-colors">
                            <div>
                              <p className="font-medium">{job.title}</p>
                              <p className="text-sm text-muted-foreground">{job.department}</p>
                            </div>
                            <div className="text-right">
                              <Badge variant={job.status === "PUBLISHED" ? "default" : "secondary"}>
                                {job.status === "PUBLISHED" ? "Publicada" : "Rascunho"}
                              </Badge>
                              <p className="text-sm text-muted-foreground mt-1">{job.candidates} candidatos</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            )}
          </motion.div>
        </main>
      </div>
    </div>
  );
}

// ============================================
// MAIN PAGE COMPONENT
// ============================================

function PageContentInner() {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const checkSession = async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        const response = await fetch("/api/auth/session", {
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        
        if (mounted && response.ok) {
          const data = await response.json();
          setUser(data?.user || null);
        }
      } catch {
        if (mounted) {
          setUser(null);
        }
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    checkSession();

    return () => {
      mounted = false;
    };
  }, []);

  const handleSignOut = async () => {
    await signOut({ redirect: false });
    setUser(null);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center p-8">
          <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/80 text-primary-foreground font-bold text-3xl shadow-lg mx-auto mb-6">
            Z
          </div>
          <h1 className="text-2xl font-bold mb-2">Zion Recruit</h1>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (user) {
    return <DashboardContent user={user} onSignOut={handleSignOut} />;
  }

  return <LoginForm onLoginSuccess={setUser} />;
}

// ============================================
// EXPORT
// ============================================

export default function Page() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center p-8">
          <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/80 text-primary-foreground font-bold text-3xl shadow-lg mx-auto mb-6">
            Z
          </div>
          <h1 className="text-2xl font-bold mb-2">Zion Recruit</h1>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    }>
      <PageContentInner />
    </Suspense>
  );
}
