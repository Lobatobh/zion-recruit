/**
 * Middleware - Zion Recruit
 * Simplified for development
 */

import { NextRequest, NextResponse } from "next/server";

/**
 * Main middleware function
 */
export async function middleware(request: NextRequest): Promise<NextResponse> {
  // Just pass through all requests
  return NextResponse.next();
}

/**
 * Configure which paths the middleware should run on
 */
export const config = {
  matcher: [
    // Match specific API routes that need rate limiting
    "/api/jobs/:path*",
    "/api/candidates/:path*",
    "/api/agents/:path*",
    "/api/ai/:path*",
    "/api/screening/:path*",
    "/api/matching/:path*",
    "/api/sourcing/:path*",
  ],
};
