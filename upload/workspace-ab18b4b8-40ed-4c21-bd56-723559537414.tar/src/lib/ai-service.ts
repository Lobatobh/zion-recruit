/**
 * AI Service - Zion Recruit
 * Handles LLM calls using z-ai-web-dev-sdk
 * Optimized for low token cost with concise prompts and JSON output
 */

import ZAI from 'z-ai-web-dev-sdk';

// Singleton for ZAI instance
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export interface AIResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  cached?: boolean;
}

export interface ParsedResume {
  name: string;
  email: string;
  phone?: string;
  skills: string[];
  experience: Array<{
    company: string;
    title: string;
    startDate?: string;
    endDate?: string;
    years?: number;
  }>;
  education: Array<{
    institution: string;
    degree: string;
    year?: string;
  }>;
  languages: string[];
  summary: string;
}

export interface MatchScoreResult {
  skillsScore: number;
  experienceScore: number;
  educationScore: number;
  overallScore: number;
  reasons: string[];
  strengths: string[];
  gaps: string[];
}

/**
 * Call LLM with structured JSON output
 */
export async function callLLM<T>(
  systemPrompt: string,
  userPrompt: string,
  options?: {
    maxTokens?: number;
    temperature?: number;
  }
): Promise<AIResponse<T>> {
  try {
    const zai = await getZAI();
    
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      max_tokens: options?.maxTokens || 500,
      temperature: options?.temperature || 0.3
    });

    const content = completion.choices[0]?.message?.content;
    
    if (!content) {
      return { success: false, error: 'No response from AI' };
    }

    // Parse JSON from response
    try {
      // Handle potential markdown code blocks
      let jsonStr = content.trim();
      if (jsonStr.startsWith('```json')) {
        jsonStr = jsonStr.slice(7);
      }
      if (jsonStr.startsWith('```')) {
        jsonStr = jsonStr.slice(3);
      }
      if (jsonStr.endsWith('```')) {
        jsonStr = jsonStr.slice(0, -3);
      }
      jsonStr = jsonStr.trim();
      
      const data = JSON.parse(jsonStr) as T;
      return { success: true, data };
    } catch {
      // If not JSON, return raw content
      return { success: false, error: 'Failed to parse AI response as JSON' };
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return { success: false, error: message };
  }
}

/**
 * Parse resume text with AI
 */
export async function parseResumeWithAI(resumeText: string): Promise<AIResponse<ParsedResume>> {
  const systemPrompt = 'Extract resume data. Return JSON only.';
  
  const userPrompt = `Extract from resume:
- name, email, phone
- skills (array of strings)
- experience (array: company, title, startDate, endDate, years number)
- education (array: institution, degree, year)
- languages (array of strings)
- summary (2 sentences max)

Return JSON only. No markdown.
Resume: ${resumeText.slice(0, 3000)}`;

  return callLLM<ParsedResume>(systemPrompt, userPrompt, { maxTokens: 600 });
}

/**
 * Calculate match score with AI
 */
export async function calculateMatchWithAI(
  candidate: {
    skills: string[];
    experience: Array<{ years?: number; title?: string }>;
    education: Array<{ degree: string }>;
    summary?: string;
  },
  jobRequirements: {
    skills?: string[];
    experienceYears?: number;
    educationLevel?: string;
    description?: string;
  }
): Promise<AIResponse<MatchScoreResult>> {
  const systemPrompt = 'Score candidate-job match. Return JSON only.';
  
  const userPrompt = `Compare candidate to job. Score 0-100 each:
- skillsScore: match between candidate skills and required skills
- experienceScore: candidate experience vs required years
- educationScore: candidate degree vs required level
- overallScore: weighted average

Also provide:
- reasons: array of 2-3 main reasons for the score
- strengths: array of 1-2 candidate strengths
- gaps: array of 1-2 missing qualifications

Candidate:
Skills: ${candidate.skills.join(', ') || 'None'}
Experience: ${candidate.experience.length} roles
Education: ${candidate.education.map(e => e.degree).join(', ') || 'None'}
${candidate.summary ? `Summary: ${candidate.summary}` : ''}

Job Requirements:
Skills: ${jobRequirements.skills?.join(', ') || 'Not specified'}
Experience: ${jobRequirements.experienceYears || 0} years required
Education: ${jobRequirements.educationLevel || 'Not specified'}

Return JSON: {skillsScore, experienceScore, educationScore, overallScore, reasons, strengths, gaps}`;

  return callLLM<MatchScoreResult>(systemPrompt, userPrompt, { maxTokens: 400 });
}

/**
 * Generate candidate summary with AI
 */
export async function generateSummaryWithAI(
  skills: string[],
  experience: Array<{ title?: string; company?: string }>,
  education: Array<{ degree: string }>
): Promise<AIResponse<string>> {
  const systemPrompt = 'Generate professional summary. Return plain text only.';
  
  const userPrompt = `Write 2-sentence professional summary for:
Skills: ${skills.slice(0, 5).join(', ')}
Experience: ${experience.slice(0, 3).map(e => e.title).join(', ')}
Education: ${education[0]?.degree || 'Not specified'}

Keep it concise and professional. No markdown.`;

  try {
    const zai = await getZAI();
    
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      max_tokens: 100,
      temperature: 0.5
    });

    const content = completion.choices[0]?.message?.content?.trim();
    
    if (!content) {
      return { success: false, error: 'No summary generated' };
    }

    return { success: true, data: content };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return { success: false, error: message };
  }
}
