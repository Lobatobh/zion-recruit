/**
 * DISC Questions Data - Zion Recruit
 * 
 * 28 questions for DISC behavioral assessment
 * Each question has 4 options corresponding to D, I, S, C factors
 * User selects "Most like me" and "Least like me" for each question
 */

export type DISCFactor = 'D' | 'I' | 'S' | 'C';

export interface DISCQuestionOption {
  id: string;
  text: string;
  factor: DISCFactor;
}

export interface DISCQuestion {
  number: number;
  options: DISCQuestionOption[];
}

export const DISC_QUESTIONS: DISCQuestion[] = [
  {
    number: 1,
    options: [
      { id: '1a', text: 'I take charge and make decisions quickly', factor: 'D' },
      { id: '1b', text: 'I enjoy meeting new people and networking', factor: 'I' },
      { id: '1c', text: 'I prefer a stable and predictable environment', factor: 'S' },
      { id: '1d', text: 'I focus on details and accuracy in my work', factor: 'C' },
    ],
  },
  {
    number: 2,
    options: [
      { id: '2a', text: 'I am competitive and like to win', factor: 'D' },
      { id: '2b', text: 'I am enthusiastic and optimistic', factor: 'I' },
      { id: '2c', text: 'I am patient and a good listener', factor: 'S' },
      { id: '2d', text: 'I am systematic and follow procedures', factor: 'C' },
    ],
  },
  {
    number: 3,
    options: [
      { id: '3a', text: 'I delegate tasks and expect results', factor: 'D' },
      { id: '3b', text: 'I motivate others with my energy', factor: 'I' },
      { id: '3c', text: 'I support team members consistently', factor: 'S' },
      { id: '3d', text: 'I analyze problems before acting', factor: 'C' },
    ],
  },
  {
    number: 4,
    options: [
      { id: '4a', text: 'I am direct and to the point', factor: 'D' },
      { id: '4b', text: 'I am talkative and expressive', factor: 'I' },
      { id: '4c', text: 'I am calm and even-tempered', factor: 'S' },
      { id: '4d', text: 'I am precise and exacting', factor: 'C' },
    ],
  },
  {
    number: 5,
    options: [
      { id: '5a', text: 'I tackle challenges head-on', factor: 'D' },
      { id: '5b', text: 'I build relationships easily', factor: 'I' },
      { id: '5c', text: 'I maintain harmony in groups', factor: 'S' },
      { id: '5d', text: 'I ensure quality in deliverables', factor: 'C' },
    ],
  },
  {
    number: 6,
    options: [
      { id: '6a', text: 'I prefer to lead rather than follow', factor: 'D' },
      { id: '6b', text: 'I like being the center of attention', factor: 'I' },
      { id: '6c', text: 'I avoid conflict when possible', factor: 'S' },
      { id: '6d', text: 'I prefer written communication', factor: 'C' },
    ],
  },
  {
    number: 7,
    options: [
      { id: '7a', text: 'I set ambitious goals for myself', factor: 'D' },
      { id: '7b', text: 'I am spontaneous and flexible', factor: 'I' },
      { id: '7c', text: 'I am loyal and dependable', factor: 'S' },
      { id: '7d', text: 'I research thoroughly before deciding', factor: 'C' },
    ],
  },
  {
    number: 8,
    options: [
      { id: '8a', text: 'I get impatient with slow progress', factor: 'D' },
      { id: '8b', text: 'I sometimes overlook details', factor: 'I' },
      { id: '8c', text: 'I struggle with sudden changes', factor: 'S' },
      { id: '8d', text: 'I can be overly critical', factor: 'C' },
    ],
  },
  {
    number: 9,
    options: [
      { id: '9a', text: 'I make decisions based on results', factor: 'D' },
      { id: '9b', text: 'I make decisions based on intuition', factor: 'I' },
      { id: '9c', text: 'I make decisions based on consensus', factor: 'S' },
      { id: '9d', text: 'I make decisions based on data', factor: 'C' },
    ],
  },
  {
    number: 10,
    options: [
      { id: '10a', text: 'I am driven by achievement', factor: 'D' },
      { id: '10b', text: 'I am driven by recognition', factor: 'I' },
      { id: '10c', text: 'I am driven by security', factor: 'S' },
      { id: '10d', text: 'I am driven by accuracy', factor: 'C' },
    ],
  },
  {
    number: 11,
    options: [
      { id: '11a', text: 'I thrive under pressure', factor: 'D' },
      { id: '11b', text: 'I bring energy to teams', factor: 'I' },
      { id: '11c', text: 'I create a supportive atmosphere', factor: 'S' },
      { id: '11d', text: 'I maintain high standards', factor: 'C' },
    ],
  },
  {
    number: 12,
    options: [
      { id: '12a', text: 'I value efficiency over perfection', factor: 'D' },
      { id: '12b', text: 'I value relationships over tasks', factor: 'I' },
      { id: '12c', text: 'I value stability over change', factor: 'S' },
      { id: '12d', text: 'I value correctness over speed', factor: 'C' },
    ],
  },
  {
    number: 13,
    options: [
      { id: '13a', text: 'I take risks when necessary', factor: 'D' },
      { id: '13b', text: 'I inspire others with my vision', factor: 'I' },
      { id: '13c', text: 'I adapt to others\' needs', factor: 'S' },
      { id: '13d', text: 'I follow established protocols', factor: 'C' },
    ],
  },
  {
    number: 14,
    options: [
      { id: '14a', text: 'I confront problems directly', factor: 'D' },
      { id: '14b', text: 'I use humor to ease tension', factor: 'I' },
      { id: '14c', text: 'I seek compromise in conflicts', factor: 'S' },
      { id: '14d', text: 'I rely on facts in disagreements', factor: 'C' },
    ],
  },
  {
    number: 15,
    options: [
      { id: '15a', text: 'I focus on bottom-line results', factor: 'D' },
      { id: '15b', text: 'I focus on team morale', factor: 'I' },
      { id: '15c', text: 'I focus on team cohesion', factor: 'S' },
      { id: '15d', text: 'I focus on process improvement', factor: 'C' },
    ],
  },
  {
    number: 16,
    options: [
      { id: '16a', text: 'I prefer short, focused meetings', factor: 'D' },
      { id: '16b', text: 'I enjoy brainstorming sessions', factor: 'I' },
      { id: '16c', text: 'I prefer structured, planned meetings', factor: 'S' },
      { id: '16d', text: 'I need agenda and minutes', factor: 'C' },
    ],
  },
  {
    number: 17,
    options: [
      { id: '17a', text: 'I am assertive in expressing opinions', factor: 'D' },
      { id: '17b', text: 'I am persuasive in discussions', factor: 'I' },
      { id: '17c', text: 'I am diplomatic in communication', factor: 'S' },
      { id: '17d', text: 'I am factual in presentations', factor: 'C' },
    ],
  },
  {
    number: 18,
    options: [
      { id: '18a', text: 'I move quickly between tasks', factor: 'D' },
      { id: '18b', text: 'I juggle multiple social interactions', factor: 'I' },
      { id: '18c', text: 'I finish one task before starting another', factor: 'S' },
      { id: '18d', text: 'I organize tasks systematically', factor: 'C' },
    ],
  },
  {
    number: 19,
    options: [
      { id: '19a', text: 'I accept criticism as a challenge', factor: 'D' },
      { id: '19b', text: 'I take criticism personally', factor: 'I' },
      { id: '19c', text: 'I appreciate constructive feedback', factor: 'S' },
      { id: '19d', text: 'I analyze criticism objectively', factor: 'C' },
    ],
  },
  {
    number: 20,
    options: [
      { id: '20a', text: 'I prefer varied and challenging work', factor: 'D' },
      { id: '20b', text: 'I prefer work with social interaction', factor: 'I' },
      { id: '20c', text: 'I prefer consistent and routine work', factor: 'S' },
      { id: '20d', text: 'I prefer work requiring precision', factor: 'C' },
    ],
  },
  {
    number: 21,
    options: [
      { id: '21a', text: 'I make quick decisions with limited info', factor: 'D' },
      { id: '21b', text: 'I trust my gut feelings', factor: 'I' },
      { id: '21c', text: 'I consult others before deciding', factor: 'S' },
      { id: '21d', text: 'I need all facts before deciding', factor: 'C' },
    ],
  },
  {
    number: 22,
    options: [
      { id: '22a', text: 'I am comfortable with authority', factor: 'D' },
      { id: '22b', text: 'I am approachable and friendly', factor: 'I' },
      { id: '22c', text: 'I am cooperative and helpful', factor: 'S' },
      { id: '22d', text: 'I am accurate and thorough', factor: 'C' },
    ],
  },
  {
    number: 23,
    options: [
      { id: '23a', text: 'I challenge the status quo', factor: 'D' },
      { id: '23b', text: 'I bring fresh perspectives', factor: 'I' },
      { id: '23c', text: 'I preserve what works well', factor: 'S' },
      { id: '23d', text: 'I ensure compliance with standards', factor: 'C' },
    ],
  },
  {
    number: 24,
    options: [
      { id: '24a', text: 'I can be seen as demanding', factor: 'D' },
      { id: '24b', text: 'I can be seen as disorganized', factor: 'I' },
      { id: '24c', text: 'I can be seen as too accommodating', factor: 'S' },
      { id: '24d', text: 'I can be seen as perfectionist', factor: 'C' },
    ],
  },
  {
    number: 25,
    options: [
      { id: '25a', text: 'I inspire others to take action', factor: 'D' },
      { id: '25b', text: 'I create excitement and enthusiasm', factor: 'I' },
      { id: '25c', text: 'I provide steady support', factor: 'S' },
      { id: '25d', text: 'I ensure nothing is overlooked', factor: 'C' },
    ],
  },
  {
    number: 26,
    options: [
      { id: '26a', text: 'I focus on opportunities', factor: 'D' },
      { id: '26b', text: 'I focus on possibilities', factor: 'I' },
      { id: '26c', text: 'I focus on relationships', factor: 'S' },
      { id: '26d', text: 'I focus on potential problems', factor: 'C' },
    ],
  },
  {
    number: 27,
    options: [
      { id: '27a', text: 'I work well independently', factor: 'D' },
      { id: '27b', text: 'I thrive in collaborative settings', factor: 'I' },
      { id: '27c', text: 'I prefer small, close-knit teams', factor: 'S' },
      { id: '27d', text: 'I work well with clear guidelines', factor: 'C' },
    ],
  },
  {
    number: 28,
    options: [
      { id: '28a', text: 'I deliver results under tight deadlines', factor: 'D' },
      { id: '28b', text: 'I maintain team spirit under pressure', factor: 'I' },
      { id: '28c', text: 'I provide stability during change', factor: 'S' },
      { id: '28d', text: 'I maintain accuracy under pressure', factor: 'C' },
    ],
  },
];

export const TOTAL_QUESTIONS = DISC_QUESTIONS.length;

/**
 * Get a question by its number
 */
export function getQuestionByNumber(number: number): DISCQuestion | undefined {
  return DISC_QUESTIONS.find(q => q.number === number);
}

/**
 * Get the factor for a specific option
 */
export function getOptionFactor(questionNumber: number, optionId: string): DISCFactor | undefined {
  const question = getQuestionByNumber(questionNumber);
  if (!question) return undefined;
  
  const option = question.options.find(o => o.id === optionId);
  return option?.factor;
}
