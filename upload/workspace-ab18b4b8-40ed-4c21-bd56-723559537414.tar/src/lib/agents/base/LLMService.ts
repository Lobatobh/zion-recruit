/**
 * LLM Service - Zion Recruit
 * Optimized for LOW TOKEN COST
 * 
 * Key optimizations:
 * 1. Use smallest capable model (gpt-4o-mini)
 * 2. Concise prompts (no fluff)
 * 3. Structured JSON output
 * 4. Caching when possible
 */

import ZAI from 'z-ai-web-dev-sdk';
import crypto from 'crypto';

// ============================================
// Types
// ============================================

export interface LLMRequest {
  systemPrompt: string;
  userPrompt: string;
  maxTokens?: number;
  temperature?: number;
  model?: string;
  jsonMode?: boolean;
}

export interface LLMResponse<T = unknown> {
  success: boolean;
  data?: T;
  rawContent?: string;
  tokensUsed?: number;
  cached?: boolean;
  error?: string;
}

export interface CacheOptions {
  enabled?: boolean;
  ttlDays?: number;
  tenantId?: string;
  cacheKey?: string;
}

// ============================================
// LLM Service Class
// ============================================

class LLMService {
  private zai: Awaited<ReturnType<typeof ZAI.create>> | null = null;
  private cache: Map<string, { data: unknown; expiresAt: number }> = new Map();
  
  private async getClient() {
    if (!this.zai) {
      this.zai = await ZAI.create();
    }
    return this.zai;
  }

  // ============================================
  // Main Call Method
  // ============================================

  async call<T = unknown>(
    request: LLMRequest,
    cache?: CacheOptions
  ): Promise<LLMResponse<T>> {
    const {
      systemPrompt,
      userPrompt,
      maxTokens = 500,
      temperature = 0.3,
      model = 'gpt-4o-mini',
      jsonMode = true,
    } = request;

    // Check cache first
    if (cache?.enabled && cache.cacheKey) {
      const cached = this.getFromCache(cache.cacheKey);
      if (cached) {
        return {
          success: true,
          data: cached as T,
          cached: true,
        };
      }
    }

    try {
      const client = await this.getClient();
      
      const completion = await client.chat.completions.create({
        model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        max_tokens: maxTokens,
        temperature,
      });

      const content = completion.choices[0]?.message?.content;
      const tokensUsed = completion.usage?.total_tokens;

      if (!content) {
        return { success: false, error: 'No response from LLM' };
      }

      // Parse JSON if needed
      let data: T | undefined;
      if (jsonMode) {
        try {
          data = this.parseJsonSafe<T>(content);
          if (!data) {
            return {
              success: false,
              error: 'Failed to parse JSON response',
              rawContent: content,
            };
          }
        } catch (e) {
          return {
            success: false,
            error: `JSON parse error: ${e}`,
            rawContent: content,
          };
        }
      }

      // Save to cache
      if (cache?.enabled && cache.cacheKey && data) {
        this.saveToCache(cache.cacheKey, data, (cache.ttlDays || 7) * 24 * 60 * 60 * 1000);
      }

      return {
        success: true,
        data,
        rawContent: content,
        tokensUsed,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      return { success: false, error: message };
    }
  }

  // ============================================
  // Optimized Prompt Helpers
  // ============================================

  createJobParsingPrompt(description: string): { system: string; user: string } {
    return {
      system: 'Extract job info. Return JSON only.',
      user: `Job: ${this.truncate(description, 1500)}
Return JSON:
{"skills":["..."],"seniority":"...","keywords":["..."],"discProfile":{"D":0-100,"I":0-100,"S":0-100,"C":0-100},"summary":"..."}`,
    };
  }

  createResumeParsingPrompt(resume: string): { system: string; user: string } {
    return {
      system: 'Extract resume info. Return JSON only.',
      user: `Resume: ${this.truncate(resume, 2000)}
Return JSON:
{"name":"...","email":"...","phone":"...","skills":["..."],"experience":[{"title":"...","company":"...","years":N}],"education":[{"degree":"...","institution":"..."}],"summary":"..."}`,
    };
  }

  createMatchingPrompt(
    candidateSummary: string,
    jobRequirements: string
  ): { system: string; user: string } {
    return {
      system: 'Score candidate-job match. Return JSON only.',
      user: `Candidate: ${this.truncate(candidateSummary, 500)}
Job: ${this.truncate(jobRequirements, 500)}
Return JSON:
{"overallScore":0-100,"skillsScore":0-100,"experienceScore":0-100,"strengths":["..."],"gaps":["..."],"recommendation":"..."}`,
    };
  }

  createDISCAnalysisPrompt(
    d: number,
    i: number,
    s: number,
    c: number,
    jobContext?: string
  ): { system: string; user: string } {
    return {
      system: 'Analyze DISC profile. Return JSON only.',
      user: `DISC: D=${d}, I=${i}, S=${s}, C=${c}
${jobContext ? `Job: ${this.truncate(jobContext, 300)}` : ''}
Return JSON:
{"primaryProfile":"D/I/S/C","strengths":["..."],"workStyle":"...","communication":"...","leadership":"..."}`,
    };
  }

  createContactMessagePrompt(
    candidateName: string,
    jobTitle: string,
    companyName: string
  ): { system: string; user: string } {
    return {
      system: 'Write recruiting message in Portuguese. Return JSON only.',
      user: `Candidate: ${candidateName}
Job: ${jobTitle}
Company: ${companyName}
Return JSON:
{"subject":"...","body":"..."}`,
    };
  }

  // ============================================
  // Caching (In-Memory)
  // ============================================

  private generateCacheKey(input: string): string {
    return crypto.createHash('sha256').update(input).digest('hex');
  }

  private getFromCache(key: string): unknown | null {
    const cached = this.cache.get(key);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.data;
    }
    if (cached) {
      this.cache.delete(key);
    }
    return null;
  }

  private saveToCache(key: string, data: unknown, ttlMs: number): void {
    this.cache.set(key, {
      data,
      expiresAt: Date.now() + ttlMs,
    });
  }

  // ============================================
  // Utility Methods
  // ============================================

  private truncate(text: string, maxLength: number): string {
    if (text.length <= maxLength) return text;
    return text.slice(0, maxLength - 3) + '...';
  }

  private parseJsonSafe<T>(text: string): T | null {
    try {
      let clean = text.trim();
      if (clean.startsWith('```json')) clean = clean.slice(7);
      if (clean.startsWith('```')) clean = clean.slice(3);
      if (clean.endsWith('```')) clean = clean.slice(0, -3);
      clean = clean.trim();
      return JSON.parse(clean) as T;
    } catch {
      return null;
    }
  }

  estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  fitsInTokens(text: string, maxTokens: number): boolean {
    return this.estimateTokens(text) <= maxTokens;
  }
}

// Export singleton instance
export const llmService = new LLMService();

// Export convenience functions
export const callLLM = llmService.call.bind(llmService);
export const estimateTokens = llmService.estimateTokens.bind(llmService);
