/**
 * DISC Analyzer Agent - Zion Recruit
 * 
 * Specialized agent that:
 * - Analyzes DISC test results
 * - Generates AI-powered insights
 * - Calculates job fit scores
 * - Identifies strengths and work style
 * 
 * Token optimization:
 * - Structured output
 * - Concise analysis
 * - Cached interpretations
 */

import { BaseAgent, AgentConfig, TaskInput, TaskResult, TaskOutput } from '../base/BaseAgent';
import { llmService } from '../base/LLMService';
import { AgentType } from '@prisma/client';
import { db } from '@/lib/db';
import { DISCFactor } from '@/lib/disc/questions';
import { calculateJobFit } from '@/lib/disc/calculator';
import { getProfileDescription, getComboProfile } from '@/lib/disc/profiles';

// ============================================
// Types
// ============================================

interface DISCAnalysisInput {
  testId: string;
  jobContext?: string;
  jobProfileRequirements?: { D: number; I: number; S: number; C: number };
}

interface DISCAnalysisOutput extends TaskOutput {
  primaryProfile: DISCFactor;
  secondaryProfile: DISCFactor | null;
  profileCombo: string;
  profileName: string;
  strengths: string[];
  areasForDevelopment: string[];
  workStyle: string;
  communicationTips: string;
  leadershipStyle: string;
  idealEnvironment: string[];
  jobFitScore: number;
  jobFitDetails: string;
  aiInsights: string;
}

// ============================================
// Agent Configuration
// ============================================

const DISC_ANALYZER_CONFIG: AgentConfig = {
  type: AgentType.DISC_ANALYZER,
  name: 'DISC Analyzer Agent',
  description: 'Analisa resultados de testes DISC e gera insights',
  model: 'gpt-4o-mini',
  maxTokens: 800,
  temperature: 0.3,
  systemPrompt: 'Analise perfil DISC. Retorne insights em JSON. Seja conciso e específico.',
};

// ============================================
// DISC Analyzer Agent Class
// ============================================

export class DISCAnalyzerAgent extends BaseAgent {
  constructor(tenantId: string) {
    super(tenantId, DISC_ANALYZER_CONFIG);
  }

  async execute(input: TaskInput): Promise<TaskResult<DISCAnalysisOutput>> {
    const { testId, jobContext, jobProfileRequirements } = input as DISCAnalysisInput;

    // Get test data
    const test = await db.dISTest.findUnique({
      where: { id: testId },
      include: {
        candidate: {
          select: {
            name: true,
            job: {
              select: {
                title: true,
                discProfileRequired: true,
              },
            },
          },
        },
      },
    });

    if (!test) {
      return { success: false, error: 'Teste DISC não encontrado' };
    }

    // Get DISC scores
    const scores = {
      D: test.profileD || 0,
      I: test.profileI || 0,
      S: test.profileS || 0,
      C: test.profileC || 0,
    };

    // Get profile descriptions
    const primaryProfile = test.primaryProfile as DISCFactor;
    const secondaryProfile = test.secondaryProfile as DISCFactor | null;
    const profileCombo = test.profileCombo || primaryProfile;

    const primaryDesc = getProfileDescription(primaryProfile);
    const comboDesc = getComboProfile(profileCombo);

    // Calculate job fit
    let jobFitScore = 0;
    let jobFitDetails = '';

    if (jobProfileRequirements) {
      const fit = calculateJobFit(
        scores,
        jobProfileRequirements
      );
      jobFitScore = fit.score;
      jobFitDetails = fit.details;
    } else if (test.candidate.job.discProfileRequired) {
      try {
        const required = JSON.parse(test.candidate.job.discProfileRequired);
        const fit = calculateJobFit(scores, required);
        jobFitScore = fit.score;
        jobFitDetails = fit.details;
      } catch {
        // Invalid JSON, skip job fit calculation
      }
    }

    // Build analysis prompt
    const prompt = this.buildAnalysisPrompt(
      scores,
      primaryProfile,
      secondaryProfile,
      test.candidate.name,
      jobContext || test.candidate.job.title
    );

    // Get AI analysis
    const response = await llmService.call<{
      strengths: string[];
      areasForDevelopment: string[];
      workStyle: string;
      communicationTips: string;
      leadershipStyle: string;
      idealEnvironment: string[];
      insights: string;
    }>(
      {
        systemPrompt: DISC_ANALYZER_CONFIG.systemPrompt!,
        userPrompt: prompt,
        maxTokens: 800,
        temperature: 0.3,
        model: 'gpt-4o-mini',
        jsonMode: true,
      },
      {
        enabled: true,
        tenantId: this.tenantId,
        cacheKey: `disc_analysis_${testId}_${profileCombo}`,
        ttlDays: 30,
      }
    );

    if (!response.success || !response.data) {
      // Fallback to static analysis if AI fails
      return this.getStaticAnalysis(
        test,
        primaryDesc,
        comboDesc,
        jobFitScore,
        jobFitDetails
      );
    }

    // Update test with analysis
    await db.dISTest.update({
      where: { id: testId },
      data: {
        aiAnalysis: response.data.insights,
        aiStrengths: JSON.stringify(response.data.strengths),
        aiWeaknesses: JSON.stringify(response.data.areasForDevelopment),
        aiWorkStyle: response.data.workStyle,
        jobFitScore,
        jobFitDetails,
      },
    });

    return {
      success: true,
      data: {
        primaryProfile,
        secondaryProfile,
        profileCombo,
        profileName: comboDesc?.name || primaryDesc.title,
        strengths: response.data.strengths,
        areasForDevelopment: response.data.areasForDevelopment,
        workStyle: response.data.workStyle,
        communicationTips: response.data.communicationTips,
        leadershipStyle: response.data.leadershipStyle,
        idealEnvironment: response.data.idealEnvironment,
        jobFitScore,
        jobFitDetails,
        aiInsights: response.data.insights,
      },
      tokensUsed: response.tokensUsed,
    };
  }

  private buildAnalysisPrompt(
    scores: { D: number; I: number; S: number; C: number },
    primary: DISCFactor,
    secondary: DISCFactor | null,
    candidateName: string,
    jobContext: string
  ): string {
    return `DISC Scores (0-100): D=${scores.D}, I=${scores.I}, S=${scores.S}, C=${scores.C}
Primary: ${primary}${secondary ? `, Secondary: ${secondary}` : ''}
Candidate: ${candidateName}
Job: ${jobContext}

Return JSON:
{
  "strengths": ["strength1", "strength2", "strength3"],
  "areasForDevelopment": ["area1", "area2"],
  "workStyle": "Brief description",
  "communicationTips": "Tips for communicating",
  "leadershipStyle": "Leadership approach",
  "idealEnvironment": ["env1", "env2"],
  "insights": "Key insight in 1-2 sentences"
}`;
  }

  private getStaticAnalysis(
    test: {
      id: string;
      primaryProfile: string | null;
      secondaryProfile: string | null;
      profileCombo: string | null;
      candidate: { name: string; job: { title: string } };
    },
    primaryDesc: ReturnType<typeof getProfileDescription>,
    comboDesc: ReturnType<typeof getComboProfile>,
    jobFitScore: number,
    jobFitDetails: string
  ): TaskResult<DISCAnalysisOutput> {
    const primary = test.primaryProfile as DISCFactor;
    const secondary = test.secondaryProfile as DISCFactor | null;

    return {
      success: true,
      data: {
        primaryProfile: primary,
        secondaryProfile: secondary,
        profileCombo: test.profileCombo || primary,
        profileName: comboDesc?.name || primaryDesc.title,
        strengths: primaryDesc.strengths.slice(0, 5),
        areasForDevelopment: primaryDesc.weaknesses.slice(0, 3),
        workStyle: primaryDesc.communicationStyle,
        communicationTips: primaryDesc.communicationStyle,
        leadershipStyle: primaryDesc.leadershipStyle,
        idealEnvironment: primaryDesc.idealEnvironment,
        jobFitScore,
        jobFitDetails,
        aiInsights: `${primaryDesc.name} profile: ${primaryDesc.description.slice(0, 150)}...`,
      },
    };
  }
}

// ============================================
// Convenience Functions
// ============================================

export async function analyzeDISCResult(
  tenantId: string,
  testId: string,
  jobContext?: string,
  jobProfileRequirements?: { D: number; I: number; S: number; C: number }
): Promise<TaskResult<DISCAnalysisOutput>> {
  const agent = new DISCAnalyzerAgent(tenantId);
  await agent.initialize();
  
  return agent.execute({ testId, jobContext, jobProfileRequirements });
}

/**
 * Get a quick DISC interpretation without AI
 */
export function getQuickDISCInterpretation(
  primaryProfile: DISCFactor,
  secondaryProfile: DISCFactor | null
): {
  profileName: string;
  summary: string;
  keyStrengths: string[];
} {
  const primaryDesc = getProfileDescription(primaryProfile);
  const comboCode = secondaryProfile 
    ? [primaryProfile, secondaryProfile].sort().join('') 
    : primaryProfile;
  const comboDesc = getComboProfile(comboCode);

  return {
    profileName: comboDesc?.name || primaryDesc.title,
    summary: primaryDesc.description,
    keyStrengths: primaryDesc.strengths.slice(0, 3),
  };
}
