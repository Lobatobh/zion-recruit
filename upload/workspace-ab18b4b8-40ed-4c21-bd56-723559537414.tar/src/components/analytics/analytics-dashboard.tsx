"use client";

import * as React from "react";
import { DateRange } from "react-day-picker";
import { subDays } from "date-fns";
import { DateRangePicker } from "./date-range-picker";
import { ExportButton } from "./export-button";
import { OverviewCards } from "./overview-cards";
import { PipelineFunnel } from "./pipeline-funnel";
import { SourceChart } from "./source-chart";
import { TimeToHireChart } from "./time-to-hire-chart";
import { AgentPerformanceChart } from "./agent-performance-chart";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BarChart3,
  TrendingUp,
  Users,
  Bot,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface AnalyticsDashboardProps {
  tenantId?: string;
}

export function AnalyticsDashboard({ tenantId = "demo" }: AnalyticsDashboardProps) {
  const [dateRange, setDateRange] = React.useState<DateRange | undefined>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });

  const [refreshKey, setRefreshKey] = React.useState(0);
  const [activeTab, setActiveTab] = React.useState("overview");

  // Data states
  const [overview, setOverview] = React.useState<any>(null);
  const [pipeline, setPipeline] = React.useState<any>(null);
  const [sources, setSources] = React.useState<any>(null);
  const [timeToHire, setTimeToHire] = React.useState<any>(null);
  const [agentPerformance, setAgentPerformance] = React.useState<any>(null);

  const [loading, setLoading] = React.useState({
    overview: false,
    pipeline: false,
    sources: false,
    timeToHire: false,
    agentPerformance: false,
  });

  // Fetch data functions
  const fetchOverview = React.useCallback(async () => {
    setLoading((l) => ({ ...l, overview: true }));
    try {
      const params = new URLSearchParams({ tenantId });
      if (dateRange?.from) params.set("startDate", dateRange.from.toISOString());
      if (dateRange?.to) params.set("endDate", dateRange.to.toISOString());

      const response = await fetch(`/api/analytics/overview?${params}`);
      const data = await response.json();
      if (data.success) {
        setOverview(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch overview:", error);
    } finally {
      setLoading((l) => ({ ...l, overview: false }));
    }
  }, [tenantId, dateRange]);

  const fetchPipeline = React.useCallback(async () => {
    setLoading((l) => ({ ...l, pipeline: true }));
    try {
      const params = new URLSearchParams({ tenantId });
      if (dateRange?.from) params.set("startDate", dateRange.from.toISOString());
      if (dateRange?.to) params.set("endDate", dateRange.to.toISOString());

      const response = await fetch(`/api/analytics/pipeline?${params}`);
      const data = await response.json();
      if (data.success) {
        setPipeline(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch pipeline:", error);
    } finally {
      setLoading((l) => ({ ...l, pipeline: false }));
    }
  }, [tenantId, dateRange]);

  const fetchSources = React.useCallback(async () => {
    setLoading((l) => ({ ...l, sources: true }));
    try {
      const params = new URLSearchParams({ tenantId });
      if (dateRange?.from) params.set("startDate", dateRange.from.toISOString());
      if (dateRange?.to) params.set("endDate", dateRange.to.toISOString());

      const response = await fetch(`/api/analytics/sources?${params}`);
      const data = await response.json();
      if (data.success) {
        setSources(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch sources:", error);
    } finally {
      setLoading((l) => ({ ...l, sources: false }));
    }
  }, [tenantId, dateRange]);

  const fetchTimeToHire = React.useCallback(async () => {
    setLoading((l) => ({ ...l, timeToHire: true }));
    try {
      const params = new URLSearchParams({ tenantId });
      if (dateRange?.from) params.set("startDate", dateRange.from.toISOString());
      if (dateRange?.to) params.set("endDate", dateRange.to.toISOString());

      const response = await fetch(`/api/analytics/time-to-hire?${params}`);
      const data = await response.json();
      if (data.success) {
        setTimeToHire(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch time-to-hire:", error);
    } finally {
      setLoading((l) => ({ ...l, timeToHire: false }));
    }
  }, [tenantId, dateRange]);

  const fetchAgentPerformance = React.useCallback(async () => {
    setLoading((l) => ({ ...l, agentPerformance: true }));
    try {
      const params = new URLSearchParams({ tenantId });
      if (dateRange?.from) params.set("startDate", dateRange.from.toISOString());
      if (dateRange?.to) params.set("endDate", dateRange.to.toISOString());

      const response = await fetch(`/api/analytics/agent-performance?${params}`);
      const data = await response.json();
      if (data.success) {
        setAgentPerformance(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch agent performance:", error);
    } finally {
      setLoading((l) => ({ ...l, agentPerformance: false }));
    }
  }, [tenantId, dateRange]);

  // Fetch all data on mount and when date range changes
  React.useEffect(() => {
    fetchOverview();
    fetchPipeline();
    fetchSources();
    fetchTimeToHire();
    fetchAgentPerformance();
  }, [fetchOverview, fetchPipeline, fetchSources, fetchTimeToHire, fetchAgentPerformance, refreshKey]);

  const handleRefresh = () => {
    setRefreshKey((k) => k + 1);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <BarChart3 className="h-6 w-6" />
            <h1 className="text-2xl font-semibold">Analytics Dashboard</h1>
          </div>
          <div className="flex items-center gap-4">
            <DateRangePicker value={dateRange} onChange={setDateRange} />
            <ExportButton dateRange={dateRange} tenantId={tenantId} />
            <Button variant="outline" size="icon" onClick={handleRefresh}>
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6">
        {/* Overview Cards */}
        <div className="mb-6">
          <OverviewCards data={overview} />
        </div>

        {/* Tabbed Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="recruitment" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Recruitment
            </TabsTrigger>
            <TabsTrigger value="agents" className="flex items-center gap-2">
              <Bot className="h-4 w-4" />
              AI Agents
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <PipelineFunnel data={pipeline} />
              <SourceChart data={sources} />
            </div>
            <TimeToHireChart data={timeToHire} />
          </TabsContent>

          {/* Recruitment Tab */}
          <TabsContent value="recruitment" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <PipelineFunnel data={pipeline} />
              <SourceChart data={sources} />
            </div>
            <TimeToHireChart data={timeToHire} />
            
            {/* Additional Recruitment Stats */}
            <Card>
              <CardHeader>
                <CardTitle>Recruitment Funnel Summary</CardTitle>
                <CardDescription>
                  Key metrics for your recruitment pipeline
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Total Candidates</p>
                    <p className="text-2xl font-bold">{overview?.totalCandidates || 0}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Active Jobs</p>
                    <p className="text-2xl font-bold">{overview?.activeJobs || 0}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Hires This Period</p>
                    <p className="text-2xl font-bold">{overview?.totalHired || 0}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Pending Interviews</p>
                    <p className="text-2xl font-bold">{overview?.pendingInterviews || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI Agents Tab */}
          <TabsContent value="agents" className="space-y-4">
            <AgentPerformanceChart data={agentPerformance} />
            
            {/* Agent Summary */}
            <Card>
              <CardHeader>
                <CardTitle>AI Agents Summary</CardTitle>
                <CardDescription>
                  Performance overview of all AI agents
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-4">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Active Agents</p>
                    <p className="text-2xl font-bold">{overview?.activeAgents || 0}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Total Tasks</p>
                    <p className="text-2xl font-bold">{overview?.totalTasks || 0}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Completed Tasks</p>
                    <p className="text-2xl font-bold">{overview?.completedTasks || 0}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">Success Rate</p>
                    <p className="text-2xl font-bold">{overview?.taskSuccessRate || 0}%</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
