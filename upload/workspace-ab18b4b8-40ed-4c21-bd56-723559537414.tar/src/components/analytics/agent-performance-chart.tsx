"use client";

import * as React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  Cell,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CHART_COLORS, formatDuration } from "@/lib/analytics/charts";

interface AgentPerformanceChartProps {
  data?: {
    metrics: Array<{
      agentId: string;
      agentType: string;
      agentName: string;
      totalRuns: number;
      successRate: number;
      avgDuration: number;
      totalTokensUsed: number;
      lastRunAt: string | null;
      errorRate: number;
    }>;
    performanceChart: Array<{
      name: string;
      totalRuns: number;
      successRate: number;
      errorRate: number;
      avgDuration: number;
      fill?: string;
    }>;
    tokensChart: Array<{
      name: string;
      tokens: number;
      fill?: string;
    }>;
  };
}

// Tooltip component defined outside to avoid recreation on each render
function AgentTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg shadow-lg p-3">
        <p className="font-medium">{label}</p>
        {payload.map((entry, index) => (
          <p
            key={index}
            className="text-sm text-muted-foreground"
          >
            {entry.name}: {entry.name === "avgDuration" ? formatDuration(entry.value) : entry.value}
            {entry.name === "successRate" || entry.name === "errorRate" ? "%" : ""}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

export function AgentPerformanceChart({ data }: AgentPerformanceChartProps) {
  const [view, setView] = React.useState<"performance" | "tokens">("performance");

  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>AI Agent Performance</CardTitle>
          <CardDescription>Tasks completed, success rate, and token usage</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center">
            <div className="animate-pulse text-muted-foreground">Loading...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (data.metrics.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>AI Agent Performance</CardTitle>
          <CardDescription>Tasks completed, success rate, and token usage</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center text-muted-foreground">
            No agent performance data available
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate totals for summary
  const totalRuns = data.metrics.reduce((sum, m) => sum + m.totalRuns, 0);
  const avgSuccessRate = data.metrics.length > 0
    ? data.metrics.reduce((sum, m) => sum + m.successRate, 0) / data.metrics.length
    : 0;
  const totalTokens = data.metrics.reduce((sum, m) => sum + m.totalTokensUsed, 0);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>AI Agent Performance</CardTitle>
            <CardDescription>Tasks completed, success rate, and token usage</CardDescription>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Total Runs:</span>
              <span className="font-medium">{totalRuns}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Avg Success:</span>
              <span className="font-medium">{avgSuccessRate.toFixed(1)}%</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Total Tokens:</span>
              <span className="font-medium">{totalTokens.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={view} onValueChange={(v) => setView(v as "performance" | "tokens")}>
          <TabsList className="mb-4">
            <TabsTrigger value="performance">Performance</TabsTrigger>
            <TabsTrigger value="tokens">Token Usage</TabsTrigger>
          </TabsList>

          <div className="h-[300px]">
            {view === "performance" ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={data.performanceChart}
                  margin={{ top: 5, right: 30, left: 20, bottom: 50 }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis 
                    dataKey="name" 
                    className="text-xs" 
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis className="text-xs" />
                  <Tooltip content={<AgentTooltip />} />
                  <Legend />
                  <Bar dataKey="totalRuns" name="Total Runs" fill={CHART_COLORS.palette[0]} radius={[4, 4, 0, 0]} />
                  <Bar dataKey="successRate" name="Success Rate %" fill={CHART_COLORS.palette[1]} radius={[4, 4, 0, 0]} />
                  <Bar dataKey="errorRate" name="Error Rate %" fill={CHART_COLORS.palette[3]} radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={data.tokensChart}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis type="number" className="text-xs" />
                  <YAxis dataKey="name" type="category" className="text-xs" width={70} />
                  <Tooltip
                    formatter={(value: number) => [value.toLocaleString(), "Tokens"]}
                    contentStyle={{
                      backgroundColor: "hsl(var(--background))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar dataKey="tokens" name="Tokens" fill={CHART_COLORS.palette[2]} radius={[0, 4, 4, 0]}>
                    {data.tokensChart.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill || CHART_COLORS.palette[index % CHART_COLORS.palette.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </Tabs>
      </CardContent>
    </Card>
  );
}
