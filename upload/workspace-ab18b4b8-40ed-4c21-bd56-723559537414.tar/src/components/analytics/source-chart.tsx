"use client";

import * as React from "react";
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CHART_COLORS } from "@/lib/analytics/charts";

interface SourceChartProps {
  data?: {
    metrics: Array<{
      source: string;
      applications: number;
      hires: number;
      conversionRate: number;
      avgTimeToHire: number;
    }>;
    pieChart: Array<{
      name: string;
      value: number;
      hires: number;
      conversionRate: number;
      fill?: string;
    }>;
    barChart: Array<{
      name: string;
      applications: number;
      hires: number;
      conversionRate: number;
    }>;
  };
}

// Tooltip components defined outside to avoid recreation on each render
function SourceTooltip({ active, payload }: { active?: boolean; payload?: Array<{ name: string; value: number; payload: { name: string; value: number; hires: number; conversionRate: number } }> }) {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-background border rounded-lg shadow-lg p-3">
        <p className="font-medium">{data.name}</p>
        <p className="text-sm text-muted-foreground">
          Applications: {data.value}
        </p>
        <p className="text-sm text-muted-foreground">
          Hires: {data.hires}
        </p>
        <p className="text-sm text-muted-foreground">
          Conversion: {data.conversionRate}%
        </p>
      </div>
    );
  }
  return null;
}

function SourceBarTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg shadow-lg p-3">
        <p className="font-medium">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm text-muted-foreground">
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

export function SourceChart({ data }: SourceChartProps) {
  const [view, setView] = React.useState<"pie" | "bar">("bar");

  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Source Effectiveness</CardTitle>
          <CardDescription>Applications and hires by source</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center">
            <div className="animate-pulse text-muted-foreground">Loading...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (data.barChart.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Source Effectiveness</CardTitle>
          <CardDescription>Applications and hires by source</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center text-muted-foreground">
            No source data available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Source Effectiveness</CardTitle>
            <CardDescription>Applications and hires by source</CardDescription>
          </div>
          <Tabs value={view} onValueChange={(v) => setView(v as "pie" | "bar")}>
            <TabsList className="grid w-[120px] grid-cols-2">
              <TabsTrigger value="bar">Bar</TabsTrigger>
              <TabsTrigger value="pie">Pie</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          {view === "pie" ? (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.pieChart}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  labelLine={false}
                >
                  {data.pieChart.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.fill || CHART_COLORS.palette[index % CHART_COLORS.palette.length]}
                    />
                  ))}
                </Pie>
                <Tooltip content={<SourceTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data.barChart}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis type="number" className="text-xs" />
                <YAxis dataKey="name" type="category" className="text-xs" width={70} />
                <Tooltip content={<SourceBarTooltip />} />
                <Legend />
                <Bar dataKey="applications" name="Applications" fill={CHART_COLORS.palette[0]} radius={[0, 4, 4, 0]} />
                <Bar dataKey="hires" name="Hires" fill={CHART_COLORS.palette[1]} radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
