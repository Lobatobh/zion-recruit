"use client";

import * as React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  FunnelChart,
  Funnel,
  LabelList,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CHART_COLORS } from "@/lib/analytics/charts";

interface PipelineData {
  name: string;
  value: number;
  conversionRate?: number;
  fill?: string;
}

interface PipelineFunnelProps {
  data?: {
    metrics: Array<{
      stageName: string;
      stageOrder: number;
      candidatesCount: number;
      conversionRate: number;
      dropOffRate: number;
    }>;
    funnel: PipelineData[];
    barChart: Array<{
      name: string;
      conversion: number;
      dropoff: number;
      candidates: number;
    }>;
  };
}

// CustomTooltip component defined outside to avoid recreation on each render
function PipelineTooltip({ active, payload }: { active?: boolean; payload?: Array<{ name: string; value: number; payload: PipelineData }> }) {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-background border rounded-lg shadow-lg p-3">
        <p className="font-medium">{data.name}</p>
        <p className="text-sm text-muted-foreground">
          Candidates: {data.value}
        </p>
        {data.conversionRate !== undefined && (
          <p className="text-sm text-muted-foreground">
            Conversion: {data.conversionRate}%
          </p>
        )}
      </div>
    );
  }
  return null;
}

export function PipelineFunnel({ data }: PipelineFunnelProps) {
  const [view, setView] = React.useState<"funnel" | "bar">("funnel");

  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Pipeline Conversion</CardTitle>
          <CardDescription>Stage-by-stage conversion rates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center">
            <div className="animate-pulse text-muted-foreground">Loading...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (data.funnel.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Pipeline Conversion</CardTitle>
          <CardDescription>Stage-by-stage conversion rates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center text-muted-foreground">
            No pipeline data available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Pipeline Conversion</CardTitle>
            <CardDescription>Stage-by-stage conversion rates</CardDescription>
          </div>
          <Tabs value={view} onValueChange={(v) => setView(v as "funnel" | "bar")}>
            <TabsList className="grid w-[160px] grid-cols-2">
              <TabsTrigger value="funnel">Funnel</TabsTrigger>
              <TabsTrigger value="bar">Bar</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          {view === "funnel" ? (
            <ResponsiveContainer width="100%" height="100%">
              <FunnelChart>
                <Tooltip content={<PipelineTooltip />} />
                <Funnel
                  dataKey="value"
                  data={data.funnel}
                  isAnimationActive
                >
                  <LabelList
                    position="right"
                    fill="currentColor"
                    stroke="none"
                    dataKey="name"
                    className="text-xs fill-current"
                  />
                  {data.funnel.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.fill || CHART_COLORS.palette[index % CHART_COLORS.palette.length]}
                    />
                  ))}
                </Funnel>
              </FunnelChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data.barChart}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis type="number" className="text-xs" />
                <YAxis dataKey="name" type="category" className="text-xs" width={70} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--background))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                  }}
                />
                <Bar dataKey="conversion" name="Conversion %" fill={CHART_COLORS.palette[0]} radius={[0, 4, 4, 0]} />
                <Bar dataKey="dropoff" name="Drop-off %" fill={CHART_COLORS.palette[3]} radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
