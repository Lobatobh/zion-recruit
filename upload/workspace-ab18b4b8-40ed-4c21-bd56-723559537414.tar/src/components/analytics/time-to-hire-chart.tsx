"use client";

import * as React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CHART_COLORS } from "@/lib/analytics/charts";

interface TimeToHireChartProps {
  data?: {
    metrics: {
      averageDays: number;
      medianDays: number;
      minDays: number;
      maxDays: number;
      trend: number;
    };
    lineChart: Array<{
      date: string;
      averageDays: number;
      hires: number;
    }>;
  };
}

// Tooltip component defined outside to avoid recreation on each render
function TimeToHireTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="bg-background border rounded-lg shadow-lg p-3">
        <p className="font-medium">{label}</p>
        {payload.map((entry, index) => (
          <p
            key={index}
            className="text-sm"
            style={{ color: entry.color }}
          >
            {entry.name === "averageDays"
              ? `Avg Days: ${entry.value}`
              : `Hires: ${entry.value}`}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

export function TimeToHireChart({ data }: TimeToHireChartProps) {
  if (!data) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Time to Hire</CardTitle>
          <CardDescription>Average days from application to hire</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center">
            <div className="animate-pulse text-muted-foreground">Loading...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (data.lineChart.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Time to Hire</CardTitle>
          <CardDescription>Average days from application to hire</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] flex items-center justify-center text-muted-foreground">
            No time-to-hire data available
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Time to Hire</CardTitle>
            <CardDescription>Average days from application to hire</CardDescription>
          </div>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Average:</span>
              <span className="font-medium">{data.metrics.averageDays} days</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Median:</span>
              <span className="font-medium">{data.metrics.medianDays} days</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={data.lineChart}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="date" className="text-xs" />
              <YAxis yAxisId="left" className="text-xs" />
              <YAxis yAxisId="right" orientation="right" className="text-xs" />
              <Tooltip content={<TimeToHireTooltip />} />
              <Legend />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="averageDays"
                name="Average Days"
                stroke={CHART_COLORS.palette[0]}
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="hires"
                name="Hires"
                stroke={CHART_COLORS.palette[1]}
                strokeWidth={2}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}
