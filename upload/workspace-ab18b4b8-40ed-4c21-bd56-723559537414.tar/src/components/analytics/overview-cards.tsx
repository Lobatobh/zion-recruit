"use client";

import * as React from "react";
import {
  Users,
  Briefcase,
  UserCheck,
  Calendar,
  Bot,
  TrendingUp,
  TrendingDown,
  Minus,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface OverviewCardProps {
  title: string;
  value: number | string;
  subValue?: string;
  trend?: number;
  description?: string;
  icon?: React.ElementType;
  className?: string;
}

function OverviewCard({
  title,
  value,
  subValue,
  trend,
  description,
  icon: Icon = Users,
  className,
}: OverviewCardProps) {
  const trendIcon =
    trend === undefined || trend === 0
      ? Minus
      : trend > 0
      ? TrendingUp
      : TrendingDown;
  const trendColor =
    trend === undefined || trend === 0
      ? "text-muted-foreground"
      : trend > 0
      ? "text-green-600 dark:text-green-400"
      : "text-red-600 dark:text-red-400";

  return (
    <Card className={cn("", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {subValue && (
          <p className="text-xs text-muted-foreground">{subValue}</p>
        )}
        {trend !== undefined && (
          <div className={cn("flex items-center text-xs mt-1", trendColor)}>
            {React.createElement(trendIcon, { className: "h-3 w-3 mr-1" })}
            <span>
              {trend > 0 ? "+" : ""}
              {trend}%
            </span>
            <span className="text-muted-foreground ml-1">{description}</span>
          </div>
        )}
        {description && trend === undefined && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
      </CardContent>
    </Card>
  );
}

interface OverviewCardsProps {
  data?: {
    totalCandidates: number;
    candidateTrend: number;
    totalJobs: number;
    activeJobs: number;
    totalHired: number;
    hireTrend: number;
    totalInterviews: number;
    pendingInterviews: number;
    activeAgents: number;
    totalTasks: number;
    completedTasks: number;
    taskSuccessRate: number;
  };
}

export function OverviewCards({ data }: OverviewCardsProps) {
  if (!data) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="h-4 w-24 bg-muted animate-pulse rounded" />
            </CardHeader>
            <CardContent>
              <div className="h-8 w-16 bg-muted animate-pulse rounded mb-2" />
              <div className="h-3 w-20 bg-muted animate-pulse rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Total Candidates",
      value: data.totalCandidates,
      trend: data.candidateTrend,
      description: "vs. previous period",
      icon: Users,
    },
    {
      title: "Active Jobs",
      value: data.activeJobs,
      subValue: `${data.totalJobs} total`,
      description: "Published positions",
      icon: Briefcase,
    },
    {
      title: "Hires This Period",
      value: data.totalHired,
      trend: data.hireTrend,
      description: "vs. previous period",
      icon: UserCheck,
    },
    {
      title: "Interviews Scheduled",
      value: data.pendingInterviews,
      subValue: `${data.totalInterviews} this period`,
      description: "Pending interviews",
      icon: Calendar,
    },
    {
      title: "AI Tasks",
      value: data.completedTasks,
      subValue: `${data.taskSuccessRate}% success`,
      description: `of ${data.totalTasks} total`,
      icon: Bot,
    },
    {
      title: "Active AI Agents",
      value: data.activeAgents,
      description: "Enabled and running",
      icon: Bot,
    },
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
      {cards.map((card, index) => (
        <OverviewCard key={index} {...card} />
      ))}
    </div>
  );
}
