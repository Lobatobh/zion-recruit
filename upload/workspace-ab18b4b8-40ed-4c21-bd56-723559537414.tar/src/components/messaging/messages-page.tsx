/**
 * Messages Page Component - Zion Recruit
 * Main messaging page with conversations list and chat view
 */

"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, Plus, Settings, X } from "lucide-react";
import { useMessagingStore } from "@/stores/messaging-store";
import { useSession } from "next-auth/react";
import { ConversationsList } from "./conversations-list";
import { ChatView } from "./chat-view";
import { useMessagingSocket } from "@/hooks/use-messaging-socket";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ConversationWithDetails } from "@/types/messaging";

export function MessagesPage() {
  const { data: session } = useSession();
  const [selectedConversation, setSelectedConversation] =
    useState<ConversationWithDetails | null>(null);
  const [isMobileListOpen, setIsMobileListOpen] = useState(true);

  // Initialize WebSocket connection
  const { socketConnected } = useMessagingSocket({
    tenantId: session?.user?.tenantId || "demo",
    userId: session?.user?.id || "demo-user",
    userName: session?.user?.name || "Recrutador",
    enabled: !!session,
  });

  const handleSelectConversation = (conversation: ConversationWithDetails) => {
    setSelectedConversation(conversation);
    setIsMobileListOpen(false);
  };

  const handleBackToList = () => {
    setIsMobileListOpen(true);
    setSelectedConversation(null);
  };

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Desktop Layout */}
      <div className="hidden md:flex w-full">
        {/* Conversations List */}
        <div className="w-[350px] flex-shrink-0">
          <ConversationsList
            onSelectConversation={handleSelectConversation}
            selectedConversationId={selectedConversation?.id}
          />
        </div>

        {/* Chat View */}
        <div className="flex-1">
          <ChatView conversation={selectedConversation} />
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="md:hidden w-full relative">
        <AnimatePresence mode="wait">
          {isMobileListOpen ? (
            <motion.div
              key="list"
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute inset-0 w-full"
            >
              <ConversationsList
                onSelectConversation={handleSelectConversation}
                selectedConversationId={selectedConversation?.id}
              />
            </motion.div>
          ) : (
            <motion.div
              key="chat"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="absolute inset-0 w-full"
            >
              <ChatView
                conversation={selectedConversation}
                onBack={handleBackToList}
                isMobile
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
