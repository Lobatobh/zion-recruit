/**
 * Chat View Component - Zion Recruit
 * Individual conversation chat interface
 */

"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send,
  Paperclip,
  Image,
  Smile,
  MoreVertical,
  Phone,
  Video,
  Bot,
  User,
  AlertCircle,
  Pause,
  Play,
  Check,
  CheckCheck,
  Clock,
  ArrowLeft,
  FileText,
  Sparkles,
} from "lucide-react";
import { useMessagingStore } from "@/stores/messaging-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { ConversationWithDetails, Message, CHANNEL_CONFIG } from "@/types/messaging";
import { toast } from "sonner";

interface ChatViewProps {
  conversation: ConversationWithDetails | null;
  onBack?: () => void;
  isMobile?: boolean;
}

export function ChatView({ conversation, onBack, isMobile = false }: ChatViewProps) {
  const {
    messages,
    fetchMessages,
    sendMessage,
    toggleAiMode,
    markAsRead,
    isLoadingMessages,
    typingIndicators,
    socketConnected,
  } = useMessagingStore();

  const [newMessage, setNewMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [showAiSuggestions, setShowAiSuggestions] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Fetch messages when conversation changes
  useEffect(() => {
    if (conversation?.id) {
      fetchMessages(conversation.id);
      markAsRead(conversation.id);
    }
  }, [conversation?.id, fetchMessages, markAsRead]);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages[conversation?.id || ""]]);

  // Typing indicator for this conversation
  const typingIndicator = typingIndicators.find(
    (t) => t.conversationId === conversation?.id
  );

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !conversation || isSending) return;

    setIsSending(true);
    try {
      await sendMessage({
        conversationId: conversation.id,
        content: newMessage.trim(),
      });
      setNewMessage("");
    } catch (error) {
      toast.error("Falha ao enviar mensagem");
    } finally {
      setIsSending(false);
      inputRef.current?.focus();
    }
  };

  const handleToggleAI = async () => {
    if (!conversation) return;
    try {
      await toggleAiMode(conversation.id, !conversation.aiMode);
      toast.success(
        conversation.aiMode ? "IA pausada" : "IA reativada"
      );
    } catch (error) {
      toast.error("Falha ao alterar modo IA");
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const formatTime = (date: Date | string) => {
    return new Date(date).toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const formatDate = (date: Date | string) => {
    const d = new Date(date);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (d.toDateString() === today.toDateString()) {
      return "Hoje";
    } else if (d.toDateString() === yesterday.toDateString()) {
      return "Ontem";
    } else {
      return d.toLocaleDateString("pt-BR", {
        weekday: "long",
        day: "numeric",
        month: "long",
      });
    }
  };

  const conversationMessages = messages[conversation?.id || ""] || [];

  // AI Suggestions
  const aiSuggestions = [
    "Perguntar sobre experiência anterior",
    "Solicitar disponibilidade",
    "Perguntar pretensão salarial",
    "Agendar entrevista",
  ];

  // Group messages by date
  const groupedMessages: { date: string; messages: Message[] }[] = [];
  let currentDate = "";
  conversationMessages.forEach((msg) => {
    const msgDate = formatDate(msg.sentAt);
    if (msgDate !== currentDate) {
      currentDate = msgDate;
      groupedMessages.push({ date: msgDate, messages: [msg] });
    } else {
      groupedMessages[groupedMessages.length - 1].messages.push(msg);
    }
  });

  if (!conversation) {
    return (
      <div className="flex-1 flex items-center justify-center bg-muted/30">
        <div className="text-center">
          <Bot className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">Selecione uma conversa</p>
          <p className="text-sm text-muted-foreground mt-1">
            para começar a interagir
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b border-border bg-background">
        {isMobile && (
          <Button variant="ghost" size="icon" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
        )}

        <Avatar className="h-10 w-10">
          <AvatarImage src={conversation.candidate?.photo || undefined} />
          <AvatarFallback>
            {getInitials(conversation.candidate?.name || "C")}
          </AvatarFallback>
        </Avatar>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium truncate">
              {conversation.candidate?.name}
            </span>
            {conversation.aiMode && (
              <Badge variant="secondary" className="text-xs gap-1">
                <Bot className="h-3 w-3" />
                IA Ativa
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground truncate">
            {conversation.job?.title || "Sem vaga associada"}
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={conversation.aiMode ? "default" : "outline"}
                  size="icon"
                  onClick={handleToggleAI}
                >
                  {conversation.aiMode ? (
                    <Pause className="h-4 w-4" />
                  ) : (
                    <Play className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {conversation.aiMode ? "Pausar IA" : "Reativar IA"}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                Ver perfil do candidato
              </DropdownMenuItem>
              <DropdownMenuItem>
                <FileText className="mr-2 h-4 w-4" />
                Ver currículo
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <Phone className="mr-2 h-4 w-4" />
                Ligar
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Video className="mr-2 h-4 w-4" />
                Video chamada
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive">
                <AlertCircle className="mr-2 h-4 w-4" />
                Encerrar conversa
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Intervention Banner */}
      {conversation.needsIntervention && (
        <div className="px-4 py-2 bg-destructive/10 border-b border-destructive/20">
          <div className="flex items-center gap-2 text-sm">
            <AlertCircle className="h-4 w-4 text-destructive" />
            <span className="text-destructive font-medium">
              Intervenção necessária:
            </span>
            <span className="text-muted-foreground">
              {conversation.interventionReason || "Aguardando análise"}
            </span>
          </div>
        </div>
      )}

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        {isLoadingMessages ? (
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div
                key={i}
                className={cn("flex gap-2", i % 2 === 0 ? "justify-end" : "")}
              >
                <Skeleton
                  className={cn(
                    "h-16 rounded-lg",
                    i % 2 === 0 ? "w-48" : "w-64"
                  )}
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-6">
            {groupedMessages.map((group) => (
              <div key={group.date}>
                {/* Date Divider */}
                <div className="flex items-center gap-4 my-4">
                  <Separator className="flex-1" />
                  <span className="text-xs text-muted-foreground font-medium">
                    {group.date}
                  </span>
                  <Separator className="flex-1" />
                </div>

                {/* Messages */}
                <div className="space-y-3">
                  {group.messages.map((message) => {
                    const isRecruiter = message.senderType === "RECRUITER";
                    const isAI = message.senderType === "AI";
                    const isCandidate = message.senderType === "CANDIDATE";

                    return (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={cn(
                          "flex gap-2 max-w-[80%]",
                          isRecruiter ? "ml-auto flex-row-reverse" : ""
                        )}
                      >
                        {/* Avatar (for non-recruiter messages) */}
                        {!isRecruiter && (
                          <Avatar className="h-8 w-8 flex-shrink-0">
                            <AvatarFallback
                              className={cn(
                                isAI
                                  ? "bg-primary/20 text-primary"
                                  : "bg-muted"
                              )}
                            >
                              {isAI ? (
                                <Bot className="h-4 w-4" />
                              ) : (
                                getInitials(
                                  conversation.candidate?.name || "C"
                                )
                              )}
                            </AvatarFallback>
                          </Avatar>
                        )}

                        {/* Message Bubble */}
                        <div
                          className={cn(
                            "rounded-lg px-4 py-2",
                            isRecruiter
                              ? "bg-primary text-primary-foreground"
                              : isAI
                              ? "bg-primary/10 border border-primary/20"
                              : "bg-muted"
                          )}
                        >
                          {/* AI Badge */}
                          {isAI && (
                            <div className="flex items-center gap-1 mb-1">
                              <Sparkles className="h-3 w-3 text-primary" />
                              <span className="text-xs font-medium text-primary">
                                {message.senderName || "Zoe (IA)"}
                              </span>
                            </div>
                          )}

                          {/* Content */}
                          <p className="text-sm whitespace-pre-wrap">
                            {message.content}
                          </p>

                          {/* Time & Status */}
                          <div
                            className={cn(
                              "flex items-center gap-1 mt-1",
                              isRecruiter
                                ? "justify-end"
                                : "justify-start"
                            )}
                          >
                            <span
                              className={cn(
                                "text-xs",
                                isRecruiter
                                  ? "text-primary-foreground/70"
                                  : "text-muted-foreground"
                              )}
                            >
                              {formatTime(message.sentAt)}
                            </span>
                            {isRecruiter && (
                              <CheckCheck className="h-3 w-3 text-primary-foreground/70" />
                            )}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </div>
            ))}

            {/* Typing Indicator */}
            <AnimatePresence>
              {typingIndicator && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="flex items-center gap-2"
                >
                  <Avatar className="h-8 w-8">
                    <AvatarFallback
                      className={
                        typingIndicator.senderType === "AI"
                          ? "bg-primary/20 text-primary"
                          : "bg-muted"
                      }
                    >
                      {typingIndicator.senderType === "AI" ? (
                        <Bot className="h-4 w-4" />
                      ) : (
                        <User className="h-4 w-4" />
                      )}
                    </AvatarFallback>
                  </Avatar>
                  <div className="bg-muted rounded-lg px-4 py-2">
                    <div className="flex items-center gap-1">
                      <motion.span
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                      />
                      <motion.span
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 1.5, repeat: Infinity, delay: 0.2 }}
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                      />
                      <motion.span
                        animate={{ opacity: [0.4, 1, 0.4] }}
                        transition={{ duration: 1.5, repeat: Infinity, delay: 0.4 }}
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                      />
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {typingIndicator.senderName || "Digitando..."}
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </ScrollArea>

      {/* AI Suggestions */}
      <AnimatePresence>
        {showAiSuggestions && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-border overflow-hidden"
          >
            <div className="p-3 flex flex-wrap gap-2">
              <span className="text-xs text-muted-foreground w-full mb-1">
                Sugestões da IA:
              </span>
              {aiSuggestions.map((suggestion) => (
                <Button
                  key={suggestion}
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setNewMessage(suggestion);
                    setShowAiSuggestions(false);
                    inputRef.current?.focus();
                  }}
                  className="text-xs"
                >
                  <Sparkles className="h-3 w-3 mr-1" />
                  {suggestion}
                </Button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowAiSuggestions(!showAiSuggestions)}
            className={showAiSuggestions ? "bg-primary/10" : ""}
          >
            <Sparkles className="h-4 w-4" />
          </Button>

          <Button variant="ghost" size="icon">
            <Paperclip className="h-4 w-4" />
          </Button>

          <Input
            ref={inputRef}
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            placeholder={
              conversation.aiMode
                ? "Mensagem (IA está ativa...)"
                : "Digite sua mensagem..."
            }
            className="flex-1"
            disabled={isSending}
          />

          <Button
            onClick={handleSendMessage}
            disabled={!newMessage.trim() || isSending}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>

        {/* Connection Status */}
        <div className="flex items-center justify-center mt-2">
          <div
            className={cn(
              "flex items-center gap-1 text-xs",
              socketConnected
                ? "text-green-600"
                : "text-yellow-600"
            )}
          >
            <div
              className={cn(
                "w-2 h-2 rounded-full",
                socketConnected ? "bg-green-600" : "bg-yellow-600"
              )}
            />
            {socketConnected ? "Conectado" : "Reconectando..."}
          </div>
        </div>
      </div>
    </div>
  );
}
