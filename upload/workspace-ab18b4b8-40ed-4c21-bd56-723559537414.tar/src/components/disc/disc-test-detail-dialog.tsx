"use client";

/**
 * DISC Test Detail Dialog - Zion Recruit
 * View detailed DISC test results and analysis
 */

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Brain,
  Send,
  CheckCircle,
  Clock,
  AlertCircle,
  MapPin,
  Briefcase,
  Star,
  TrendingUp,
  Loader2,
  Copy,
  ExternalLink,
  Mail,
  MessageSquare,
  User,
  Building2,
  Calendar,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

// Types
interface Candidate {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  photo: string | null;
  matchScore: number | null;
  city: string | null;
  state: string | null;
  job: {
    id: string;
    title: string;
    city: string | null;
    state: string | null;
    discProfileRequired: string | null;
  };
}

interface DiscTest {
  id: string;
  status: string;
  sentAt: string | null;
  startedAt: string | null;
  completedAt: string | null;
  profileD: number | null;
  profileI: number | null;
  profileS: number | null;
  profileC: number | null;
  primaryProfile: string | null;
  secondaryProfile: string | null;
  jobFitScore: number | null;
  jobFitDetails: string | null;
  aiAnalysis: string | null;
  aiStrengths: string | null;
  aiWeaknesses: string | null;
  aiWorkStyle: string | null;
  candidate: Candidate;
  createdAt: string;
}

interface DiscTestDetailDialogProps {
  test: DiscTest | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onUpdated: () => void;
}

const profileColors: Record<string, { bg: string; text: string; light: string }> = {
  D: { bg: "bg-red-500", text: "text-red-600", light: "bg-red-100 dark:bg-red-900/20" },
  I: { bg: "bg-yellow-500", text: "text-yellow-600", light: "bg-yellow-100 dark:bg-yellow-900/20" },
  S: { bg: "bg-green-500", text: "text-green-600", light: "bg-green-100 dark:bg-green-900/20" },
  C: { bg: "bg-blue-500", text: "text-blue-600", light: "bg-blue-100 dark:bg-blue-900/20" },
};

const profileDescriptions: Record<string, { title: string; description: string }> = {
  D: {
    title: "Dominância",
    description: "Foco em resultados, direto, decisivo, competitivo, orientado a metas",
  },
  I: {
    title: "Influência",
    description: "Entusiasta, otimista, colaborativo, persuasivo, gera conexões",
  },
  S: {
    title: "Estabilidade",
    description: "Paciente, confiável, colaborativo, bom ouvinte, busca harmonia",
  },
  C: {
    title: "Conformidade",
    description: "Analítico, preciso, detalhista, segue regras, busca qualidade",
  },
};

export function DiscTestDetailDialog({
  test,
  open,
  onOpenChange,
  onUpdated,
}: DiscTestDetailDialogProps) {
  const [sending, setSending] = useState(false);
  const [activeTab, setActiveTab] = useState("overview");

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getTestUrl = () => {
    if (!test) return "";
    const baseUrl = process.env.NEXT_PUBLIC_APP_URL || window.location.origin;
    return `${baseUrl}/?view=disc-test&testId=${test.id}`;
  };

  const copyTestLink = async () => {
    const url = getTestUrl();
    await navigator.clipboard.writeText(url);
    toast.success("Link copiado para a área de transferência");
  };

  const sendTest = async () => {
    if (!test) return;
    setSending(true);
    try {
      const response = await fetch("/api/disc/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          candidateId: test.candidate.id,
          sendEmail: true,
          sendWhatsapp: false,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Erro ao enviar teste");
      }

      toast.success(data.message);
      onUpdated();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Erro ao enviar teste");
    } finally {
      setSending(false);
    }
  };

  if (!test) return null;

  const scores = {
    D: test.profileD || 0,
    I: test.profileI || 0,
    S: test.profileS || 0,
    C: test.profileC || 0,
  };

  const primaryColor = test.primaryProfile ? profileColors[test.primaryProfile] : null;
  const primaryDesc = test.primaryProfile ? profileDescriptions[test.primaryProfile] : null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-primary" />
            Teste DISC - {test.candidate.name}
          </DialogTitle>
        </DialogHeader>

        <div className="p-6">
          {/* Candidate Info */}
          <div className="flex items-start gap-4 mb-6">
            <Avatar className="h-16 w-16">
              <AvatarImage src={test.candidate.photo || undefined} />
              <AvatarFallback className="text-lg">
                {getInitials(test.candidate.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="text-lg font-semibold">{test.candidate.name}</h3>
              <p className="text-sm text-muted-foreground">{test.candidate.email}</p>
              <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Briefcase className="h-4 w-4" />
                  {test.candidate.job.title}
                </div>
                <div className="flex items-center gap-1">
                  <MapPin className="h-4 w-4" />
                  {test.candidate.city || "Não informado"}
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <Badge
                className={cn(
                  test.status === "COMPLETED"
                    ? "bg-green-500"
                    : test.status === "SENT"
                    ? "bg-blue-500"
                    : test.status === "STARTED"
                    ? "bg-yellow-500"
                    : "bg-gray-500"
                )}
              >
                {test.status === "COMPLETED"
                  ? "Concluído"
                  : test.status === "SENT"
                  ? "Enviado"
                  : test.status === "STARTED"
                  ? "Iniciado"
                  : "Pendente"}
              </Badge>
              {test.jobFitScore !== null && (
                <div className="flex items-center gap-1 text-sm font-medium">
                  <Star className="h-4 w-4 text-yellow-500" />
                  {test.jobFitScore}% Job Fit
                </div>
              )}
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="profile">Perfil DISC</TabsTrigger>
              <TabsTrigger value="analysis">Análise IA</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-4">
              <ScrollArea className="h-[400px] pr-4">
                <div className="space-y-4">
                  {/* Status Timeline */}
                  <div className="rounded-lg border p-4">
                    <h4 className="font-medium mb-3">Timeline</h4>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                          <Calendar className="h-4 w-4 text-gray-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">Teste Criado</p>
                          <p className="text-xs text-muted-foreground">
                            {formatDate(test.createdAt)}
                          </p>
                        </div>
                      </div>
                      {test.sentAt && (
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center">
                            <Send className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Teste Enviado</p>
                            <p className="text-xs text-muted-foreground">
                              {formatDate(test.sentAt)}
                            </p>
                          </div>
                        </div>
                      )}
                      {test.startedAt && (
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-yellow-100 dark:bg-yellow-900/20 flex items-center justify-center">
                            <Clock className="h-4 w-4 text-yellow-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Teste Iniciado</p>
                            <p className="text-xs text-muted-foreground">
                              {formatDate(test.startedAt)}
                            </p>
                          </div>
                        </div>
                      )}
                      {test.completedAt && (
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/20 flex items-center justify-center">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Teste Concluído</p>
                            <p className="text-xs text-muted-foreground">
                              {formatDate(test.completedAt)}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Test Link */}
                  {(test.status === "PENDING" || test.status === "SENT") && (
                    <div className="rounded-lg border p-4">
                      <h4 className="font-medium mb-3">Link do Teste</h4>
                      <div className="flex gap-2">
                        <Input value={getTestUrl()} readOnly className="text-xs" />
                        <Button size="icon" variant="outline" onClick={copyTestLink}>
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="outline"
                          onClick={() => window.open(getTestUrl(), "_blank")}
                        >
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="flex gap-2 mt-3">
                        <Button
                          onClick={sendTest}
                          disabled={sending}
                          className="flex-1"
                        >
                          {sending ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <Mail className="h-4 w-4 mr-2" />
                          )}
                          Enviar por Email
                        </Button>
                        <Button variant="outline" disabled>
                          <MessageSquare className="h-4 w-4 mr-2" />
                          WhatsApp
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Quick Stats */}
                  {test.status === "COMPLETED" && (
                    <div className="grid grid-cols-2 gap-4">
                      <div className="rounded-lg border p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <Brain className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium">Perfil Principal</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {primaryColor && (
                            <span
                              className={cn(
                                "w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold text-lg",
                                primaryColor.bg
                              )}
                            >
                              {test.primaryProfile}
                            </span>
                          )}
                          <div>
                            <p className="font-semibold">{primaryDesc?.title}</p>
                            <p className="text-xs text-muted-foreground">
                              {primaryDesc?.description}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="rounded-lg border p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <TrendingUp className="h-4 w-4 text-primary" />
                          <span className="text-sm font-medium">Job Fit Score</span>
                        </div>
                        <p className="text-3xl font-bold">
                          {test.jobFitScore != null ? `${test.jobFitScore}%` : "-"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Compatibilidade com a vaga
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </ScrollArea>
            </TabsContent>

            <TabsContent value="profile" className="mt-4">
              <ScrollArea className="h-[400px] pr-4">
                {test.status !== "COMPLETED" ? (
                  <div className="flex flex-col items-center justify-center h-64 text-center">
                    <Brain className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">
                      O perfil DISC será exibido após a conclusão do teste
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {/* Profile Bars */}
                    <div className="space-y-4">
                      {(["D", "I", "S", "C"] as const).map((profile) => {
                        const score = scores[profile];
                        const colors = profileColors[profile];
                        const desc = profileDescriptions[profile];

                        return (
                          <div key={profile}>
                            <div className="flex items-center justify-between mb-1">
                              <div className="flex items-center gap-2">
                                <span
                                  className={cn(
                                    "w-8 h-8 rounded flex items-center justify-center text-white font-bold",
                                    colors.bg
                                  )}
                                >
                                  {profile}
                                </span>
                                <span className="font-medium">{desc.title}</span>
                              </div>
                              <span className="font-bold">{score}%</span>
                            </div>
                            <Progress value={score} className="h-2" />
                            <p className="text-xs text-muted-foreground mt-1">
                              {desc.description}
                            </p>
                          </div>
                        );
                      })}
                    </div>

                    {/* Profile Combination */}
                    {test.primaryProfile && test.secondaryProfile && (
                      <div className="rounded-lg border p-4">
                        <h4 className="font-medium mb-2">Combinação de Perfil</h4>
                        <div className="flex items-center gap-2">
                          <span
                            className={cn(
                              "w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold",
                              profileColors[test.primaryProfile].bg
                            )}
                          >
                            {test.primaryProfile}
                          </span>
                          <span className="text-lg">+</span>
                          <span
                            className={cn(
                              "w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold",
                              profileColors[test.secondaryProfile].bg
                            )}
                          >
                            {test.secondaryProfile}
                          </span>
                          <span className="ml-2 text-lg font-semibold">
                            {test.primaryProfile}
                            {test.secondaryProfile}
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Job Fit Details */}
                    {test.jobFitDetails && (
                      <div className="rounded-lg border p-4">
                        <h4 className="font-medium mb-2">Detalhes do Job Fit</h4>
                        <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                          {test.jobFitDetails}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>

            <TabsContent value="analysis" className="mt-4">
              <ScrollArea className="h-[400px] pr-4">
                {test.status !== "COMPLETED" ? (
                  <div className="flex flex-col items-center justify-center h-64 text-center">
                    <Brain className="h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">
                      A análise da IA será exibida após a conclusão do teste
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* AI Analysis */}
                    {test.aiAnalysis && (
                      <div className="rounded-lg border p-4">
                        <h4 className="font-medium mb-2 flex items-center gap-2">
                          <Brain className="h-4 w-4 text-primary" />
                          Análise Geral
                        </h4>
                        <p className="text-sm text-muted-foreground">
                          {test.aiAnalysis}
                        </p>
                      </div>
                    )}

                    {/* Strengths */}
                    {test.aiStrengths && (
                      <div className="rounded-lg border p-4">
                        <h4 className="font-medium mb-2 flex items-center gap-2">
                          <TrendingUp className="h-4 w-4 text-green-500" />
                          Pontos Fortes
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {JSON.parse(test.aiStrengths).map(
                            (strength: string, i: number) => (
                              <Badge key={i} variant="outline" className="bg-green-50 dark:bg-green-900/20">
                                {strength}
                              </Badge>
                            )
                          )}
                        </div>
                      </div>
                    )}

                    {/* Areas for Development */}
                    {test.aiWeaknesses && (
                      <div className="rounded-lg border p-4">
                        <h4 className="font-medium mb-2 flex items-center gap-2">
                          <AlertCircle className="h-4 w-4 text-yellow-500" />
                          Áreas de Desenvolvimento
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {JSON.parse(test.aiWeaknesses).map(
                            (weakness: string, i: number) => (
                              <Badge key={i} variant="outline" className="bg-yellow-50 dark:bg-yellow-900/20">
                                {weakness}
                              </Badge>
                            )
                          )}
                        </div>
                      </div>
                    )}

                    {/* Work Style */}
                    {test.aiWorkStyle && (
                      <div className="rounded-lg border p-4">
                        <h4 className="font-medium mb-2">Estilo de Trabalho</h4>
                        <p className="text-sm text-muted-foreground">
                          {test.aiWorkStyle}
                        </p>
                      </div>
                    )}

                    {!test.aiAnalysis && !test.aiStrengths && !test.aiWeaknesses && !test.aiWorkStyle && (
                      <div className="flex flex-col items-center justify-center h-64 text-center">
                        <Brain className="h-12 w-12 text-muted-foreground mb-4" />
                        <p className="text-muted-foreground">
                          Análise da IA em processamento...
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}
