"use client";

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar, 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from "recharts";
import { 
  Printer, 
  Download, 
  Share2, 
  Briefcase,
  MessageSquare,
  Users,
  Target,
  TrendingUp,
} from "lucide-react";
import { DISCFactor } from "@/lib/disc/questions";
import { 
  getProfileDescription, 
  getComboProfile, 
  getFactorColors 
} from "@/lib/disc/profiles";

interface DiscResultsProps {
  testId: string;
  scores: {
    D: number;
    I: number;
    S: number;
    C: number;
  };
  primaryProfile: DISCFactor;
  secondaryProfile: DISCFactor | null;
  profileCombo: string;
  aiAnalysis?: string | null;
  aiStrengths?: string | null;
  aiWeaknesses?: string | null;
  aiWorkStyle?: string | null;
  jobFitScore?: number | null;
  jobFitDetails?: string | null;
  candidateName?: string;
  jobTitle?: string;
}

export function DiscResults({
  testId,
  scores,
  primaryProfile,
  secondaryProfile,
  profileCombo,
  aiAnalysis,
  aiStrengths,
  aiWeaknesses,
  aiWorkStyle,
  jobFitScore,
  jobFitDetails,
  candidateName,
  jobTitle,
}: DiscResultsProps) {
  const primaryDesc = getProfileDescription(primaryProfile);
  const comboDesc = getComboProfile(profileCombo);
  const colors = getFactorColors();

  // Prepare radar chart data
  const radarData = [
    { factor: 'D', value: scores.D, fullMark: 100 },
    { factor: 'I', value: scores.I, fullMark: 100 },
    { factor: 'S', value: scores.S, fullMark: 100 },
    { factor: 'C', value: scores.C, fullMark: 100 },
  ];

  // Prepare bar chart data
  const barData = [
    { name: 'D', value: scores.D, color: colors.D },
    { name: 'I', value: scores.I, color: colors.I },
    { name: 'S', value: scores.S, color: colors.S },
    { name: 'C', value: scores.C, color: colors.C },
  ];

  // Parse AI data
  const strengths = aiStrengths ? JSON.parse(aiStrengths) : primaryDesc.strengths.slice(0, 5);
  const weaknesses = aiWeaknesses ? JSON.parse(aiWeaknesses) : primaryDesc.weaknesses.slice(0, 3);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6" id="disc-results">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">DISC Assessment Results</h2>
          {candidateName && (
            <p className="text-muted-foreground">
              {candidateName} {jobTitle && `• ${jobTitle}`}
            </p>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handlePrint}>
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
        </div>
      </div>

      {/* Profile Badge */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-4">
            <div 
              className="w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold"
              style={{ backgroundColor: primaryDesc.color }}
            >
              {profileCombo}
            </div>
            <div>
              <h3 className="text-xl font-bold" style={{ color: primaryDesc.color }}>
                {comboDesc?.name || primaryDesc.title}
              </h3>
              <p className="text-muted-foreground">
                {primaryProfile} (Primary){secondaryProfile && ` with ${secondaryProfile} (Secondary)`}
              </p>
            </div>
            {jobFitScore !== null && jobFitScore !== undefined && (
              <div className="ml-auto text-right">
                <div className="text-2xl font-bold text-green-500">{jobFitScore}%</div>
                <div className="text-sm text-muted-foreground">Job Fit Score</div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Charts */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Radar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Profile Visualization</CardTitle>
            <CardDescription>DISC factor distribution</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData}>
                  <PolarGrid />
                  <PolarAngleAxis 
                    dataKey="factor" 
                    tick={{ fill: '#888', fontSize: 12 }}
                  />
                  <PolarRadiusAxis 
                    angle={90} 
                    domain={[0, 100]} 
                    tick={{ fontSize: 10 }}
                  />
                  <Radar
                    name="Profile"
                    dataKey="value"
                    stroke={primaryDesc.color}
                    fill={primaryDesc.color}
                    fillOpacity={0.5}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Bar Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Factor Scores</CardTitle>
            <CardDescription>Percentage scores for each factor</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" domain={[0, 100]} />
                  <YAxis type="category" dataKey="name" width={30} />
                  <Tooltip />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                    {barData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tabs */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="strengths">Strengths</TabsTrigger>
          <TabsTrigger value="workstyle">Work Style</TabsTrigger>
          <TabsTrigger value="jobfit">Job Fit</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Profile Overview
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                {aiAnalysis || primaryDesc.description}
              </p>
              
              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="space-y-2">
                  <h4 className="font-medium">Leadership Style</h4>
                  <p className="text-sm text-muted-foreground">{primaryDesc.leadershipStyle}</p>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium">Decision Making</h4>
                  <p className="text-sm text-muted-foreground">{primaryDesc.decisionMaking}</p>
                </div>
              </div>

              <div className="space-y-2 pt-4">
                <h4 className="font-medium">Ideal Environment</h4>
                <div className="flex flex-wrap gap-2">
                  {primaryDesc.idealEnvironment.map((env, i) => (
                    <Badge key={i} variant="secondary">{env}</Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="strengths" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-600">
                  <TrendingUp className="h-5 w-5" />
                  Strengths
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {strengths.map((strength: string, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-green-500 mt-2" />
                      <span className="text-sm">{strength}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-600">
                  <Target className="h-5 w-5" />
                  Areas for Development
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {weaknesses.map((weakness: string, i: number) => (
                    <li key={i} className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-amber-500 mt-2" />
                      <span className="text-sm">{weakness}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="workstyle" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Work Style & Communication
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <h4 className="font-medium">Work Style</h4>
                <p className="text-sm text-muted-foreground">
                  {aiWorkStyle || primaryDesc.communicationStyle}
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Communication Style</h4>
                <p className="text-sm text-muted-foreground">
                  {primaryDesc.communicationStyle}
                </p>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium">Team Contribution</h4>
                <p className="text-sm text-muted-foreground">
                  {primaryDesc.teamContribution}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4">
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-green-500" />
                    Motivators
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {primaryDesc.motivators.map((m, i) => (
                      <Badge key={i} variant="outline" className="text-xs">{m}</Badge>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <Target className="h-4 w-4 text-red-500" />
                    Stressors
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {primaryDesc.stressors.map((s, i) => (
                      <Badge key={i} variant="outline" className="text-xs">{s}</Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="jobfit" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                Job Fit Analysis
              </CardTitle>
              {jobTitle && <CardDescription>For position: {jobTitle}</CardDescription>}
            </CardHeader>
            <CardContent className="space-y-6">
              {jobFitScore !== null && jobFitScore !== undefined ? (
                <>
                  <div className="flex items-center justify-center">
                    <div className="relative w-32 h-32">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle
                          className="text-muted"
                          strokeWidth="12"
                          stroke="currentColor"
                          fill="transparent"
                          r="52"
                          cx="64"
                          cy="64"
                        />
                        <circle
                          className="text-green-500"
                          strokeWidth="12"
                          strokeDasharray={`${(jobFitScore / 100) * 327} 327`}
                          strokeLinecap="round"
                          stroke="currentColor"
                          fill="transparent"
                          r="52"
                          cx="64"
                          cy="64"
                        />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-3xl font-bold">{jobFitScore}%</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-center">
                    <Badge 
                      variant={jobFitScore >= 70 ? "default" : jobFitScore >= 50 ? "secondary" : "destructive"}
                      className="text-sm"
                    >
                      {jobFitScore >= 70 ? "Strong Match" : jobFitScore >= 50 ? "Moderate Match" : "Potential Gap"}
                    </Badge>
                  </div>

                  {jobFitDetails && (
                    <p className="text-sm text-muted-foreground text-center">
                      {jobFitDetails}
                    </p>
                  )}
                </>
              ) : (
                <div className="text-center py-8">
                  <Briefcase className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">
                    No job fit analysis available. 
                    This can be generated when a specific job is assigned.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
