"use client";

import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  CheckCircle2,
  Loader2,
  AlertCircle,
} from "lucide-react";
import { DiscQuestionCard } from "./disc-question-card";
import { DiscResults } from "./disc-results";
import { DISC_QUESTIONS, TOTAL_QUESTIONS } from "@/lib/disc/questions";
import { cn } from "@/lib/utils";

interface Answer {
  questionNumber: number;
  mostOption: string;
  leastOption: string;
}

interface TestState {
  id: string;
  status: string;
  candidate?: {
    name: string;
    job: {
      title: string;
    };
  };
  profileD?: number;
  profileI?: number;
  profileS?: number;
  profileC?: number;
  primaryProfile?: string;
  secondaryProfile?: string | null;
  profileCombo?: string;
  aiAnalysis?: string | null;
  aiStrengths?: string | null;
  aiWeaknesses?: string | null;
  aiWorkStyle?: string | null;
  jobFitScore?: number | null;
  jobFitDetails?: string | null;
}

interface DiscTestPageProps {
  testId: string;
  initialTest?: TestState;
}

export function DiscTestPage({ testId, initialTest }: DiscTestPageProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [test, setTest] = useState<TestState | null>(initialTest || null);
  const [error, setError] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [showTimer, setShowTimer] = useState(false);

  // Load test data if not provided
  useEffect(() => {
    if (!initialTest && testId) {
      fetchTest();
    }
  }, [testId, initialTest]);

  // Start timer when test begins
  useEffect(() => {
    if (test?.status === 'STARTED' && !startTime) {
      setStartTime(new Date());
    }
  }, [test?.status, startTime]);

  const fetchTest = async () => {
    try {
      const response = await fetch(`/api/disc/${testId}`);
      if (!response.ok) throw new Error('Failed to load test');
      
      const data = await response.json();
      setTest(data.test);
      
      // Load existing answers if any
      if (data.test.answers && data.test.answers.length > 0) {
        setAnswers(data.test.answers);
      }
      
      if (data.test.status === 'COMPLETED') {
        setIsCompleted(true);
      }
    } catch (err) {
      setError('Failed to load test. Please try again.');
      console.error(err);
    }
  };

  const startTest = async () => {
    try {
      const response = await fetch(`/api/disc/${testId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'STARTED' }),
      });
      
      if (!response.ok) throw new Error('Failed to start test');
      
      const data = await response.json();
      setTest(data.test);
      setStartTime(new Date());
    } catch (err) {
      setError('Failed to start test. Please try again.');
      console.error(err);
    }
  };

  const handleMostSelect = (optionId: string) => {
    const questionNum = currentQuestion + 1;
    const existing = answers.find(a => a.questionNumber === questionNum);
    
    if (existing) {
      setAnswers(answers.map(a => 
        a.questionNumber === questionNum 
          ? { ...a, mostOption: optionId }
          : a
      ));
    } else {
      setAnswers([...answers, {
        questionNumber: questionNum,
        mostOption: optionId,
        leastOption: '',
      }]);
    }
    
    // Auto-save
    saveAnswer(questionNum, optionId, existing?.leastOption || '');
  };

  const handleLeastSelect = (optionId: string) => {
    const questionNum = currentQuestion + 1;
    const existing = answers.find(a => a.questionNumber === questionNum);
    
    if (existing) {
      setAnswers(answers.map(a => 
        a.questionNumber === questionNum 
          ? { ...a, leastOption: optionId }
          : a
      ));
    } else {
      setAnswers([...answers, {
        questionNumber: questionNum,
        mostOption: '',
        leastOption: optionId,
      }]);
    }
    
    // Auto-save
    saveAnswer(questionNum, existing?.mostOption || '', optionId);
  };

  const saveAnswer = async (questionNum: number, mostOption: string, leastOption: string) => {
    try {
      await fetch(`/api/disc/${testId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          answers: [{
            questionNumber: questionNum,
            mostOption,
            leastOption,
          }],
        }),
      });
    } catch (err) {
      console.error('Failed to save answer:', err);
    }
  };

  const goNext = () => {
    if (currentQuestion < TOTAL_QUESTIONS - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const goPrev = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = async () => {
    // Validate all answers
    const allAnswered = answers.length === TOTAL_QUESTIONS && 
      answers.every(a => a.mostOption && a.leastOption);
    
    if (!allAnswered) {
      setError('Please answer all questions before submitting.');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const response = await fetch(`/api/disc/${testId}/submit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answers }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Failed to submit test');
      }

      const data = await response.json();
      setTest(data.test);
      setIsCompleted(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit test');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Calculate progress
  const answeredCount = answers.filter(a => a.mostOption && a.leastOption).length;
  const progress = (answeredCount / TOTAL_QUESTIONS) * 100;
  const currentAnswer = answers.find(a => a.questionNumber === currentQuestion + 1);
  const isCurrentComplete = currentAnswer?.mostOption && currentAnswer?.leastOption;

  // Calculate elapsed time
  const getElapsedTime = () => {
    if (!startTime) return '00:00';
    const now = new Date();
    const diff = Math.floor((now.getTime() - startTime.getTime()) / 1000);
    const mins = Math.floor(diff / 60);
    const secs = diff % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const [elapsedTime, setElapsedTime] = useState('00:00');

  useEffect(() => {
    if (startTime && !isCompleted) {
      const interval = setInterval(() => {
        setElapsedTime(getElapsedTime());
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [startTime, isCompleted]);

  // Show completed results
  if (isCompleted && test) {
    return (
      <DiscResults
        testId={testId}
        scores={{
          D: test.profileD || 0,
          I: test.profileI || 0,
          S: test.profileS || 0,
          C: test.profileC || 0,
        }}
        primaryProfile={test.primaryProfile as 'D' | 'I' | 'S' | 'C'}
        secondaryProfile={test.secondaryProfile as 'D' | 'I' | 'S' | 'C' | null}
        profileCombo={test.profileCombo || test.primaryProfile || 'D'}
        aiAnalysis={test.aiAnalysis}
        aiStrengths={test.aiStrengths}
        aiWeaknesses={test.aiWeaknesses}
        aiWorkStyle={test.aiWorkStyle}
        jobFitScore={test.jobFitScore}
        jobFitDetails={test.jobFitDetails}
        candidateName={test.candidate?.name}
        jobTitle={test.candidate?.job?.title}
      />
    );
  }

  // Show intro screen
  if (test?.status === 'PENDING' || test?.status === 'SENT') {
    return (
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">DISC Behavioral Assessment</CardTitle>
          <CardDescription>
            Discover your behavioral profile and work style preferences
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center space-y-4">
            <div className="grid grid-cols-2 gap-4 text-left">
              <div className="p-4 bg-muted rounded-lg">
                <div className="font-medium mb-1">Questions</div>
                <div className="text-2xl font-bold">{TOTAL_QUESTIONS}</div>
              </div>
              <div className="p-4 bg-muted rounded-lg">
                <div className="font-medium mb-1">Duration</div>
                <div className="text-2xl font-bold">~10 min</div>
              </div>
            </div>
            
            <div className="text-left space-y-2">
              <p className="text-sm text-muted-foreground">
                Each question presents 4 statements. You will select:
              </p>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>• <strong>Most like you</strong> - the statement that best describes you</li>
                <li>• <strong>Least like you</strong> - the statement that least describes you</li>
              </ul>
            </div>

            <div className="bg-blue-50 dark:bg-blue-950/30 p-4 rounded-lg text-left">
              <p className="text-sm">
                <strong>Tip:</strong> There are no right or wrong answers. 
                Be honest and go with your first instinct.
              </p>
            </div>

            <Button 
              size="lg" 
              className="w-full"
              onClick={startTest}
            >
              Start Assessment
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Show test interface
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Progress Header */}
      <Card>
        <CardContent className="py-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">
                Question {currentQuestion + 1} of {TOTAL_QUESTIONS}
              </span>
              <Badge variant="secondary">
                {answeredCount} answered
              </Badge>
            </div>
            {showTimer && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                {elapsedTime}
              </div>
            )}
          </div>
          <Progress value={progress} className="h-2" />
          
          {/* Question Navigator */}
          <div className="flex gap-1 mt-4 overflow-x-auto pb-2">
            {DISC_QUESTIONS.map((_, idx) => {
              const answer = answers.find(a => a.questionNumber === idx + 1);
              const isComplete = answer?.mostOption && answer?.leastOption;
              const isCurrent = idx === currentQuestion;
              
              return (
                <button
                  key={idx}
                  onClick={() => setCurrentQuestion(idx)}
                  className={cn(
                    "w-8 h-8 rounded-full text-xs font-medium transition-colors shrink-0",
                    isCurrent && "ring-2 ring-primary ring-offset-2",
                    isComplete 
                      ? "bg-green-500 text-white" 
                      : "bg-muted text-muted-foreground hover:bg-muted/80"
                  )}
                >
                  {isComplete ? <CheckCircle2 className="h-4 w-4 mx-auto" /> : idx + 1}
                </button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Error Message */}
      {error && (
        <div className="flex items-center gap-2 p-4 bg-destructive/10 text-destructive rounded-lg">
          <AlertCircle className="h-5 w-5" />
          <span>{error}</span>
        </div>
      )}

      {/* Current Question */}
      <DiscQuestionCard
        question={DISC_QUESTIONS[currentQuestion]}
        questionNumber={currentQuestion + 1}
        totalQuestions={TOTAL_QUESTIONS}
        selectedMost={currentAnswer?.mostOption || null}
        selectedLeast={currentAnswer?.leastOption || null}
        onMostSelect={handleMostSelect}
        onLeastSelect={handleLeastSelect}
      />

      {/* Navigation */}
      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={goPrev}
          disabled={currentQuestion === 0}
        >
          <ChevronLeft className="h-4 w-4 mr-2" />
          Previous
        </Button>

        {currentQuestion === TOTAL_QUESTIONS - 1 ? (
          <Button
            onClick={handleSubmit}
            disabled={!isCurrentComplete || isSubmitting}
            className="bg-green-600 hover:bg-green-700"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Submit Test
              </>
            )}
          </Button>
        ) : (
          <Button
            onClick={goNext}
            disabled={currentQuestion === TOTAL_QUESTIONS - 1}
          >
            Next
            <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        )}
      </div>
    </div>
  );
}
