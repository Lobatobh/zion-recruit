"use client";

/**
 * DISC Management Page - Zion Recruit
 * Manage DISC tests for candidates
 */

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Brain,
  Send,
  Search,
  CheckCircle,
  Clock,
  AlertCircle,
  RefreshCw,
  Eye,
  MapPin,
  Briefcase,
  Star,
  TrendingUp,
  Users,
  Loader2,
  Plus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { DiscTestDetailDialog } from "./disc-test-detail-dialog";

// Types
interface Candidate {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  photo: string | null;
  matchScore: number | null;
  city: string | null;
  state: string | null;
  job: {
    id: string;
    title: string;
    city: string | null;
    state: string | null;
    discProfileRequired: string | null;
  };
}

interface DiscTest {
  id: string;
  status: string;
  sentAt: string | null;
  startedAt: string | null;
  completedAt: string | null;
  profileD: number | null;
  profileI: number | null;
  profileS: number | null;
  profileC: number | null;
  primaryProfile: string | null;
  secondaryProfile: string | null;
  jobFitScore: number | null;
  candidate: Candidate;
  createdAt: string;
}

interface DiscStats {
  total: number;
  pending: number;
  sent: number;
  started: number;
  completed: number;
  avgJobFit: number | null;
}

const statusConfig = {
  PENDING: {
    label: "Pendente",
    color: "bg-gray-500",
    textColor: "text-gray-600",
    bgColor: "bg-gray-50 dark:bg-gray-900/20",
    icon: Clock,
  },
  SENT: {
    label: "Enviado",
    color: "bg-blue-500",
    textColor: "text-blue-600",
    bgColor: "bg-blue-50 dark:bg-blue-900/20",
    icon: Send,
  },
  STARTED: {
    label: "Iniciado",
    color: "bg-yellow-500",
    textColor: "text-yellow-600",
    bgColor: "bg-yellow-50 dark:bg-yellow-900/20",
    icon: RefreshCw,
  },
  COMPLETED: {
    label: "Concluído",
    color: "bg-green-500",
    textColor: "text-green-600",
    bgColor: "bg-green-50 dark:bg-green-900/20",
    icon: CheckCircle,
  },
  EXPIRED: {
    label: "Expirado",
    color: "bg-red-500",
    textColor: "text-red-600",
    bgColor: "bg-red-50 dark:bg-red-900/20",
    icon: AlertCircle,
  },
};

const profileColors: Record<string, string> = {
  D: "bg-red-500",
  I: "bg-yellow-500",
  S: "bg-green-500",
  C: "bg-blue-500",
};

export function DiscManagementPage() {
  const [tests, setTests] = useState<DiscTest[]>([]);
  const [stats, setStats] = useState<DiscStats | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selectedTest, setSelectedTest] = useState<DiscTest | null>(null);
  const [detailOpen, setDetailOpen] = useState(false);
  const [sendingTestId, setSendingTestId] = useState<string | null>(null);

  const fetchTests = useCallback(async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter !== "all") {
        params.append("status", statusFilter);
      }

      const response = await fetch(`/api/disc?${params.toString()}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Erro ao carregar testes");
      }

      setTests(data.tests || []);

      // Calculate stats
      const total = data.tests?.length || 0;
      const completed = data.tests?.filter((t: DiscTest) => t.status === "COMPLETED").length || 0;
      const completedTests = data.tests?.filter((t: DiscTest) => t.status === "COMPLETED" && t.jobFitScore) || [];
      const avgJobFit = completedTests.length > 0
        ? Math.round(completedTests.reduce((acc: number, t: DiscTest) => acc + (t.jobFitScore || 0), 0) / completedTests.length)
        : null;

      setStats({
        total,
        pending: data.tests?.filter((t: DiscTest) => t.status === "PENDING").length || 0,
        sent: data.tests?.filter((t: DiscTest) => t.status === "SENT").length || 0,
        started: data.tests?.filter((t: DiscTest) => t.status === "STARTED").length || 0,
        completed,
        avgJobFit,
      });
    } catch (error) {
      console.error("Error fetching DISC tests:", error);
      toast.error("Erro ao carregar testes DISC");
    } finally {
      setIsLoading(false);
    }
  }, [statusFilter]);

  useEffect(() => {
    fetchTests();
  }, [fetchTests]);

  const filteredTests = tests.filter((test) => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        test.candidate.name.toLowerCase().includes(query) ||
        test.candidate.email.toLowerCase().includes(query) ||
        test.candidate.job.title.toLowerCase().includes(query)
      );
    }
    return true;
  });

  const sendTest = async (candidateId: string, testId: string) => {
    setSendingTestId(testId);
    try {
      const response = await fetch("/api/disc/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ candidateId, sendEmail: true, sendWhatsapp: false }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Erro ao enviar teste");
      }

      toast.success(data.message);
      fetchTests();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Erro ao enviar teste");
    } finally {
      setSendingTestId(null);
    }
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleDateString("pt-BR", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const handleTestClick = (test: DiscTest) => {
    setSelectedTest(test);
    setDetailOpen(true);
  };

  return (
    <div className="h-full flex flex-col p-6 lg:p-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Brain className="h-7 w-7 text-primary" />
            Testes DISC
          </h1>
          <p className="text-muted-foreground">
            Gerencie testes comportamentais dos candidatos
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={fetchTests}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Atualizar
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gray-100 dark:bg-gray-900/20">
                <Users className="h-5 w-5 text-gray-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-2xl font-bold">{stats?.total || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-gray-100 dark:bg-gray-900/20">
                <Clock className="h-5 w-5 text-gray-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pendentes</p>
                <p className="text-2xl font-bold">{stats?.pending || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/20">
                <Send className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Enviados</p>
                <p className="text-2xl font-bold">{stats?.sent || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-100 dark:bg-green-900/20">
                <CheckCircle className="h-5 w-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Concluídos</p>
                <p className="text-2xl font-bold">{stats?.completed || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/20">
                <TrendingUp className="h-5 w-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Job Fit Médio</p>
                <p className="text-2xl font-bold">
                  {stats?.avgJobFit != null ? `${stats.avgJobFit}%` : "-"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar por candidato, vaga..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os Status</SelectItem>
            <SelectItem value="PENDING">Pendente</SelectItem>
            <SelectItem value="SENT">Enviado</SelectItem>
            <SelectItem value="STARTED">Iniciado</SelectItem>
            <SelectItem value="COMPLETED">Concluído</SelectItem>
            <SelectItem value="EXPIRED">Expirado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      ) : filteredTests.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
          <Brain className="h-16 w-16 text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Nenhum teste DISC encontrado</h3>
          <p className="text-muted-foreground mb-4">
            {searchQuery || statusFilter !== "all"
              ? "Tente ajustar os filtros de busca"
              : "Os testes DISC são criados quando candidatos avançam para a etapa de teste DISC"}
          </p>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Criar Teste DISC
          </Button>
        </div>
      ) : (
        <ScrollArea className="flex-1 -mx-6 px-6 lg:-mx-8 lg:px-8">
          <div className="space-y-3">
            <AnimatePresence mode="popLayout">
              {filteredTests.map((test) => {
                const config = statusConfig[test.status as keyof typeof statusConfig] || statusConfig.PENDING;
                const StatusIcon = config.icon;

                return (
                  <motion.div
                    key={test.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    onClick={() => handleTestClick(test)}
                    className={cn(
                      "p-4 rounded-lg border cursor-pointer transition-all",
                      "hover:shadow-md hover:border-primary/20",
                      config.bgColor
                    )}
                  >
                    <div className="flex items-start gap-4">
                      {/* Avatar */}
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={test.candidate.photo || undefined} />
                        <AvatarFallback>
                          {getInitials(test.candidate.name)}
                        </AvatarFallback>
                      </Avatar>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <h4 className="font-medium truncate">{test.candidate.name}</h4>
                            <p className="text-sm text-muted-foreground truncate">
                              {test.candidate.job.title}
                            </p>
                          </div>
                          <Badge className={cn("text-xs", config.color, "text-white")}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {config.label}
                          </Badge>
                        </div>

                        {/* Profile Info (if completed) */}
                        {test.status === "COMPLETED" && test.primaryProfile && (
                          <div className="flex items-center gap-4 mt-2">
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">Perfil:</span>
                              <div className="flex gap-1">
                                {["D", "I", "S", "C"].map((p) => (
                                  <span
                                    key={p}
                                    className={cn(
                                      "w-6 h-6 rounded flex items-center justify-center text-xs font-bold text-white",
                                      test.primaryProfile === p
                                        ? profileColors[p]
                                        : "bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400"
                                    )}
                                  >
                                    {p}
                                  </span>
                                ))}
                              </div>
                            </div>
                            {test.jobFitScore !== null && (
                              <div className="flex items-center gap-2">
                                <Star className="h-4 w-4 text-yellow-500" />
                                <span className="text-sm font-medium">{test.jobFitScore}% Job Fit</span>
                              </div>
                            )}
                          </div>
                        )}

                        {/* Location */}
                        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Briefcase className="h-3 w-3" />
                            {test.candidate.job.city || "Remoto"}
                            {test.candidate.job.state && `, ${test.candidate.job.state}`}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {test.candidate.city || "Não informado"}
                            {test.candidate.state && `, ${test.candidate.state}`}
                          </div>
                          {test.candidate.matchScore !== null && (
                            <Badge variant="outline" className="text-xs">
                              Match: {test.candidate.matchScore}%
                            </Badge>
                          )}
                        </div>

                        {/* Dates */}
                        <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                          {test.sentAt && (
                            <span>Enviado: {formatDate(test.sentAt)}</span>
                          )}
                          {test.completedAt && (
                            <span>Concluído: {formatDate(test.completedAt)}</span>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2">
                        {test.status === "PENDING" && (
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              sendTest(test.candidate.id, test.id);
                            }}
                            disabled={sendingTestId === test.id}
                          >
                            {sendingTestId === test.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <>
                                <Send className="h-4 w-4 mr-1" />
                                Enviar
                              </>
                            )}
                          </Button>
                        )}
                        {test.status === "SENT" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              sendTest(test.candidate.id, test.id);
                            }}
                            disabled={sendingTestId === test.id}
                          >
                            <RefreshCw className="h-4 w-4 mr-1" />
                            Reenviar
                          </Button>
                        )}
                        {test.status === "COMPLETED" && (
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4 mr-1" />
                            Ver Relatório
                          </Button>
                        )}
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        </ScrollArea>
      )}

      {/* Detail Dialog */}
      <DiscTestDetailDialog
        test={selectedTest}
        open={detailOpen}
        onOpenChange={setDetailOpen}
        onUpdated={fetchTests}
      />
    </div>
  );
}
