"use client";

import { useEffect, useState, useCallback } from "react";
import { useDebouncedCallback } from "use-debounce";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useCandidatesStore,
  useCandidatesStore as useStore,
} from "@/stores/candidates-store";
import {
  CandidateWithRelations,
  CandidateStatus,
  candidateStatusOptions,
  candidateStatusConfig,
  getCandidateStatusLabel,
  getMatchScoreColorClass,
  getMatchScoreLabelClass,
  formatCandidateDate,
  parseJsonField,
  MatchDetails,
} from "@/types/candidate";
import { Job } from "@/types/job";
import { CandidateForm } from "./candidate-form";
import { CandidateNotes } from "./candidate-notes";
import { CandidateTimeline } from "./candidate-timeline";
import { MatchScoreDisplay } from "./match-score-display";
import { CandidateProfilePanel } from "./candidate-profile-panel";
import {
  Search,
  Plus,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Mail,
  Phone,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Users,
  Filter,
  ArrowUpDown,
  Loader2,
  ExternalLink,
  FileText,
  Briefcase,
  MapPin,
} from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

// Mock data for jobs (will be replaced with API)
const mockJobs: Job[] = [
  {
    id: "1",
    organizationId: "org1",
    title: "Desenvolvedor Full Stack",
    slug: "desenvolvedor-full-stack",
    department: "Engenharia",
    location: "São Paulo, SP",
    type: "FULL_TIME",
    remote: true,
    salaryMin: 8000,
    salaryMax: 12000,
    currency: "BRL",
    description: "Descrição da vaga",
    requirements: "Requisitos da vaga",
    benefits: "Benefícios",
    status: "PUBLISHED",
    publishedAt: new Date().toISOString(),
    expiresAt: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "2",
    organizationId: "org1",
    title: "Product Manager",
    slug: "product-manager",
    department: "Produto",
    location: "Remoto",
    type: "FULL_TIME",
    remote: true,
    salaryMin: 10000,
    salaryMax: 15000,
    currency: "BRL",
    description: "Descrição da vaga",
    requirements: "Requisitos da vaga",
    benefits: null,
    status: "PUBLISHED",
    publishedAt: new Date().toISOString(),
    expiresAt: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// Mock candidates for development
const mockCandidates: CandidateWithRelations[] = [
  {
    id: "1",
    organizationId: "org1",
    jobId: "1",
    pipelineStageId: "stage1",
    name: "Maria Silva",
    email: "maria.silva@email.com",
    phone: "(11) 99999-8888",
    linkedin: "https://linkedin.com/in/mariasilva",
    portfolio: null,
    resumeUrl: null,
    resumeText: null,
    photo: null,
    parsedSkills: JSON.stringify([
      { name: "React", level: "expert" },
      { name: "TypeScript", level: "advanced" },
      { name: "Node.js", level: "advanced" },
    ]),
    parsedExperience: JSON.stringify([
      { company: "Tech Corp", title: "Senior Developer", years: 3 },
      { company: "StartUp XYZ", title: "Full Stack Developer", years: 2 },
    ]),
    parsedEducation: JSON.stringify([
      { institution: "USP", degree: "Bacharelado em Ciência da Computação", year: "2018" },
    ]),
    parsedLanguages: JSON.stringify([
      { name: "Inglês", level: "advanced" },
      { name: "Português", level: "native" },
    ]),
    aiSummary: "Desenvolvedora experiente com forte background em React e Node.js.",
    matchScore: 85,
    matchDetails: JSON.stringify({
      skillsScore: 90,
      experienceScore: 80,
      educationScore: 85,
      overallScore: 85,
      strengths: ["Excelente domínio de React", "Boa experiência em projetos similares"],
      gaps: ["Pode melhorar conhecimentos em DevOps"],
    }),
    status: "INTERVIEWING",
    source: "LinkedIn",
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
    job: {
      id: "1",
      title: "Desenvolvedor Full Stack",
      department: "Engenharia",
    },
    pipelineStage: {
      id: "stage1",
      name: "Entrevista Técnica",
      color: "#F59E0B",
      order: 3,
    },
    _count: { notes: 2 },
  },
  {
    id: "2",
    organizationId: "org1",
    jobId: "1",
    pipelineStageId: "stage2",
    name: "João Santos",
    email: "joao.santos@email.com",
    phone: "(11) 98888-7777",
    linkedin: null,
    portfolio: "https://joaosantos.dev",
    resumeUrl: null,
    resumeText: null,
    photo: null,
    parsedSkills: JSON.stringify([
      { name: "Vue.js", level: "advanced" },
      { name: "Python", level: "intermediate" },
      { name: "Docker", level: "intermediate" },
    ]),
    parsedExperience: JSON.stringify([
      { company: "Digital Agency", title: "Frontend Developer", years: 2 },
    ]),
    parsedEducation: JSON.stringify([
      { institution: "UNICAMP", degree: "Bacharelado em Sistemas de Informação", year: "2020" },
    ]),
    parsedLanguages: null,
    aiSummary: "Desenvolvedor frontend com foco em Vue.js e interesse em aprender novas tecnologias.",
    matchScore: 65,
    matchDetails: JSON.stringify({
      skillsScore: 60,
      experienceScore: 70,
      educationScore: 70,
      overallScore: 65,
      strengths: ["Boa base em frontend"],
      gaps: ["Experiência limitada com React", "Conhecimentos intermediários em backend"],
    }),
    status: "SCREENING",
    source: "Indeed",
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
    job: {
      id: "1",
      title: "Desenvolvedor Full Stack",
      department: "Engenharia",
    },
    pipelineStage: {
      id: "stage2",
      name: "Triagem",
      color: "#3B82F6",
      order: 2,
    },
    _count: { notes: 0 },
  },
  {
    id: "3",
    organizationId: "org1",
    jobId: "2",
    pipelineStageId: null,
    name: "Ana Costa",
    email: "ana.costa@email.com",
    phone: null,
    linkedin: "https://linkedin.com/in/anacosta",
    portfolio: null,
    resumeUrl: null,
    resumeText: null,
    photo: null,
    parsedSkills: JSON.stringify([
      { name: "Product Management", level: "expert" },
      { name: "Agile", level: "expert" },
      { name: "Data Analysis", level: "advanced" },
    ]),
    parsedExperience: JSON.stringify([
      { company: "Big Tech", title: "Senior PM", years: 4 },
      { company: "Consulting Firm", title: "Product Analyst", years: 2 },
    ]),
    parsedEducation: JSON.stringify([
      { institution: "FGV", degree: "MBA em Gestão de Produtos", year: "2019" },
      { institution: "PUC", degree: "Engenharia de Produção", year: "2016" },
    ]),
    parsedLanguages: JSON.stringify([
      { name: "Inglês", level: "native" },
      { name: "Espanhol", level: "intermediate" },
    ]),
    aiSummary: "Product Manager experiente com histórico de sucesso em produtos digitais.",
    matchScore: 92,
    matchDetails: JSON.stringify({
      skillsScore: 95,
      experienceScore: 90,
      educationScore: 90,
      overallScore: 92,
      strengths: ["Experiência sólida em PM", "Excelente formação", "Background em dados"],
      gaps: [],
    }),
    status: "OFFERED",
    source: "Indicação",
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
    job: {
      id: "2",
      title: "Product Manager",
      department: "Produto",
    },
    pipelineStage: null,
    _count: { notes: 5 },
  },
];

// Get initials for avatar
function getInitials(name: string): string {
  const parts = name.split(" ");
  if (parts.length === 1) return parts[0].charAt(0).toUpperCase();
  return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
}

// Candidate card for mobile view
function CandidateCard({
  candidate,
  onView,
  onEdit,
  onDelete,
}: {
  candidate: CandidateWithRelations;
  onView: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const statusConfig = candidateStatusConfig[candidate.status];
  const matchDetails = parseJsonField<MatchDetails>(candidate.matchDetails);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
    >
      <div className="flex items-start gap-3">
        <Avatar className="h-10 w-10">
          <AvatarFallback className="bg-primary/10 text-primary">
            {getInitials(candidate.name)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="font-medium truncate">{candidate.name}</p>
              <p className="text-sm text-muted-foreground truncate">
                {candidate.email}
              </p>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={onView}>
                  <Eye className="h-4 w-4 mr-2" />
                  Ver Perfil Completo
                </DropdownMenuItem>
                <DropdownMenuItem onClick={onEdit}>
                  <Edit className="h-4 w-4 mr-2" />
                  Editar
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={onDelete}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Excluir
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant="outline" className="text-xs">
              {candidate.job?.title}
            </Badge>
            <Badge className={`text-xs ${statusConfig.color} ${statusConfig.bgColor}`}>
              {statusConfig.label}
            </Badge>
          </div>

          {candidate.matchScore !== null && (
            <div className="flex items-center gap-2 mt-2">
              <span className="text-xs text-muted-foreground">Match:</span>
              <Badge className={`text-xs ${getMatchScoreColorClass(candidate.matchScore)}`}>
                {candidate.matchScore}%
              </Badge>
            </div>
          )}

          <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {formatCandidateDate(candidate.createdAt)}
            </span>
            {candidate._count?.notes && candidate._count.notes > 0 && (
              <span className="flex items-center gap-1">
                <FileText className="h-3 w-3" />
                {candidate._count.notes} notas
              </span>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// Candidate detail dialog content
function CandidateDetailContent({
  candidate,
}: {
  candidate: CandidateWithRelations;
}) {
  const [activeTab, setActiveTab] = useState("overview");
  const matchDetails = parseJsonField<MatchDetails>(candidate.matchDetails);
  const skills = parseJsonField<Array<{ name: string; level?: string }>>(
    candidate.parsedSkills
  );
  const experience = parseJsonField<
    Array<{ company?: string; title?: string; years?: number }>
  >(candidate.parsedExperience);
  const education = parseJsonField<
    Array<{ institution?: string; degree: string; year?: string }>
  >(candidate.parsedEducation);

  const statusConfig = candidateStatusConfig[candidate.status];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start gap-4">
        <Avatar className="h-16 w-16">
          <AvatarFallback className="text-xl bg-primary/10 text-primary">
            {getInitials(candidate.name)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h2 className="text-xl font-bold">{candidate.name}</h2>
          <p className="text-muted-foreground">{candidate.email}</p>
          <div className="flex flex-wrap gap-2 mt-2">
            <Badge variant="outline">{candidate.job?.title}</Badge>
            <Badge className={`${statusConfig.color} ${statusConfig.bgColor}`}>
              {statusConfig.label}
            </Badge>
            {candidate.matchScore !== null && (
              <Badge className={getMatchScoreColorClass(candidate.matchScore)}>
                {candidate.matchScore}% Match
              </Badge>
            )}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Visão Geral</TabsTrigger>
          <TabsTrigger value="match">Match Score</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 mt-4">
          {/* Contact Info */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Contato</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {candidate.phone && (
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{candidate.phone}</span>
                </div>
              )}
              {candidate.linkedin && (
                <div className="flex items-center gap-2 text-sm">
                  <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  <a
                    href={candidate.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    LinkedIn
                  </a>
                </div>
              )}
              {candidate.portfolio && (
                <div className="flex items-center gap-2 text-sm">
                  <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  <a
                    href={candidate.portfolio}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    Portfolio
                  </a>
                </div>
              )}
              {candidate.source && (
                <div className="flex items-center gap-2 text-sm">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span>Origem: {candidate.source}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Skills */}
          {skills && skills.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Skills</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {skills.map((skill, index) => (
                    <Badge key={index} variant="secondary">
                      {skill.name}
                      {skill.level && ` (${skill.level})`}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Experience */}
          {experience && experience.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Experiência</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {experience.map((exp, index) => (
                    <div key={index} className="text-sm">
                      <p className="font-medium">
                        {exp.title || "Cargo não informado"}
                      </p>
                      <p className="text-muted-foreground">
                        {exp.company}
                        {exp.years && ` • ${exp.years} anos`}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Education */}
          {education && education.length > 0 && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Educação</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {education.map((edu, index) => (
                    <div key={index} className="text-sm">
                      <p className="font-medium">{edu.degree}</p>
                      {edu.institution && (
                        <p className="text-muted-foreground">
                          {edu.institution}
                          {edu.year && ` • ${edu.year}`}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Summary */}
          {candidate.aiSummary && (
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Resumo IA</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  {candidate.aiSummary}
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="match" className="mt-4">
          <MatchScoreDisplay
            score={candidate.matchScore}
            details={matchDetails}
            showBreakdown
          />
        </TabsContent>

        <TabsContent value="timeline" className="mt-4">
          <CandidateTimeline
            activities={[
              {
                id: "1",
                type: "CANDIDATE_APPLIED",
                description: `Candidatou-se para ${candidate.job?.title}`,
                createdAt: candidate.createdAt,
                member: null,
              },
            ]}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export function CandidatesList() {
  const {
    candidates,
    total,
    page,
    isLoading,
    filters,
    isNewCandidateDialogOpen,
    isDeletingCandidate,
    viewingCandidate,
    fetchCandidates,
    createCandidate,
    deleteCandidate,
    setFilters,
    setPage,
    openNewCandidateDialog,
    closeNewCandidateDialog,
    openDeleteCandidateDialog,
    closeDeleteCandidateDialog,
    openCandidateDetail,
    closeCandidateDetail,
  } = useCandidatesStore();

  const [searchValue, setSearchValue] = useState(filters.search || "");
  const [jobs, setJobs] = useState<Job[]>(mockJobs);
  const [isCreating, setIsCreating] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [useMockData, setUseMockData] = useState(false);
  const [profileCandidateId, setProfileCandidateId] = useState<string | null>(null);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Debounced search
  const debouncedSearch = useDebouncedCallback((value: string) => {
    setFilters({ search: value || undefined });
  }, 300);

  // Fetch candidates on mount and when filters change
  useEffect(() => {
    const loadData = async () => {
      try {
        await fetchCandidates();
      } catch (error) {
        console.error("Error fetching candidates, using mock data:", error);
        setUseMockData(true);
      }
    };
    loadData();
  }, [fetchCandidates, filters]);

  // Use mock data if API fails
  const displayCandidates = useMockData ? mockCandidates : candidates;
  const displayTotal = useMockData ? mockCandidates.length : total;

  // Handle search input change
  const handleSearchChange = (value: string) => {
    setSearchValue(value);
    debouncedSearch(value);
  };

  // Handle create candidate
  const handleCreateCandidate = async (data: any) => {
    setIsCreating(true);
    try {
      await createCandidate(data);
      toast.success("Candidato criado com sucesso!");
      closeNewCandidateDialog();
    } catch (error) {
      toast.error("Erro ao criar candidato");
    } finally {
      setIsCreating(false);
    }
  };

  // Handle delete candidate
  const handleDeleteCandidate = async () => {
    if (!isDeletingCandidate) return;

    setIsDeleting(true);
    try {
      const success = await deleteCandidate(isDeletingCandidate.id);
      if (success) {
        toast.success("Candidato excluído");
      } else {
        toast.error("Erro ao excluir candidato");
      }
    } catch (error) {
      toast.error("Erro ao excluir candidato");
    } finally {
      setIsDeleting(false);
      closeDeleteCandidateDialog();
    }
  };

  // Handle sort
  const handleSort = (sortBy: "name" | "matchScore" | "createdAt" | "status") => {
    setFilters({
      sortBy,
      sortOrder: filters.sortBy === sortBy && filters.sortOrder === "desc" ? "asc" : "desc",
    });
  };

  // Filter candidates by search (for mock data)
  const filteredCandidates = useMockData
    ? displayCandidates.filter((c) => {
        if (!filters.search) return true;
        const search = filters.search.toLowerCase();
        return (
          c.name.toLowerCase().includes(search) ||
          c.email.toLowerCase().includes(search)
        );
      })
    : displayCandidates;

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Candidatos</h1>
          <p className="text-muted-foreground mt-1">
            Gerencie todos os candidatos do seu processo seletivo
          </p>
        </div>
        <Button onClick={openNewCandidateDialog} className="gap-2">
          <Plus className="h-4 w-4" />
          Novo Candidato
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nome ou email..."
                value={searchValue}
                onChange={(e) => handleSearchChange(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Job Filter */}
            <Select
              value={filters.jobId || "ALL"}
              onValueChange={(value) =>
                setFilters({ jobId: value === "ALL" ? undefined : value })
              }
            >
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Todas as vagas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Todas as vagas</SelectItem>
                {jobs.map((job) => (
                  <SelectItem key={job.id} value={job.id}>
                    {job.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Status Filter */}
            <Select
              value={filters.status || "ALL"}
              onValueChange={(value) =>
                setFilters({ status: value as CandidateStatus | "ALL" })
              }
            >
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Todos os status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Todos os status</SelectItem>
                {candidateStatusOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Results count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {displayTotal} candidato{displayTotal !== 1 ? "s" : ""} encontrado
          {displayTotal !== 1 ? "s" : ""}
        </p>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center gap-4 p-4 rounded-lg border">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-1/4" />
                <Skeleton className="h-3 w-1/3" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && filteredCandidates.length === 0 && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="h-16 w-16 text-muted-foreground/50 mb-4" />
            <h3 className="text-lg font-medium mb-2">Nenhum candidato encontrado</h3>
            <p className="text-muted-foreground text-center mb-4">
              Comece adicionando candidatos ao seu processo seletivo
            </p>
            <Button onClick={openNewCandidateDialog} className="gap-2">
              <Plus className="h-4 w-4" />
              Adicionar Candidato
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Desktop Table View */}
      {!isLoading && filteredCandidates.length > 0 && (
        <div className="hidden lg:block">
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[250px]">
                    <button
                      onClick={() => handleSort("name")}
                      className="flex items-center gap-1 hover:text-foreground"
                    >
                      Nome
                      <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Vaga</TableHead>
                  <TableHead>Etapa</TableHead>
                  <TableHead className="text-center">
                    <button
                      onClick={() => handleSort("matchScore")}
                      className="flex items-center gap-1 hover:text-foreground mx-auto"
                    >
                      Match
                      <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </TableHead>
                  <TableHead>
                    <button
                      onClick={() => handleSort("status")}
                      className="flex items-center gap-1 hover:text-foreground"
                    >
                      Status
                      <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </TableHead>
                  <TableHead>
                    <button
                      onClick={() => handleSort("createdAt")}
                      className="flex items-center gap-1 hover:text-foreground"
                    >
                      Data
                      <ArrowUpDown className="h-3 w-3" />
                    </button>
                  </TableHead>
                  <TableHead className="w-[50px]"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCandidates.map((candidate, index) => {
                  const statusConfig = candidateStatusConfig[candidate.status] || {
                    label: candidate.status,
                    color: "text-gray-700",
                    bgColor: "bg-gray-100",
                  };
                  return (
                    <motion.tr
                      key={candidate.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ delay: index * 0.03 }}
                      className="group cursor-pointer hover:bg-muted/50 border-b transition-colors"
                      onClick={() => {
                        setProfileCandidateId(candidate.id);
                        setIsProfileOpen(true);
                      }}
                    >
                      <TableCell className="p-4">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-primary/10 text-primary text-xs">
                              {getInitials(candidate.name)}
                            </AvatarFallback>
                          </Avatar>
                          <span className="font-medium">{candidate.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="p-4 text-muted-foreground">
                        {candidate.email}
                      </TableCell>
                      <TableCell className="p-4">
                        <Badge variant="outline" className="text-xs">
                          {candidate.job?.title}
                        </Badge>
                      </TableCell>
                      <TableCell className="p-4">
                        {candidate.pipelineStage ? (
                          <div className="flex items-center gap-2">
                            <div
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: candidate.pipelineStage.color }}
                            />
                            <span className="text-sm">
                              {candidate.pipelineStage.name}
                            </span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-sm">
                            Não definida
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="p-4 text-center">
                        {candidate.matchScore !== null ? (
                          <Badge
                            className={getMatchScoreColorClass(candidate.matchScore)}
                          >
                            {candidate.matchScore}%
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-sm">-</span>
                        )}
                      </TableCell>
                      <TableCell className="p-4">
                        <Badge
                          className={`${statusConfig.color} ${statusConfig.bgColor}`}
                        >
                          {statusConfig.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="p-4 text-muted-foreground">
                        {formatCandidateDate(candidate.createdAt)}
                      </TableCell>
                      <TableCell className="p-4">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 opacity-0 group-hover:opacity-100"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.stopPropagation();
                                setProfileCandidateId(candidate.id);
                                setIsProfileOpen(true);
                              }}
                            >
                              <Eye className="h-4 w-4 mr-2" />
                              Ver Detalhes
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.stopPropagation();
                                // Edit functionality
                              }}
                            >
                              <Edit className="h-4 w-4 mr-2" />
                              Editar
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.stopPropagation();
                                openDeleteCandidateDialog(candidate);
                              }}
                              className="text-destructive focus:text-destructive"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Excluir
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </motion.tr>
                  );
                })}
              </TableBody>
            </Table>
          </Card>
        </div>
      )}

      {/* Mobile Card View */}
      {!isLoading && filteredCandidates.length > 0 && (
        <div className="lg:hidden space-y-4">
          {filteredCandidates.map((candidate, index) => (
            <motion.div
              key={candidate.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.03 }}
            >
              <CandidateCard
                candidate={candidate}
                onView={() => {
                  setProfileCandidateId(candidate.id);
                  setIsProfileOpen(true);
                }}
                onEdit={() => {
                  // Edit functionality
                }}
                onDelete={() => openDeleteCandidateDialog(candidate)}
              />
            </motion.div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {!isLoading && filteredCandidates.length > 0 && displayTotal > 20 && (
        <div className="flex items-center justify-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page - 1)}
            disabled={page === 1}
          >
            <ChevronLeft className="h-4 w-4" />
            Anterior
          </Button>
          <span className="text-sm text-muted-foreground">
            Página {page} de {Math.ceil(displayTotal / 20)}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setPage(page + 1)}
            disabled={page >= Math.ceil(displayTotal / 20)}
          >
            Próxima
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* New Candidate Dialog */}
      <Dialog open={isNewCandidateDialogOpen} onOpenChange={closeNewCandidateDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Novo Candidato</DialogTitle>
            <DialogDescription>
              Adicione um novo candidato ao processo seletivo
            </DialogDescription>
          </DialogHeader>
          <CandidateForm
            jobs={jobs}
            onSubmit={handleCreateCandidate}
            onCancel={closeNewCandidateDialog}
            isLoading={isCreating}
          />
        </DialogContent>
      </Dialog>

      {/* Candidate Profile Panel */}
      <CandidateProfilePanel
        candidateId={profileCandidateId}
        open={isProfileOpen}
        onClose={() => {
          setIsProfileOpen(false);
          setProfileCandidateId(null);
        }}
        onEdit={(id) => {
          setIsProfileOpen(false);
          // TODO: Open edit dialog
        }}
      />

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!isDeletingCandidate}
        onOpenChange={(open) => !open && closeDeleteCandidateDialog()}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir candidato</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir{" "}
              <strong>{isDeletingCandidate?.name}</strong>? Esta ação não pode ser
              desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteCandidate}
              disabled={isDeleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {isDeleting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Excluindo...
                </>
              ) : (
                "Excluir"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
