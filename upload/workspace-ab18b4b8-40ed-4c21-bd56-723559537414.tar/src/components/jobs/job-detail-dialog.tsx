"use client";

/**
 * Job Detail Dialog - Zion Recruit
 * Shows complete job details including DISC profile suggestion
 */

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Briefcase,
  MapPin,
  DollarSign,
  FileText,
  ListChecks,
  Gift,
  Brain,
  Loader2,
  RefreshCw,
  Users,
  Calendar,
  Building2,
  Edit,
  Trash2,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import {
  JobWithCandidates,
  getJobStatusLabel,
  getJobTypeLabel,
  formatSalary,
  JobStatus,
  JobType,
} from "@/types/job";
import { DISCProfileSuggestionCard, DISCBadge } from "./disc-profile-suggestion";

// ============================================
// Extended Job Type with DISC fields
// ============================================

interface JobWithDISC extends JobWithCandidates {
  discProfileRequired: string | null;
  discProfileReason: string | null;
  discIdealCombo: string | null;
  discIdealRoles: string | null;
  discWorkEnvironment: string | null;
  aiParsedSkills: string | null;
  aiParsedKeywords: string | null;
  aiParsedSeniority: string | null;
  aiSummary: string | null;
}

// ============================================
// Props
// ============================================

interface JobDetailDialogProps {
  job: JobWithDISC | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onEdit?: (job: JobWithDISC) => void;
  onDelete?: (job: JobWithDISC) => void;
}

// ============================================
// Status Colors
// ============================================

const statusColors: Record<JobStatus, string> = {
  DRAFT: "secondary",
  PUBLISHED: "default",
  CLOSED: "outline",
  ARCHIVED: "destructive",
};

// ============================================
// Component
// ============================================

export function JobDetailDialog({
  job,
  open,
  onOpenChange,
  onEdit,
  onDelete,
}: JobDetailDialogProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzedJob, setAnalyzedJob] = useState<JobWithDISC | null>(null);

  const currentJob = analyzedJob || job;

  const handleAnalyzeDISC = async () => {
    if (!currentJob) return;

    setIsAnalyzing(true);
    try {
      const response = await fetch(`/api/jobs/${currentJob.id}/analyze-disc`, {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error("Falha ao analisar vaga");
      }

      const data = await response.json();
      setAnalyzedJob({
        ...currentJob,
        ...data.job,
      });

      toast.success("Análise DISC concluída!", {
        description: "O perfil DISC ideal foi definido para esta vaga.",
      });
    } catch (error) {
      toast.error("Erro ao analisar vaga", {
        description: "Tente novamente em alguns instantes.",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (!currentJob) return null;

  const salary = formatSalary(currentJob.salaryMin, currentJob.salaryMax, currentJob.currency);
  const parsedSkills = currentJob.aiParsedSkills ? JSON.parse(currentJob.aiParsedSkills) : [];
  const parsedKeywords = currentJob.aiParsedKeywords ? JSON.parse(currentJob.aiParsedKeywords) : [];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-1">
              <DialogTitle className="text-xl">{currentJob.title}</DialogTitle>
              <DialogDescription className="flex items-center gap-2">
                {currentJob.department && (
                  <>
                    <Building2 className="h-3.5 w-3.5" />
                    <span>{currentJob.department}</span>
                  </>
                )}
                {currentJob.location && (
                  <>
                    <MapPin className="h-3.5 w-3.5" />
                    <span>{currentJob.location}</span>
                  </>
                )}
              </DialogDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={statusColors[currentJob.status] as "default" | "secondary" | "outline" | "destructive"}>
                {getJobStatusLabel(currentJob.status)}
              </Badge>
              <Badge variant="outline">{getJobTypeLabel(currentJob.type)}</Badge>
              {currentJob.remote && (
                <Badge variant="outline" className="text-blue-600 border-blue-200">
                  Remoto
                </Badge>
              )}
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="details" className="flex-1 overflow-hidden flex flex-col">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="details">Detalhes</TabsTrigger>
            <TabsTrigger value="disc">Perfil DISC</TabsTrigger>
            <TabsTrigger value="ai">Análise IA</TabsTrigger>
          </TabsList>

          <div className="flex-1 overflow-y-auto mt-4">
            <TabsContent value="details" className="space-y-6 m-0">
              {/* Quick Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Users className="h-4 w-4" />
                    <span className="text-sm">Candidatos</span>
                  </div>
                  <div className="text-2xl font-bold">{currentJob.candidatesCount}</div>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <DollarSign className="h-4 w-4" />
                    <span className="text-sm">Salário</span>
                  </div>
                  <div className="text-lg font-semibold">{salary || "Não definido"}</div>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Briefcase className="h-4 w-4" />
                    <span className="text-sm">Tipo</span>
                  </div>
                  <div className="text-lg font-semibold">{getJobTypeLabel(currentJob.type)}</div>
                </div>
                <div className="p-4 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2 text-muted-foreground mb-1">
                    <Calendar className="h-4 w-4" />
                    <span className="text-sm">Criado</span>
                  </div>
                  <div className="text-sm font-medium">
                    {new Date(currentJob.createdAt).toLocaleDateString("pt-BR")}
                  </div>
                </div>
              </div>

              {/* DISC Badge */}
              {currentJob.discProfileRequired && (
                <div className="flex items-center gap-2 p-4 rounded-lg bg-gradient-to-r from-primary/5 to-primary/10 border">
                  <Brain className="h-5 w-5 text-primary" />
                  <span className="text-sm font-medium">Perfil DISC Ideal:</span>
                  <DISCBadge profile={currentJob.discProfileRequired} />
                </div>
              )}

              {/* Description */}
              <div className="space-y-2">
                <h4 className="font-medium flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  Descrição
                </h4>
                <div className="prose prose-sm dark:prose-invert max-w-none p-4 rounded-lg bg-muted/30">
                  {currentJob.description}
                </div>
              </div>

              {/* Requirements */}
              <div className="space-y-2">
                <h4 className="font-medium flex items-center gap-2">
                  <ListChecks className="h-4 w-4" />
                  Requisitos
                </h4>
                <div className="prose prose-sm dark:prose-invert max-w-none p-4 rounded-lg bg-muted/30">
                  {currentJob.requirements}
                </div>
              </div>

              {/* Benefits */}
              {currentJob.benefits && (
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <Gift className="h-4 w-4" />
                    Benefícios
                  </h4>
                  <div className="prose prose-sm dark:prose-invert max-w-none p-4 rounded-lg bg-muted/30">
                    {currentJob.benefits}
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="disc" className="m-0">
              <div className="space-y-4">
                {currentJob.discProfileRequired ? (
                  <DISCProfileSuggestionCard job={currentJob} />
                ) : (
                  <div className="text-center py-8">
                    <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">Perfil DISC não analisado</h3>
                    <p className="text-muted-foreground mb-4">
                      Clique no botão abaixo para que a IA analise a vaga e sugira o perfil DISC ideal.
                    </p>
                    <Button onClick={handleAnalyzeDISC} disabled={isAnalyzing}>
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Analisando...
                        </>
                      ) : (
                        <>
                          <Brain className="h-4 w-4 mr-2" />
                          Analisar Perfil DISC
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {currentJob.discProfileRequired && (
                  <Button
                    variant="outline"
                    onClick={handleAnalyzeDISC}
                    disabled={isAnalyzing}
                    className="w-full"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Reanalisando...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2" />
                        Reanalisar Perfil DISC
                      </>
                    )}
                  </Button>
                )}
              </div>
            </TabsContent>

            <TabsContent value="ai" className="m-0">
              <div className="space-y-6">
                {/* AI Summary */}
                {currentJob.aiSummary ? (
                  <div className="p-4 rounded-lg bg-gradient-to-r from-primary/5 to-primary/10 border">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <Brain className="h-4 w-4 text-primary" />
                      Resumo IA
                    </h4>
                    <p className="text-sm text-muted-foreground">{currentJob.aiSummary}</p>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Brain className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">Análise IA não disponível</h3>
                    <p className="text-muted-foreground mb-4">
                      Clique no botão abaixo para que a IA analise a vaga.
                    </p>
                    <Button onClick={handleAnalyzeDISC} disabled={isAnalyzing}>
                      {isAnalyzing ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Analisando...
                        </>
                      ) : (
                        <>
                          <Brain className="h-4 w-4 mr-2" />
                          Analisar com IA
                        </>
                      )}
                    </Button>
                  </div>
                )}

                {/* Seniority */}
                {currentJob.aiParsedSeniority && (
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">Senioridade sugerida:</span>
                    <Badge variant="secondary">{currentJob.aiParsedSeniority}</Badge>
                  </div>
                )}

                {/* Skills */}
                {parsedSkills.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-medium">Habilidades Extraídas</h4>
                    <div className="flex flex-wrap gap-2">
                      {parsedSkills.map((skill: string, index: number) => (
                        <Badge key={index} variant="outline">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Keywords */}
                {parsedKeywords.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-medium">Palavras-chave</h4>
                    <div className="flex flex-wrap gap-2">
                      {parsedKeywords.map((keyword: string, index: number) => (
                        <Badge key={index} variant="secondary">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
          </div>
        </Tabs>

        <Separator />

        {/* Actions */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-2">
            {onDelete && (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => onDelete(currentJob)}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Excluir
              </Button>
            )}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Fechar
            </Button>
            {onEdit && (
              <Button onClick={() => onEdit(currentJob)}>
                <Edit className="h-4 w-4 mr-1" />
                Editar
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
