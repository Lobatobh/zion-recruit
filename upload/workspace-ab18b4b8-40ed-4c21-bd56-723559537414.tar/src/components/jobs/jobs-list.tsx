"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  Search,
  Plus,
  MoreHorizontal,
  Edit,
  Copy,
  Archive,
  Trash2,
  Briefcase,
  MapPin,
  Users,
  Clock,
} from "lucide-react";
import { useJobsStore } from "@/stores/jobs-store";
import {
  JobWithCandidates,
  JobStatus,
  getJobStatusLabel,
  getJobTypeLabel,
  formatSalary,
} from "@/types/job";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

const statusColors: Record<JobStatus, string> = {
  DRAFT: "bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300",
  PUBLISHED: "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300",
  CLOSED: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300",
  ARCHIVED: "bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300",
};

function JobStatusBadge({ status }: { status: JobStatus }) {
  return (
    <Badge variant="secondary" className={statusColors[status]}>
      {getJobStatusLabel(status)}
    </Badge>
  );
}

function JobTableRow({
  job,
  index = 0,
  onEdit,
  onDuplicate,
  onArchive,
  onDelete,
}: {
  job: JobWithCandidates;
  index?: number;
  onEdit: () => void;
  onDuplicate: () => void;
  onArchive: () => void;
  onDelete: () => void;
}) {
  return (
    <motion.tr
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className="group hover:bg-muted/50 border-b transition-colors"
    >
      <TableCell className="p-4">
        <div className="flex items-start gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Briefcase className="h-5 w-5" />
          </div>
          <div>
            <div className="font-medium">{job.title}</div>
            {job.department && (
              <div className="text-sm text-muted-foreground">
                {job.department}
              </div>
            )}
          </div>
        </div>
      </TableCell>
      <TableCell className="p-4">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          <MapPin className="h-4 w-4" />
          <span className="text-sm">
            {job.location || "Não definido"}
            {job.remote && " (Remoto)"}
          </span>
        </div>
      </TableCell>
      <TableCell className="p-4">
        <JobStatusBadge status={job.status} />
      </TableCell>
      <TableCell className="p-4">
        <div className="flex items-center gap-1.5">
          <Users className="h-4 w-4 text-muted-foreground" />
          <span className="font-medium">{job.candidatesCount}</span>
        </div>
      </TableCell>
      <TableCell className="p-4">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          <Clock className="h-4 w-4" />
          <span className="text-sm">
            {formatDistanceToNow(new Date(job.createdAt), {
              addSuffix: true,
              locale: ptBR,
            })}
          </span>
        </div>
      </TableCell>
      <TableCell className="p-4 text-right">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onEdit}>
              <Edit className="mr-2 h-4 w-4" />
              Editar
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onDuplicate}>
              <Copy className="mr-2 h-4 w-4" />
              Duplicar
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            {job.status !== "ARCHIVED" && (
              <DropdownMenuItem onClick={onArchive}>
                <Archive className="mr-2 h-4 w-4" />
                Arquivar
              </DropdownMenuItem>
            )}
            <DropdownMenuItem
              onClick={onDelete}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Excluir
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </TableCell>
    </motion.tr>
  );
}

function JobCard({
  job,
  onEdit,
  onDuplicate,
  onArchive,
  onDelete,
}: {
  job: JobWithCandidates;
  onEdit: () => void;
  onDuplicate: () => void;
  onArchive: () => void;
  onDelete: () => void;
}) {
  const salary = formatSalary(job.salaryMin, job.salaryMax, job.currency);

  return (
    <Card className="group hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Briefcase className="h-5 w-5" />
            </div>
            <div className="space-y-1">
              <div className="font-medium">{job.title}</div>
              <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                {job.department && <span>{job.department}</span>}
                {job.department && job.location && <span>•</span>}
                {job.location && <span>{job.location}</span>}
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}>
                <Edit className="mr-2 h-4 w-4" />
                Editar
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onDuplicate}>
                <Copy className="mr-2 h-4 w-4" />
                Duplicar
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {job.status !== "ARCHIVED" && (
                <DropdownMenuItem onClick={onArchive}>
                  <Archive className="mr-2 h-4 w-4" />
                  Arquivar
                </DropdownMenuItem>
              )}
              <DropdownMenuItem
                onClick={onDelete}
                className="text-destructive focus:text-destructive"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Excluir
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <JobStatusBadge status={job.status} />
          <Badge variant="outline">{getJobTypeLabel(job.type)}</Badge>
          {job.remote && (
            <Badge variant="outline" className="text-blue-600">
              Remoto
            </Badge>
          )}
        </div>

        <div className="mt-4 flex items-center justify-between text-sm">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5 text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{job.candidatesCount} candidatos</span>
            </div>
            {salary && (
              <span className="text-muted-foreground">{salary}</span>
            )}
          </div>
          <span className="text-muted-foreground">
            {formatDistanceToNow(new Date(job.createdAt), {
              addSuffix: true,
              locale: ptBR,
            })}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

function JobsListSkeleton() {
  return (
    <div className="space-y-4">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="flex items-center gap-4 p-4 border rounded-lg">
          <Skeleton className="h-10 w-10 rounded-lg" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-48" />
            <Skeleton className="h-3 w-32" />
          </div>
          <Skeleton className="h-6 w-20" />
          <Skeleton className="h-4 w-16" />
        </div>
      ))}
    </div>
  );
}

function EmptyState({ onNewJob }: { onNewJob: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center justify-center py-16 text-center"
    >
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-muted">
        <Briefcase className="h-10 w-10 text-muted-foreground" />
      </div>
      <h3 className="mt-4 text-lg font-semibold">Nenhuma vaga encontrada</h3>
      <p className="mt-2 text-sm text-muted-foreground max-w-sm">
        Comece criando sua primeira vaga para receber candidatos.
      </p>
      <Button onClick={onNewJob} className="mt-6">
        <Plus className="mr-2 h-4 w-4" />
        Nova Vaga
      </Button>
    </motion.div>
  );
}

export function JobsList() {
  const {
    jobs,
    isLoading,
    error,
    filters,
    fetchJobs,
    setFilters,
    openNewJobDialog,
    openEditJobDialog,
    deleteJob,
    duplicateJob,
    updateJob,
    isDeletingJob,
    openDeleteJobDialog,
    closeDeleteJobDialog,
  } = useJobsStore();

  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(
    null
  );

  useEffect(() => {
    fetchJobs();
  }, [filters.status]);

  useEffect(() => {
    if (error) {
      toast.error(error);
    }
  }, [error]);

  const handleSearch = (value: string) => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const timeout = setTimeout(() => {
      setFilters({ search: value || undefined });
      fetchJobs();
    }, 300);

    setSearchTimeout(timeout);
  };

  const handleEdit = (job: JobWithCandidates) => {
    openEditJobDialog(job);
  };

  const handleDuplicate = async (job: JobWithCandidates) => {
    toast.promise(duplicateJob(job.id), {
      loading: "Duplicando vaga...",
      success: "Vaga duplicada com sucesso!",
      error: "Erro ao duplicar vaga",
    });
  };

  const handleArchive = async (job: JobWithCandidates) => {
    toast.promise(updateJob(job.id, { status: "ARCHIVED" }), {
      loading: "Arquivando vaga...",
      success: "Vaga arquivada com sucesso!",
      error: "Erro ao arquivar vaga",
    });
  };

  const handleDelete = async () => {
    if (!isDeletingJob) return;

    const success = await deleteJob(isDeletingJob.id);
    if (success) {
      toast.success("Vaga excluída com sucesso!");
    }
  };

  // Filter out archived jobs from display unless specifically requested
  const displayJobs = jobs;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Vagas</h1>
          <p className="text-muted-foreground">
            Gerencie suas vagas e acompanhe candidatos
          </p>
        </div>
        <Button onClick={openNewJobDialog}>
          <Plus className="mr-2 h-4 w-4" />
          Nova Vaga
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-4 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Buscar vagas..."
            className="pl-9"
            onChange={(e) => handleSearch(e.target.value)}
          />
        </div>
        <Select
          value={filters.status || "ALL"}
          onValueChange={(value) =>
            setFilters({ status: value as JobStatus | "ALL" })
          }
        >
          <SelectTrigger className="w-full sm:w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">Todos</SelectItem>
            <SelectItem value="DRAFT">Rascunho</SelectItem>
            <SelectItem value="PUBLISHED">Publicada</SelectItem>
            <SelectItem value="CLOSED">Fechada</SelectItem>
            <SelectItem value="ARCHIVED">Arquivada</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Content */}
      {isLoading ? (
        <JobsListSkeleton />
      ) : displayJobs.length === 0 ? (
        <EmptyState onNewJob={openNewJobDialog} />
      ) : (
        <>
          {/* Desktop Table View */}
          <div className="hidden md:block rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Título</TableHead>
                  <TableHead>Localização</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Candidatos</TableHead>
                  <TableHead>Criado</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {displayJobs.map((job, index) => (
                  <JobTableRow
                    key={job.id}
                    job={job}
                    index={index}
                    onEdit={() => handleEdit(job)}
                    onDuplicate={() => handleDuplicate(job)}
                    onArchive={() => handleArchive(job)}
                    onDelete={() => openDeleteJobDialog(job)}
                  />
                ))}
              </TableBody>
            </Table>
          </div>

          {/* Mobile Card View */}
          <div className="grid gap-4 md:hidden">
            {displayJobs.map((job, index) => (
              <motion.div
                key={job.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <JobCard
                  job={job}
                  onEdit={() => handleEdit(job)}
                  onDuplicate={() => handleDuplicate(job)}
                  onArchive={() => handleArchive(job)}
                  onDelete={() => openDeleteJobDialog(job)}
                />
              </motion.div>
            ))}
          </div>
        </>
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!isDeletingJob} onOpenChange={(open) => !open && closeDeleteJobDialog()}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir vaga</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir a vaga &quot;{isDeletingJob?.title}&quot;?
              Esta ação não pode ser desfeita. A vaga será arquivada e não aparecerá
              mais na lista principal.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
