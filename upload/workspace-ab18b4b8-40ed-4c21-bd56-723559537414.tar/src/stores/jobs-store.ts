import { create } from "zustand";
import {
  Job,
  JobWithCandidates,
  JobFilters,
  CreateJobInput,
  UpdateJobInput,
} from "@/types/job";

interface JobsState {
  // Data
  jobs: JobWithCandidates[];
  selectedJob: Job | null;
  total: number;

  // UI State
  isLoading: boolean;
  error: string | null;
  filters: JobFilters;

  // Dialog State
  isNewJobDialogOpen: boolean;
  editingJob: Job | null;
  isDeletingJob: Job | null;

  // Actions
  fetchJobs: () => Promise<void>;
  fetchJob: (id: string) => Promise<void>;
  createJob: (data: CreateJobInput) => Promise<Job | null>;
  updateJob: (id: string, data: UpdateJobInput) => Promise<Job | null>;
  deleteJob: (id: string) => Promise<boolean>;
  duplicateJob: (id: string) => Promise<Job | null>;

  // Filter Actions
  setFilters: (filters: Partial<JobFilters>) => void;
  resetFilters: () => void;

  // Dialog Actions
  openNewJobDialog: () => void;
  closeNewJobDialog: () => void;
  openEditJobDialog: (job: Job) => void;
  closeEditJobDialog: () => void;
  openDeleteJobDialog: (job: Job) => void;
  closeDeleteJobDialog: () => void;

  // Utility Actions
  setSelectedJob: (job: Job | null) => void;
  clearError: () => void;
  reset: () => void;
}

const initialFilters: JobFilters = {
  status: "ALL",
  department: undefined,
  search: undefined,
};

const initialState = {
  jobs: [],
  selectedJob: null,
  total: 0,
  isLoading: false,
  error: null,
  filters: initialFilters,
  isNewJobDialogOpen: false,
  editingJob: null,
  isDeletingJob: null,
};

export const useJobsStore = create<JobsState>((set, get) => ({
  ...initialState,

  // Fetch all jobs
  fetchJobs: async () => {
    const { filters } = get();
    set({ isLoading: true, error: null });

    try {
      const params = new URLSearchParams();
      if (filters.status && filters.status !== "ALL") {
        params.append("status", filters.status);
      }
      if (filters.search) {
        params.append("search", filters.search);
      }
      if (filters.department) {
        params.append("department", filters.department);
      }

      const response = await fetch(`/api/jobs?${params.toString()}`);
      if (!response.ok) {
        throw new Error("Failed to fetch jobs");
      }

      const data = await response.json();
      set({ jobs: data.jobs, total: data.total, isLoading: false });
    } catch (error) {
      console.error("Error fetching jobs:", error);
      set({
        error: "Erro ao carregar vagas. Tente novamente.",
        isLoading: false,
      });
    }
  },

  // Fetch single job
  fetchJob: async (id: string) => {
    set({ isLoading: true, error: null });

    try {
      const response = await fetch(`/api/jobs/${id}`);
      if (!response.ok) {
        throw new Error("Failed to fetch job");
      }

      const data = await response.json();
      set({ selectedJob: data.job, isLoading: false });
    } catch (error) {
      console.error("Error fetching job:", error);
      set({
        error: "Erro ao carregar vaga. Tente novamente.",
        isLoading: false,
      });
    }
  },

  // Create job
  createJob: async (data: CreateJobInput) => {
    set({ isLoading: true, error: null });

    try {
      const response = await fetch("/api/jobs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to create job");
      }

      const result = await response.json();

      // Refresh jobs list
      await get().fetchJobs();
      set({ isNewJobDialogOpen: false, isLoading: false });

      return result.job;
    } catch (error) {
      console.error("Error creating job:", error);
      set({
        error:
          error instanceof Error ? error.message : "Erro ao criar vaga",
        isLoading: false,
      });
      return null;
    }
  },

  // Update job
  updateJob: async (id: string, data: UpdateJobInput) => {
    set({ isLoading: true, error: null });

    try {
      const response = await fetch(`/api/jobs/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to update job");
      }

      const result = await response.json();

      // Refresh jobs list
      await get().fetchJobs();
      set({ editingJob: null, isLoading: false });

      return result.job;
    } catch (error) {
      console.error("Error updating job:", error);
      set({
        error:
          error instanceof Error ? error.message : "Erro ao atualizar vaga",
        isLoading: false,
      });
      return null;
    }
  },

  // Delete job (soft delete)
  deleteJob: async (id: string) => {
    set({ isLoading: true, error: null });

    try {
      const response = await fetch(`/api/jobs/${id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Failed to delete job");
      }

      // Refresh jobs list
      await get().fetchJobs();
      set({ isDeletingJob: null, isLoading: false });

      return true;
    } catch (error) {
      console.error("Error deleting job:", error);
      set({
        error:
          error instanceof Error ? error.message : "Erro ao excluir vaga",
        isLoading: false,
      });
      return false;
    }
  },

  // Duplicate job
  duplicateJob: async (id: string) => {
    const { jobs } = get();
    const jobToDuplicate = jobs.find((j) => j.id === id);

    if (!jobToDuplicate) {
      set({ error: "Vaga não encontrada" });
      return null;
    }

    return get().createJob({
      title: `${jobToDuplicate.title} (Cópia)`,
      department: jobToDuplicate.department,
      location: jobToDuplicate.location,
      type: jobToDuplicate.type,
      remote: jobToDuplicate.remote,
      salaryMin: jobToDuplicate.salaryMin,
      salaryMax: jobToDuplicate.salaryMax,
      currency: jobToDuplicate.currency,
      description: jobToDuplicate.description,
      requirements: jobToDuplicate.requirements,
      benefits: jobToDuplicate.benefits,
      status: "DRAFT",
    });
  },

  // Filter Actions
  setFilters: (filters: Partial<JobFilters>) => {
    set((state) => ({
      filters: { ...state.filters, ...filters },
    }));
  },

  resetFilters: () => {
    set({ filters: initialFilters });
  },

  // Dialog Actions
  openNewJobDialog: () => {
    set({ isNewJobDialogOpen: true });
  },

  closeNewJobDialog: () => {
    set({ isNewJobDialogOpen: false });
  },

  openEditJobDialog: (job: Job) => {
    set({ editingJob: job });
  },

  closeEditJobDialog: () => {
    set({ editingJob: null });
  },

  openDeleteJobDialog: (job: Job) => {
    set({ isDeletingJob: job });
  },

  closeDeleteJobDialog: () => {
    set({ isDeletingJob: null });
  },

  // Utility Actions
  setSelectedJob: (job: Job | null) => {
    set({ selectedJob: job });
  },

  clearError: () => {
    set({ error: null });
  },

  reset: () => {
    set(initialState);
  },
}));
