import { z } from "zod";

// Enums matching Prisma schema
export const JobTypeSchema = z.enum([
  "FULL_TIME",
  "PART_TIME",
  "CONTRACT",
  "INTERNSHIP",
  "FREELANCE",
]);

export const JobStatusSchema = z.enum([
  "DRAFT",
  "PUBLISHED",
  "CLOSED",
  "ARCHIVED",
]);

// Type definitions
export type JobType = z.infer<typeof JobTypeSchema>;
export type JobStatus = z.infer<typeof JobStatusSchema>;

// Job interface (from database)
export interface Job {
  id: string;
  organizationId: string;
  title: string;
  slug: string;
  department: string | null;
  location: string | null;
  type: JobType;
  remote: boolean;
  salaryMin: number | null;
  salaryMax: number | null;
  currency: string;
  description: string;
  requirements: string;
  benefits: string | null;
  status: JobStatus;
  publishedAt: string | null;
  expiresAt: string | null;
  createdAt: string;
  updatedAt: string;
  _count?: {
    candidates: number;
  };
}

// Job with candidates count
export interface JobWithCandidates extends Job {
  candidatesCount: number;
}

// Create job schema
export const createJobSchema = z.object({
  title: z.string().min(1, "Título é obrigatório").max(200, "Título muito longo"),
  department: z.string().max(100).optional().nullable(),
  location: z.string().max(200).optional().nullable(),
  type: JobTypeSchema.default("FULL_TIME"),
  remote: z.boolean().default(false),
  salaryMin: z.number().min(0).optional().nullable(),
  salaryMax: z.number().min(0).optional().nullable(),
  currency: z.string().default("BRL"),
  description: z.string().min(1, "Descrição é obrigatória"),
  requirements: z.string().min(1, "Requisitos são obrigatórios"),
  benefits: z.string().optional().nullable(),
  status: JobStatusSchema.default("DRAFT"),
});

export type CreateJobInput = z.infer<typeof createJobSchema>;

// Update job schema (partial)
export const updateJobSchema = createJobSchema.partial();

export type UpdateJobInput = z.infer<typeof updateJobSchema>;

// Job filters
export interface JobFilters {
  status?: JobStatus | "ALL";
  department?: string;
  search?: string;
}

// Job list response
export interface JobsListResponse {
  jobs: JobWithCandidates[];
  total: number;
}

// Job API responses
export interface JobApiResponse {
  job: Job;
}

// Form select options
export const jobTypeOptions: { value: JobType; label: string }[] = [
  { value: "FULL_TIME", label: "Tempo Integral" },
  { value: "PART_TIME", label: "Meio Período" },
  { value: "CONTRACT", label: "Contrato" },
  { value: "INTERNSHIP", label: "Estágio" },
  { value: "FREELANCE", label: "Freelance" },
];

export const jobStatusOptions: { value: JobStatus; label: string }[] = [
  { value: "DRAFT", label: "Rascunho" },
  { value: "PUBLISHED", label: "Publicada" },
  { value: "CLOSED", label: "Fechada" },
  { value: "ARCHIVED", label: "Arquivada" },
];

// Helper functions
export function getJobStatusLabel(status: JobStatus): string {
  const option = jobStatusOptions.find((opt) => opt.value === status);
  return option?.label || status;
}

export function getJobTypeLabel(type: JobType): string {
  const option = jobTypeOptions.find((opt) => opt.value === type);
  return option?.label || type;
}

export function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function formatSalary(
  min: number | null,
  max: number | null,
  currency: string
): string | null {
  if (!min && !max) return null;

  const formatter = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });

  if (min && max) {
    return `${formatter.format(min)} - ${formatter.format(max)}`;
  }

  if (min) {
    return `A partir de ${formatter.format(min)}`;
  }

  if (max) {
    return `Até ${formatter.format(max)}`;
  }

  return null;
}
