import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  serverExternalPackages: ["@prisma/client"],
  // Allow cross-origin requests from preview panel
  allowedDevOrigins: [
    "preview-chat-ab18b4b8-40ed-4c21-bd56-723559537414.space.z.ai",
    ".space.z.ai",
    "localhost:81",
  ],
};

export default nextConfig;
