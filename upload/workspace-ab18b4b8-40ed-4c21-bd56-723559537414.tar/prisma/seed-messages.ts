/**
 * Seed Messages Data - Zion Recruit
 * Creates demo conversations and messages for testing
 */

import { PrismaClient, ChannelType, ConversationStatus, SenderType, ContentType, MessageStatus } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding messages data...");

  // Get the first tenant
  const tenant = await prisma.tenant.findFirst();
  if (!tenant) {
    console.log("No tenant found. Run the main seed first.");
    return;
  }
  
  const DEMO_TENANT_ID = tenant.id;
  console.log("Using tenant ID:", DEMO_TENANT_ID);

  // Get existing candidates
  const candidates = await prisma.candidate.findMany({
    where: { tenantId: DEMO_TENANT_ID },
    take: 5,
  });

  if (candidates.length === 0) {
    console.log("No candidates found. Run the main seed first.");
    return;
  }

  // Create conversations for some candidates
  for (let i = 0; i < Math.min(candidates.length, 3); i++) {
    const candidate = candidates[i];

    // Check if conversation already exists
    const existingConversation = await prisma.conversation.findFirst({
      where: {
        tenantId: DEMO_TENANT_ID,
        candidateId: candidate.id,
        channel: ChannelType.CHAT,
      },
    });

    if (existingConversation) {
      console.log(`Conversation already exists for ${candidate.name}`);
      continue;
    }

    // Create conversation
    const conversation = await prisma.conversation.create({
      data: {
        tenantId: DEMO_TENANT_ID,
        candidateId: candidate.id,
        jobId: candidate.jobId,
        channel: ChannelType.CHAT,
        status: ConversationStatus.ACTIVE,
        aiMode: true,
        aiStage: i === 0 ? "skills_check" : i === 1 ? "availability_check" : "welcome",
        lastMessageAt: new Date(Date.now() - i * 3600000),
        lastMessagePreview: i === 0 ? "Legal! Tenho experiência com..." : i === 1 ? "Qual sua disponibilidade?" : "Olá! Sou a Zoe...",
      },
    });

    // Create initial messages
    const messages = [];

    // Welcome message from AI
    messages.push({
      conversationId: conversation.id,
      senderType: SenderType.AI,
      senderName: "Zoe (IA)",
      content: `Olá, ${candidate.name}! 👋\n\nSou a Zoe, assistente de recrutamento da Zion Recruit. Fiquei feliz em receber seu currículo!\n\nGostaria de conhecer melhor seu perfil. Tem alguns minutos para responder algumas perguntas rápidas?`,
      contentType: ContentType.TEXT,
      channel: ChannelType.CHAT,
      status: MessageStatus.SENT,
      isAiGenerated: true,
      sentAt: new Date(Date.now() - 3600000 * (i + 1)),
    });

    // Candidate response
    messages.push({
      conversationId: conversation.id,
      senderType: SenderType.CANDIDATE,
      content: "Olá! Sim, tenho alguns minutos. Pode me fazer as perguntas!",
      contentType: ContentType.TEXT,
      channel: ChannelType.CHAT,
      status: MessageStatus.SENT,
      isAiGenerated: false,
      sentAt: new Date(Date.now() - 3600000 * i - 1800000),
    });

    // AI follow-up
    messages.push({
      conversationId: conversation.id,
      senderType: SenderType.AI,
      senderName: "Zoe (IA)",
      content: `Perfeito! Vou fazer algumas perguntas rápidas para conhecer melhor seu perfil.\n\nPor favor, responda da forma que preferir - não há respostas certas ou erradas! 😊\n\nMe conta, qual sua experiência mais recente relacionada a ${candidate.job?.title || "essa área"}?`,
      contentType: ContentType.TEXT,
      channel: ChannelType.CHAT,
      status: MessageStatus.SENT,
      isAiGenerated: true,
      sentAt: new Date(Date.now() - 3600000 * i - 900000),
    });

    if (i === 0) {
      // Add more messages for first conversation
      messages.push({
        conversationId: conversation.id,
        senderType: SenderType.CANDIDATE,
        content: "Trabalho há 5 anos com desenvolvimento full stack. Minha última experiência foi em uma startup onde desenvolvi sistemas de pagamento integrados.",
        contentType: ContentType.TEXT,
        channel: ChannelType.CHAT,
        status: MessageStatus.SENT,
        isAiGenerated: false,
        sentAt: new Date(Date.now() - 600000),
      });

      messages.push({
        conversationId: conversation.id,
        senderType: SenderType.AI,
        senderName: "Zoe (IA)",
        content: "Interessante! Experiência com sistemas de pagamento é muito valiosa. Quais tecnologias você utilizou nesse projeto?",
        contentType: ContentType.TEXT,
        channel: ChannelType.CHAT,
        status: MessageStatus.SENT,
        isAiGenerated: true,
        sentAt: new Date(Date.now() - 300000),
      });
    }

    // Insert messages
    for (const msg of messages) {
      await prisma.message.create({ data: msg });
    }

    console.log(`Created conversation for ${candidate.name} with ${messages.length} messages`);

    // Add intervention for one conversation
    if (i === 1) {
      await prisma.conversation.update({
        where: { id: conversation.id },
        data: {
          needsIntervention: true,
          interventionReason: "Candidato solicitou falar com humano",
        },
      });

      await prisma.humanIntervention.create({
        data: {
          conversationId: conversation.id,
          triggeredBy: "CANDIDATE",
          reason: "Candidato solicitou falar com humano",
        },
      });

      // Add candidate message asking for human
      await prisma.message.create({
        data: {
          conversationId: conversation.id,
          senderType: SenderType.CANDIDATE,
          content: "Na verdade, prefiro falar diretamente com um recrutador se possível.",
          contentType: ContentType.TEXT,
          channel: ChannelType.CHAT,
          status: MessageStatus.SENT,
          isAiGenerated: false,
          sentAt: new Date(Date.now() - 60000),
        },
      });

      console.log(`Added intervention for ${candidate.name}`);
    }
  }

  // Create some message templates
  const templates = [
    {
      tenantId: DEMO_TENANT_ID,
      trigger: "WELCOME",
      name: "Mensagem de Boas-vindas",
      category: "screening",
      body: `Olá, {candidateName}! 👋\n\nSou a Zoe, assistente de recrutamento da Zion Recruit. Fiquei feliz em receber seu currículo para a vaga de {jobTitle}!\n\nGostaria de conhecer melhor seu perfil. Tem alguns minutos para responder algumas perguntas rápidas?`,
      channel: ChannelType.CHAT,
      variables: JSON.stringify(["candidateName", "jobTitle"]),
      isActive: true,
      isDefault: true,
    },
    {
      tenantId: DEMO_TENANT_ID,
      trigger: "SCHEDULE_INTERVIEW",
      name: "Agendar Entrevista",
      category: "scheduling",
      body: `Parabéns, {candidateName}! 🎉\n\nSeu perfil se encaixa muito bem com o que buscamos para a vaga de {jobTitle}.\n\nGostaria de agendar uma conversa com nossa equipe de recrutamento? Por favor, me informe:\n- Sua disponibilidade nos próximos dias\n- Prefere reunião por vídeo ou presencial?`,
      channel: ChannelType.CHAT,
      variables: JSON.stringify(["candidateName", "jobTitle"]),
      isActive: true,
      isDefault: true,
    },
    {
      tenantId: DEMO_TENANT_ID,
      trigger: "REJECT",
      name: "Feedback - Não Selecionado",
      category: "feedback",
      body: `Olá, {candidateName}\n\nAgradecemos seu interesse na vaga de {jobTitle} na Zion Recruit.\n\nApós análise cuidadosa do seu perfil, decidimos seguir com outros candidatos cujo perfil mais se adequa às necessidades atuais da posição.\n\nIsso não significa que você não tenha qualificações valiosas. Guardaremos seu currículo em nosso banco de talentos para oportunidades futuras.\n\nDesejamos muito sucesso em sua jornada profissional! 🙏`,
      channel: ChannelType.CHAT,
      variables: JSON.stringify(["candidateName", "jobTitle"]),
      isActive: true,
      isDefault: true,
    },
  ];

  for (const template of templates) {
    await prisma.messageTemplate.upsert({
      where: {
        tenantId_trigger_channel: {
          tenantId: DEMO_TENANT_ID,
          trigger: template.trigger,
          channel: template.channel,
        },
      },
      create: template,
      update: template,
    });
  }

  console.log("Created message templates");

  console.log("✅ Messages seed completed!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
